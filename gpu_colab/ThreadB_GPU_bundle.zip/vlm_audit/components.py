"""Per-family component extractors.

Returns ``{"vision", "fusion", "language", "head"}`` for the V/F/L/H families.
For new Phase-2 families that don't fit the V/F/L/H schema (native-fusion
Chameleon, decoupled-encoder Janus-Pro), additional component slots are used:

* ``"fused_transformer"`` — Chameleon's shared transformer; vision and language
  are not separable.
* ``"vision_und"`` / ``"vision_gen"`` — Janus-Pro's two decoupled vision
  encoders (understanding vs. generation).

Component attribute paths come from the existing notebooks where verified,
and from HuggingFace transformers source for the new model classes.

Phase-2 bug fix: IDEFICS-9B language extractor explicitly walks the LLaMA
backbone (was returning None before — see EXPERIMENT_LOG.md issue #4).

Revision fix A13 (2026-10): the IDEFICS-9B fallback omitted
``gated_cross_attn_layers`` (1,434.5 M parameters), so the reported total was
7,495.2 M against a checkpoint of 8,929.7 M. The fallback now includes them
(Section 3.2 rule: inserted cross-attention layers belong to the language
component). Janus-Pro's generation-pathway modules (``gen_embed``,
``gen_aligner``, ``gen_head``) are now attributed through the new
``fusion_gen`` / ``head_gen`` slots. Overlapping extracted modules (Qwen
merger inside ``visual``, InternVL3 ``lm_head`` inside ``language_model``,
Chameleon ``embed_tokens`` inside the fused transformer) are resolved by
``metrics.partition_component_params``, which gives every parameter exactly
one owner and reports any residual.
"""

from typing import Any, Dict, List, Optional, Tuple


COMPONENT_NAMES = ("vision", "fusion", "language", "head")
# Extended component names that may appear for native-fusion / decoupled models
EXTENDED_COMPONENT_NAMES = (
    "vision", "fusion", "language", "head",
    "fused_transformer", "vision_und", "vision_gen", "embeddings",
    "fusion_gen", "head_gen",
)

# Small top-level ``nn.Parameter`` tensors that no extracted module owns.
# Each is mapped to the component whose function it serves (matched on the
# final segment of the parameter name). Anything not listed here and not
# owned by a component is reported as unattributed by the residual check.
LOOSE_PARAMETER_COMPONENT = {
    "query_tokens": "fusion",      # BLIP-2 / InstructBLIP learned Q-Former queries
    "logit_scale": "fusion",       # CLIP / SigLIP contrastive temperature
    "logit_bias": "fusion",        # SigLIP sigmoid-loss bias
    "image_newline": "fusion",     # LLaVA-NeXT / DeepSeek-VL2 tile-separator embedding
    "view_seperator": "fusion",    # DeepSeek-VL2 global/local view separator (sic)
}

# Small modules that the extractors do not return (so that the returned
# modules stay forward-callable for the FLOPs / memory scripts) but whose
# parameters must still be attributed. Matched on the parameter-name prefix.
UNEXTRACTED_MODULE_COMPONENT = {
    "vilt.layernorm.": "language",  # final LayerNorm of ViLT's shared transformer
    "vilt.pooler.": "head",         # [CLS] pooler that feeds only the VQA classifier
}


def _safe_getattr(obj, path, default=None):
    """Resolve a dotted attribute path, returning ``default`` if any step fails."""
    cur = obj
    for part in path.split("."):
        if cur is None:
            return default
        cur = getattr(cur, part, None)
        if cur is None:
            return default
    return cur


def _params_of(mod):
    """Quick total-param helper for use inside extractors (avoids circular import)."""
    if mod is None:
        return 0
    return sum(p.numel() for p in mod.parameters())


def extract_components(model, family: str) -> Dict[str, Any]:
    """Return per-component module dict for the given family.

    For Phase-1 families this is V/F/L/H. For Phase-2 native families this
    may include additional component slots; callers must iterate the dict's
    actual keys rather than assuming V/F/L/H.
    """
    if family == "dual_encoder_contrastive":
        return _extract_clip_style(model)
    if family == "bridge_module_precursor":
        return _extract_blip_style(model)
    if family == "bridge_module":
        return _extract_blip2_style(model)
    if family == "bridge_module_adapter_llm":
        return _extract_instructblip_style(model)
    if family == "adapter_llm":
        return _extract_llava_style(model)
    if family == "cross_attention_llm":
        return _extract_cross_attention_style(model)
    if family == "perceiver_adapter_llm":
        return _extract_idefics2_style(model)
    if family == "single_stream_fused":
        return _extract_vilt_style(model)
    # --- Phase 2 families ---
    if family == "dynamic_tile_adapter_llm":
        return _extract_dynamic_tile_style(model)
    if family == "adapter_llm_own_encoder":
        return _extract_pixtral_style(model)
    if family == "moe_adapter_llm":
        return _extract_moe_style(model)
    if family == "native_early_fusion":
        return _extract_chameleon_style(model)
    if family == "native_decoupled_encoder":
        return _extract_janus_style(model)
    raise ValueError(f"Unknown family: {family!r}")


# ===========================================================================
# Phase-1 family extractors (preserved; IDEFICS extractor bug-fixed)
# ===========================================================================

def _extract_clip_style(model) -> Dict[str, Any]:
    """CLIP / SigLIP / SigLIP2 — dual towers with projection heads."""
    fusion = None
    if hasattr(model, "visual_projection") and hasattr(model, "text_projection"):
        import torch.nn as nn
        fusion = nn.ModuleList([model.visual_projection, model.text_projection])
    return {
        "vision":   getattr(model, "vision_model", None),
        "fusion":   fusion,
        "language": getattr(model, "text_model", None),
        "head":     None,
    }


def _extract_blip_style(model) -> Dict[str, Any]:
    """BLIP-1 (image-captioning / VQA)."""
    text_encoder = getattr(model, "text_encoder", None)
    if text_encoder is not None:
        n = sum(p.numel() for p in text_encoder.parameters())
        if n == 0:
            text_encoder = None
    return {
        "vision":   getattr(model, "vision_model", None),
        "fusion":   text_encoder,
        "language": getattr(model, "text_decoder", None),
        "head":     None,
    }


def _extract_blip2_style(model) -> Dict[str, Any]:
    """BLIP-2 — ViT-g + Q-Former + frozen LLM + projection."""
    return {
        "vision":   getattr(model, "vision_model", None),
        "fusion":   getattr(model, "qformer", None),
        "language": getattr(model, "language_model", None),
        "head":     getattr(model, "language_projection", None),
    }


def _extract_instructblip_style(model) -> Dict[str, Any]:
    """InstructBLIP — same layout as BLIP-2."""
    return {
        "vision":   getattr(model, "vision_model", None),
        "fusion":   getattr(model, "qformer", None),
        "language": getattr(model, "language_model", None),
        "head":     getattr(model, "language_projection", None),
    }


def _extract_llava_style(model) -> Dict[str, Any]:
    """LLaVA-1.5 / LLaVA-NeXT / Molmo — adapter-LLM with CLIP-derived vision.

    Phase-2 bug fix F-8 (transformers 5.x compatibility): HF 5.x moves
    ``vision_tower`` / ``multi_modal_projector`` / ``language_model``
    from ``model.X`` down to ``model.model.X``. The Phase-1 extractor only
    checked top-level attributes, so fusion silently came back ``None`` →
    LLaVA-1.5 reported 0% fusion (the 152M discrepancy). The cascade below
    tries the new HF 5.x path first, then falls back to the legacy one.
    Also: the top-level ``lm_head`` (131M for LLaVA-1.5) is now captured.
    """
    # Vision encoder — HF 5.x prefers model.model.vision_tower
    vision = (
        _safe_getattr(model, "model.vision_tower")          # HF 5.x — LLaVA-1.5 / -NeXT
        or getattr(model, "vision_tower", None)             # Legacy HF 4.x
        or _safe_getattr(model, "model.vision_backbone")    # Molmo legacy
        or _safe_getattr(model, "vision_backbone")
    )
    # Fusion projector — HF 5.x: model.model.multi_modal_projector
    fusion = (
        _safe_getattr(model, "model.multi_modal_projector")  # HF 5.x — THE FIX
        or getattr(model, "multi_modal_projector", None)     # Legacy HF 4.x
        or _safe_getattr(model, "model.image_projector")     # Molmo
        or _safe_getattr(model, "model.vision_projector")
    )
    # Language model — HF 5.x: model.model.language_model
    language = (
        _safe_getattr(model, "model.language_model")        # HF 5.x
        or getattr(model, "language_model", None)           # Legacy HF 4.x
        or _safe_getattr(model, "model.transformer")
    )
    return {
        "vision":   vision,
        "fusion":   fusion,
        "language": language,
        "head":     getattr(model, "lm_head", None),         # captures the 131M head
    }


def _extract_cross_attention_style(model) -> Dict[str, Any]:
    """IDEFICS-9B and Llama-3.2-Vision — gated cross-attention LLM.

    Phase-2 bug fix: the Phase-1 extractor returned ``None`` for language
    on IDEFICS-9B because ``inner.language_model`` / ``inner.text_model``
    didn't exist. We now explicitly fall back to the inner ``model.model``
    transformer and subtract the perceiver/vision portions when summarizing.
    Llama-3.2-Vision uses ``MllamaForConditionalGeneration`` which has
    ``vision_model`` + ``language_model`` + cross-attention layers inside
    the language model — handled by the cascade below.
    """
    inner = getattr(model, "model", model)

    # Vision encoder
    vision = (
        _safe_getattr(inner, "vision_model")
        or _safe_getattr(inner, "vision_tower")
    )
    # Fusion / resampler / cross-attention adapter
    fusion = (
        _safe_getattr(inner, "perceiver_resampler")
        or _safe_getattr(inner, "multi_modal_projector")
        or _safe_getattr(inner, "perceiver")
    )
    # Language: try named submodules; if not found, fall back to the inner
    # transformer body. For IDEFICS-9B the LLaMA layers sit directly under
    # ``inner.layers`` — wrap them in a transparent container so the param
    # counter sees them.
    language = (
        _safe_getattr(inner, "language_model")
        or _safe_getattr(inner, "text_model")
    )
    if language is None:
        # IDEFICS / Llama-Vision fallback: build a temporary ModuleList of
        # the transformer body so param-count picks it up. IDEFICS keeps its
        # gated cross-attention blocks in a sibling ``gated_cross_attn_layers``
        # list, NOT inside ``layers``, so it must be collected explicitly
        # (revision fix A13 — these 1,434.5 M parameters were previously lost).
        import torch.nn as nn
        bits = []
        layers = _safe_getattr(inner, "layers")
        if layers is not None:
            bits.append(layers)
        gated_cross_attention_layers = _safe_getattr(inner, "gated_cross_attn_layers")
        if gated_cross_attention_layers is not None:
            bits.append(gated_cross_attention_layers)
        embed = _safe_getattr(inner, "embed_tokens") or _safe_getattr(inner, "wte")
        if embed is not None:
            bits.append(embed)
        norm = _safe_getattr(inner, "norm") or _safe_getattr(inner, "final_layernorm")
        if norm is not None:
            bits.append(norm)
        if bits:
            language = nn.ModuleList(bits)
        else:
            # Last resort: the inner model itself (includes everything).
            language = inner

    return {
        "vision":   vision,
        "fusion":   fusion,
        "language": language,
        "head":     getattr(model, "lm_head", None),
    }


def _extract_idefics2_style(model) -> Dict[str, Any]:
    """IDEFICS2 — perceiver resampler + adapter style.

    Phase-2 bug fix F-8: HF 5.x sometimes renames ``text_model`` →
    ``language_model``; cascade tries both.
    """
    inner = getattr(model, "model", model)
    return {
        "vision":   _safe_getattr(inner, "vision_model"),
        "fusion":   _safe_getattr(inner, "connector"),
        "language": (
            _safe_getattr(inner, "text_model")
            or _safe_getattr(inner, "language_model")        # HF 5.x rename
        ),
        "head":     getattr(model, "lm_head", None),
    }


def _extract_vilt_style(model) -> Dict[str, Any]:
    """ViLT — single-stream fused."""
    inner = getattr(model, "vilt", model)
    return {
        "vision":   _safe_getattr(inner, "embeddings"),
        "fusion":   None,
        "language": _safe_getattr(inner, "encoder"),
        "head":     getattr(model, "classifier", None),
    }


# ===========================================================================
# Phase-2 family extractors
# ===========================================================================

def _extract_dynamic_tile_style(model) -> Dict[str, Any]:
    """Qwen2-VL / Qwen2.5-VL / InternVL3 — dynamic-tile adapter-LLM.

    Qwen family: ``model.visual`` (ViT), ``model.model`` (LLM body), optional merger.
    InternVL3: ``model.vision_model`` (InternViT), ``model.mlp1`` (pixel-shuffle), ``model.language_model``.
    """
    inner = getattr(model, "model", model)

    vision = (
        getattr(model, "visual", None)
        or _safe_getattr(inner, "vision_model")
        or _safe_getattr(inner, "visual")
        or _safe_getattr(model, "vision_model")
    )
    fusion = (
        _safe_getattr(model, "visual.merger")
        or _safe_getattr(inner, "merger")
        or getattr(model, "mlp1", None)
        or getattr(model, "multi_modal_projector", None)
    )
    language = (
        getattr(model, "language_model", None)
        or _safe_getattr(inner, "language_model")
        or inner
    )
    head = getattr(model, "lm_head", None)
    return {
        "vision":   vision,
        "fusion":   fusion,
        "language": language,
        "head":     head,
    }


def _extract_pixtral_style(model) -> Dict[str, Any]:
    """Pixtral-12B — LLaVA-class wrapper with own (from-scratch) vision encoder.

    HF wraps Pixtral via ``LlavaForConditionalGeneration``; the attribute names
    are the LLaVA ones but the vision module is Pixtral's bespoke encoder.

    Phase-2 bug fix F-8: HF 5.x moves the LLaVA attributes from ``model.X`` to
    ``model.model.X`` — same fix as ``_extract_llava_style``.
    """
    vision = (
        _safe_getattr(model, "model.vision_tower")           # HF 5.x
        or getattr(model, "vision_tower", None)              # Legacy HF 4.x
    )
    fusion = (
        _safe_getattr(model, "model.multi_modal_projector")  # HF 5.x
        or getattr(model, "multi_modal_projector", None)     # Legacy HF 4.x
    )
    language = (
        _safe_getattr(model, "model.language_model")         # HF 5.x
        or getattr(model, "language_model", None)            # Legacy HF 4.x
    )
    return {
        "vision":   vision,
        "fusion":   fusion,
        "language": language,
        "head":     getattr(model, "lm_head", None),         # capture top-level head
    }


def _extract_moe_style(model) -> Dict[str, Any]:
    """DeepSeek-VL2-Small — MoE adapter-LLM.

    DeepSeek-VL2 layout (custom transformers integration):
        - ``model.vision`` (SigLIP-SO400M) or ``model.vision_model``
        - ``model.projector`` (VL adapter)
        - ``model.language_model`` or ``model.language`` (DeepSeekMoE)
        - ``model.aux_loss`` for routing (ignored here)
    The language module's ``mlp`` is a sparse Mixture-of-Experts. We do not
    rewrite the V/F/L/H schema; the MoE handling lives in ``metrics.py``
    via ``count_active_params``.
    """
    inner = getattr(model, "model", model)
    vision = (
        _safe_getattr(model, "vision")
        or _safe_getattr(model, "vision_model")
        or _safe_getattr(inner, "vision")
        or _safe_getattr(inner, "vision_model")
    )
    fusion = (
        _safe_getattr(model, "projector")
        or _safe_getattr(model, "aligner")
        or _safe_getattr(inner, "projector")
        or _safe_getattr(model, "multi_modal_projector")
    )
    language = (
        _safe_getattr(model, "language")
        or _safe_getattr(model, "language_model")
        or _safe_getattr(inner, "language")
        or _safe_getattr(inner, "language_model")
        or inner
    )
    head = getattr(model, "lm_head", None)
    return {
        "vision":   vision,
        "fusion":   fusion,
        "language": language,
        "head":     head,
    }


def _extract_chameleon_style(model) -> Dict[str, Any]:
    """Chameleon-7B — native early-fusion.

    Token-based early fusion: image and text are tokenized into the same vocab.
    The V/F/L decomposition does NOT apply. We report:
        * ``fused_transformer``: the shared transformer (the whole thing).
        * ``embeddings``: the (image-token-vocab + text-token-vocab) embedding table.
        * ``head``: the lm_head.
    Caller should iterate the dict's actual keys.
    """
    inner = getattr(model, "model", model)
    return {
        "vision":   None,
        "fusion":   None,
        "language": None,
        "head":     getattr(model, "lm_head", None),
        "fused_transformer": inner,
        "embeddings": _safe_getattr(inner, "embed_tokens") or _safe_getattr(inner, "wte"),
    }


def _extract_janus_style(model) -> Dict[str, Any]:
    """Janus-Pro-7B — native unified gen+understanding with DECOUPLED encoders.

    Reports two vision encoders separately:
        * ``vision_und``: SigLIP-L for understanding (input vision pathway)
        * ``vision_gen``: VQ-style encoder for generation (output vision pathway)
    Plus a shared LLM ``language`` and an output ``head``.
    """
    inner = getattr(model, "model", model)
    vision_und = (
        _safe_getattr(model, "vision_model")
        or _safe_getattr(model, "vision")
        or _safe_getattr(model, "vision_und_encoder")
        or _safe_getattr(model, "siglip_vision_model")
        or _safe_getattr(inner, "vision_model")
    )
    vision_gen = (
        _safe_getattr(model, "gen_vision_model")
        or _safe_getattr(model, "vision_gen_encoder")
        or _safe_getattr(model, "vq_model")
    )
    fusion = (
        _safe_getattr(model, "aligner")
        or _safe_getattr(model, "projector")
    )
    language = (
        _safe_getattr(model, "language_model")
        or _safe_getattr(model, "llm")
        or _safe_getattr(inner, "language_model")
        or inner
    )
    # Generation pathway (revision fix A13): the image-token embedding and its
    # aligner feed generated-image tokens into the LLM (a fusion role), and
    # ``gen_head`` projects LLM states onto the image codebook (a head role).
    # Previously only ``aligner`` was captured and these 100.9 M parameters
    # were unattributed.
    import torch.nn as nn
    generation_input_modules = [
        module for module in (_safe_getattr(model, "gen_embed"), _safe_getattr(model, "gen_aligner"))
        if module is not None
    ]
    fusion_generation = nn.ModuleList(generation_input_modules) if generation_input_modules else None
    return {
        "vision":   vision_und,        # canonical "vision" → the understanding path
        "fusion":   fusion,
        "language": language,
        "head":     getattr(model, "lm_head", None),
        "vision_und": vision_und,      # explicit duplicate for clarity in figures
        "vision_gen": vision_gen,      # the generation-side encoder
        "fusion_gen": fusion_generation,
        "head_gen": _safe_getattr(model, "gen_head"),
    }


# ===========================================================================
# Freezing-policy hints (one per family) — used by metrics.compute_trainable_from_policy
# ===========================================================================

def freezing_policy_hint(family: str) -> str:
    """Short prose description of the typical training-stage freezing policy."""
    return {
        "dual_encoder_contrastive":      "End-to-end pretraining; nothing frozen.",
        "bridge_module_precursor":       "End-to-end pretraining.",
        "bridge_module":                 "Vision encoder and LLM frozen; only Q-Former trained.",
        "bridge_module_adapter_llm":     "Vision encoder and LLM frozen; Q-Former and instruction adapter trained.",
        "adapter_llm":                   "Stage-1: only projector trained. Stage-2: projector + LLM trained; vision frozen throughout.",
        "cross_attention_llm":           "LLM backbone frozen; inserted cross-attention layers and the vision-to-LLM adapter trained. Vision encoder frozen (IDEFICS) or updated (Llama-3.2-Vision) - see ModelSpec.training_recipe_note.",
        "perceiver_adapter_llm":         "Vision frozen during pretraining; perceiver + adapter trained.",
        "single_stream_fused":           "End-to-end training of the single shared transformer.",
        "dynamic_tile_adapter_llm":      "Vision encoder frozen in early stage; vision + projector + LLM trained end-to-end in later stages.",
        "adapter_llm_own_encoder":       "Vision encoder trained end-to-end with LLM (no pre-existing frozen CLIP).",
        "moe_adapter_llm":               "Vision encoder frozen; MoE LLM + projector trained.",
        "native_early_fusion":           "End-to-end pretraining of the single shared transformer over interleaved tokens.",
        "native_decoupled_encoder":      "Two-stage: vision encoders pretrained, then LLM joint-trained on both encoders.",
    }.get(family, "")


# ===========================================================================
# Trainable-component sets derived from freezing policy (Phase-2 bug fix F-5)
# ===========================================================================

def trainable_components_for_family(family: str) -> Dict[str, bool]:
    """Which V/F/L/H components are trainable under the canonical recipe?

    Used by ``metrics.compute_trainable_from_policy`` to compute
    ``params_trainable`` from the documented training recipe rather than
    from ``requires_grad`` (which is True for everything on a fresh HF
    ``from_pretrained`` load — see EXPERIMENT_LOG.md issue F-5).

    Values are ``True`` (trainable), ``False`` (frozen), or
    ``INSERTED_CROSS_ATTENTION_ONLY`` (only the cross-attention blocks that
    were inserted into an otherwise frozen language model are trained).
    Per-model deviations live in ``ModelSpec.trainable_policy_override``.
    """
    # True = trainable in the canonical training recipe; False = frozen.
    return {
        "dual_encoder_contrastive":      {"vision": True,  "fusion": True,  "language": True,  "head": True},
        "bridge_module_precursor":       {"vision": True,  "fusion": True,  "language": True,  "head": True},
        "bridge_module":                 {"vision": False, "fusion": True,  "language": False, "head": True},
        "bridge_module_adapter_llm":     {"vision": False, "fusion": True,  "language": False, "head": True},
        "adapter_llm":                   {"vision": False, "fusion": True,  "language": True,  "head": True},   # stage-2 final
        # Revision fix A13: the LM head belongs to the frozen language model, and
        # the trained cross-attention blocks sit INSIDE the language component.
        "cross_attention_llm":           {"vision": False, "fusion": True,
                                          "language": INSERTED_CROSS_ATTENTION_ONLY, "head": False},
        "perceiver_adapter_llm":         {"vision": False, "fusion": True,  "language": True,  "head": True},
        "single_stream_fused":           {"vision": True,  "fusion": True,  "language": True,  "head": True},
        "dynamic_tile_adapter_llm":      {"vision": True,  "fusion": True,  "language": True,  "head": True},   # late-stage
        "adapter_llm_own_encoder":       {"vision": True,  "fusion": True,  "language": True,  "head": True},
        "moe_adapter_llm":               {"vision": False, "fusion": True,  "language": True,  "head": True},
        "native_early_fusion":           {"vision": True,  "fusion": True,  "language": True,  "head": True,
                                          "fused_transformer": True, "embeddings": True},
        "native_decoupled_encoder":      {"vision": True,  "fusion": True,  "language": True,  "head": True,
                                          "vision_und": True, "vision_gen": True,
                                          "fusion_gen": True, "head_gen": True},
    }.get(family, {})


# ===========================================================================
# Inserted cross-attention layers (revision fix A13)
# ===========================================================================

INSERTED_CROSS_ATTENTION_ONLY = "inserted_cross_attention_only"


def find_inserted_cross_attention_modules(model) -> List[Tuple[str, Any]]:
    """Return ``[(module_path, module), ...]`` for cross-attention blocks inserted into the LLM.

    Two layouts exist in the roster:

    * IDEFICS-9B keeps them in a separate ``model.gated_cross_attn_layers`` list.
    * Llama-3.2-Vision (Mllama) interleaves them with the self-attention layers;
      they are recognised by their class name (``MllamaCrossAttentionDecoderLayer``).

    Returns an empty list for models without inserted cross-attention.
    """
    found_modules = []
    for module_path, module in model.named_modules():
        is_idefics_block_list = module_path.endswith("gated_cross_attn_layers")
        is_mllama_cross_layer = type(module).__name__.endswith("CrossAttentionDecoderLayer")
        if is_idefics_block_list or is_mllama_cross_layer:
            found_modules.append((module_path, module))
    return found_modules


def find_component_aliases(components: Dict[str, Any]) -> Dict[str, str]:
    """Return ``{alias_name: canonical_name}`` for components that point at the same module object.

    Janus-Pro reports its understanding encoder under both ``vision`` and
    ``vision_und``. The specific slot (``vision_und``) owns the parameters;
    the generic slot is an alias and is excluded from parameter sums.
    """
    aliases = {}
    named_modules = [(name, module) for name, module in components.items() if module is not None]
    for alias_index, (alias_name, alias_module) in enumerate(named_modules):
        for canonical_name, canonical_module in named_modules[alias_index + 1:]:
            if alias_module is canonical_module:
                generic_first = alias_name in COMPONENT_NAMES and canonical_name not in COMPONENT_NAMES
                if generic_first:
                    aliases[alias_name] = canonical_name
                else:
                    aliases[canonical_name] = alias_name
    return aliases
