"""Analysis of the GPU latency measurements (notebooks 29 and 30; reviewer item A5 iii).

Reads the per-model JSON results written by ``latency_measurement`` and answers:

1. **Does the cost model hold at full depth?** Predicted versus op-level FLOPs per
   component on the released checkpoints (``flop_validation_table``).
2. **Which quantity tracks prefill latency?** Spearman correlations of measured
   prefill latency with the predicted FLOPs of the executed input, the revised
   Table 3 FLOPs, the parameter count and the visual tokens in the language
   model (``proxy_correlations``), with permutation p-values.
3. **Do compute shares match time shares?** Measured vision-encoder share of
   prefill time against the predicted encoder share of FLOPs (``component_shares``).
4. **Does latency scale with FLOPs within a model?** 448 x 448 to 1024 x 1024
   ratios (``input_scaling``).
5. **What sets decode cost?** Per-token decode latency against resident weights
   and active parameters, and its sensitivity to the image size (``decode_table``).

Diagnostics added after the first GPU run (2026-10-03):

* the proxy test restricted to the LLM-based models, so that a proxy cannot win only
  by separating sub-billion encoders from 7B language models (``llm_based``);
* executed versus intrinsic FLOPs: padding the reference implementations run
  (``executed_versus_intrinsic``);
* whether the cheaper model of a pair changes with the input size (``latency_rank_changes``);
* the vision encoder's share of time against its share of FLOPs, with the throughput
  each component reaches (``encoder_time_versus_flops``);
* prefill cost in units of decode steps (``prefill_in_decode_tokens``).

The per-pass floor (decision log N28, added 2026-10-04):

* the language model's prefill time in decode steps against the tokens it sees
  (``prefill_floor_table``, ``floor_summary``);
* decode time per token against the operator calls of one decode step, counted by
  ``operator_dispatch`` under the transformers release of each GPU measurement
  (``matched_operator_counts``, ``decode_versus_operator_calls``).

Author: Sunita Sahu.
"""

import json
import math
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .correlation_grid import pairwise_order_changes, spearman_permutation_test
from .latency_measurement import COMPONENTS, summary_rows
from .tensor_cost_model import LANGUAGE, VISION

PRIMARY_INPUT = "1024x1024"
SENSITIVITY_INPUT = "448x448"

# Models without a language model that generates from visual tokens: dual encoders, ViLT's
# answer classifier, BLIP-large's 0.14B captioning decoder.
NON_LLM_MODELS = {"CLIP-ViT-L/14", "SigLIP-L/16", "SigLIP2-So400m/14", "ViLT-B/32", "BLIP-large"}


def exclude_results(results: List[dict], excluded: Dict[str, str]) -> List[dict]:
    """Drop results known to be invalid ({model: reason}); the reasons are printed, not hidden."""
    for model_name, reason in excluded.items():
        print(f"excluded {model_name}: {reason}")
    return [result for result in results if result.get("model") not in excluded]


def llm_based(table: pd.DataFrame) -> pd.DataFrame:
    """Rows of the models whose language model generates from visual input."""
    return table[~table["model"].isin(NON_LLM_MODELS)]


def load_results(results_directory, include_dry_run: bool = False) -> List[dict]:
    """Every per-model JSON result in a folder (released-weight runs only, unless asked)."""
    results = []
    for path in sorted(Path(results_directory).glob("*.json")):
        result = json.loads(path.read_text(encoding="utf-8"))
        if result.get("mode") == "released" or include_dry_run:
            results.append(result)
    return results


def run_overview(results: List[dict]) -> pd.DataFrame:
    """Status, GPU, library versions and errors of every model result."""
    rows = []
    for result in results:
        versions = result.get("library_versions") or {}
        rows.append({
            "model": result.get("model"), "status": result.get("status"), "mode": result.get("mode"),
            "gpu": (result.get("gpu") or {}).get("name"), "transformers": versions.get("transformers"),
            "torch": versions.get("torch"), "attention": result.get("attention_implementation"),
            "inputs_complete": ", ".join(key for key, entry in result.get("inputs", {}).items()
                                         if entry.get("status") == "complete"),
            "stage_errors": "; ".join(f"{key}:{stage}" for key, entry in result.get("inputs", {}).items()
                                      for stage in entry.get("errors", {})),
            "run_error": (result.get("run_error") or "").strip().splitlines()[-1] if result.get("run_error") else "",
            "notes": " | ".join(result.get("notes") or []),
        })
    return pd.DataFrame(rows)


def latency_table(results: List[dict]) -> pd.DataFrame:
    """One row per (model, input) with the summary columns plus derived shares and rates."""
    table = pd.DataFrame([row for result in results for row in summary_rows(result)])
    if table.empty:
        return table
    table["predicted_total_tflops"] = table["predicted_total_gflops"] / 1000.0
    table["vision_time_share_pct"] = 100.0 * table[f"{VISION}_ms_median"] / table["prefill_ms_median"]
    table["measured_vision_flop_share_pct"] = 100.0 * table[f"measured_{VISION}_gflops"] / table["measured_total_gflops"]
    return table


def flop_validation_table(results: List[dict]) -> pd.DataFrame:
    """Predicted versus op-level FLOPs per component, for every model and input."""
    rows = []
    for result in results:
        for input_key, entry in result.get("inputs", {}).items():
            measured = entry.get("measured_gflops") or {}
            predicted = entry.get("predicted_executed_gflops") or {}
            for component in (*COMPONENTS, "total"):
                if measured.get(component) and predicted.get(component) is not None:
                    rows.append({"model": result["model"], "input": input_key, "component": component,
                                 "measured_gflops": measured[component], "predicted_gflops": predicted[component],
                                 "relative_difference_pct": 100.0 * (predicted[component] - measured[component])
                                 / measured[component]})
    return pd.DataFrame(rows)


def _log_log_fit(predictor, response) -> Dict[str, float]:
    """Least-squares fit of log10(response) on log10(predictor): slope, intercept, R squared."""
    predictor_logs = np.log10(np.asarray(predictor, dtype=float))
    response_logs = np.log10(np.asarray(response, dtype=float))
    slope, intercept = np.polyfit(predictor_logs, response_logs, 1)
    fitted = slope * predictor_logs + intercept
    residual = float(((response_logs - fitted) ** 2).sum())
    total = float(((response_logs - response_logs.mean()) ** 2).sum())
    return {"slope": float(slope), "intercept": float(intercept), "r_squared": 1.0 - residual / total if total else math.nan}


PROXIES = {
    "predicted_total_gflops": "cost model, executed input",
    "predicted_intrinsic_total_gflops": "cost model, revised Table 3 convention",
    "parameter_count": "total parameters",
    "language_visual_tokens": "visual tokens in the language model",
}


def proxy_correlations(table: pd.DataFrame, response: str = "prefill_ms_median", seed: int = 0) -> pd.DataFrame:
    """Spearman correlation (permutation p) of a latency column with each candidate proxy, per input."""
    rows = []
    for input_key, group in table.groupby("input"):
        for proxy, description in PROXIES.items():
            usable = group.dropna(subset=[proxy, response])
            usable = usable[usable[response] > 0]
            if len(usable) < 4 or usable[proxy].nunique() < 2:
                continue
            test = spearman_permutation_test(usable[proxy], usable[response], seed=seed)
            row = {"input": input_key, "response": response, "proxy": proxy, "description": description,
                   "sample_size": test["sample_size"], "spearman_rho": test["rho"], "p_value": test["p_value"],
                   "exact": test["exact"]}
            if (usable[proxy] > 0).all():
                fit = _log_log_fit(usable[proxy], usable[response])
                row.update({f"log_log_{key}": value for key, value in fit.items()})
            rows.append(row)
    return pd.DataFrame(rows)


def component_shares(table: pd.DataFrame, seed: int = 0) -> pd.DataFrame:
    """Measured vision share of prefill time against the predicted vision share of FLOPs, per input."""
    rows = []
    for input_key, group in table.groupby("input"):
        usable = group.dropna(subset=["vision_time_share_pct", "predicted_vision_share_pct"])
        usable = usable[usable["predicted_vision_share_pct"] > 0]
        if len(usable) < 4:
            continue
        test = spearman_permutation_test(usable["predicted_vision_share_pct"], usable["vision_time_share_pct"], seed=seed)
        difference = usable["vision_time_share_pct"] - usable["predicted_vision_share_pct"]
        rows.append({"input": input_key, "sample_size": test["sample_size"], "spearman_rho": test["rho"],
                     "p_value": test["p_value"], "mean_difference_pp": float(difference.mean()),
                     "mean_absolute_difference_pp": float(difference.abs().mean()),
                     "largest_absolute_difference_pp": float(difference.abs().max()),
                     "largest_difference_model": usable.loc[difference.abs().idxmax(), "model"]})
    return pd.DataFrame(rows)


def input_scaling(table: pd.DataFrame, small: str = SENSITIVITY_INPUT, large: str = PRIMARY_INPUT,
                  seed: int = 0) -> Dict[str, object]:
    """Per-model latency ratio (large / small input) against the predicted FLOP ratio."""
    columns = ["model", "prefill_ms_median", "predicted_total_gflops", "decode_ms_per_token"]
    small_rows = table[table["input"] == small][columns].set_index("model")
    large_rows = table[table["input"] == large][columns].set_index("model")
    joined = small_rows.join(large_rows, lsuffix="_small", rsuffix="_large", how="inner").dropna(
        subset=["prefill_ms_median_small", "prefill_ms_median_large"])
    joined["latency_ratio"] = joined["prefill_ms_median_large"] / joined["prefill_ms_median_small"]
    joined["predicted_flop_ratio"] = joined["predicted_total_gflops_large"] / joined["predicted_total_gflops_small"]
    joined["decode_ratio"] = joined["decode_ms_per_token_large"] / joined["decode_ms_per_token_small"]
    summary: Dict[str, object] = {"per_model": joined.reset_index()}
    varying = joined[joined["predicted_flop_ratio"] > 1.001]
    if len(varying) >= 4:
        test = spearman_permutation_test(varying["predicted_flop_ratio"], varying["latency_ratio"], seed=seed)
        summary.update({"models_whose_flops_change": len(varying), "spearman_rho": test["rho"],
                        "p_value": test["p_value"]})
    return summary


def decode_table(table: pd.DataFrame, input_key: str = PRIMARY_INPUT, seed: int = 0) -> Dict[str, object]:
    """Per-token decode latency against resident weights and active parameters (one input size)."""
    rows = table[(table["input"] == input_key)].dropna(subset=["decode_ms_per_token"])
    summary: Dict[str, object] = {"per_model": rows[["model", "decode_ms_per_token", "weights_resident_gb",
                                                      "active_parameter_count", "parameter_count",
                                                      "language_visual_tokens"]].reset_index(drop=True)}
    for proxy in ("weights_resident_gb", "active_parameter_count", "language_visual_tokens"):
        usable = rows.dropna(subset=[proxy])
        if len(usable) >= 4 and usable[proxy].nunique() > 1:
            test = spearman_permutation_test(usable[proxy], usable["decode_ms_per_token"], seed=seed)
            summary[f"rho_with_{proxy}"] = test["rho"]
            summary[f"p_with_{proxy}"] = test["p_value"]
            summary[f"n_with_{proxy}"] = test["sample_size"]
    return summary


def executed_versus_intrinsic(table: pd.DataFrame, threshold: float = 0.05) -> pd.DataFrame:
    """Models whose executed FLOPs differ from the revised-protocol (intrinsic) FLOPs by more than ``threshold``.

    Differences come from padding the reference implementation runs (Llama-3.2's empty tile
    slots, Idefics2's padded sub-images), from DeepSeek-VL2's absorbed latent attention, from
    LM heads computed at every position, and from prompts shorter or longer than the
    32-token convention.
    """
    view = table[["model", "input", "predicted_total_gflops", "predicted_intrinsic_total_gflops",
                  "encoder_tokens", "prefill_ms_median"]].copy()
    view["executed_over_intrinsic"] = view["predicted_total_gflops"] / view["predicted_intrinsic_total_gflops"]
    return view[(view["executed_over_intrinsic"] - 1.0).abs() > threshold].sort_values("executed_over_intrinsic")


def latency_rank_changes(table: pd.DataFrame, small: str = SENSITIVITY_INPUT, large: str = PRIMARY_INPUT,
                         minimum_gap: float = 0.05) -> Dict[str, object]:
    """Does the latency order of model pairs change between two input sizes?

    A pair counts as flipped when its order differs and both gaps exceed ``minimum_gap``
    (relative), so measurement noise cannot create a flip (``pairwise_order_changes``).
    """
    from scipy import stats

    latency = table.pivot(index="model", columns="input", values="prefill_ms_median").dropna(subset=[small, large])
    latency["ratio_large_over_small"] = latency[large] / latency[small]
    flipped = pairwise_order_changes(latency[small].rename(f"ms_{small}"), latency[large].rename(f"ms_{large}"),
                                     minimum_gap)
    names = latency.index
    tau = stats.kendalltau(latency[small], latency[large]).statistic
    return {"per_model": latency.reset_index(), "flipped_pairs": flipped,
            "pairs": len(names) * (len(names) - 1) // 2, "kendall_tau": float(tau)}


def encoder_time_versus_flops(table: pd.DataFrame, input_key: str = PRIMARY_INPUT) -> pd.DataFrame:
    """Vision encoder: share of prefill time against share of FLOPs, and the throughput of each component."""
    rows = llm_based(table[table["input"] == input_key]).copy()
    rows["time_share_over_flop_share"] = rows["vision_time_share_pct"] / rows["predicted_vision_share_pct"]
    rows["encoder_tflops_per_second"] = rows[f"predicted_{VISION}_gflops"] / rows[f"{VISION}_ms_median"]
    rows["language_tflops_per_second"] = rows[f"predicted_{LANGUAGE}_gflops"] / rows[f"{LANGUAGE}_ms_median"]
    columns = ["model", "predicted_vision_share_pct", "vision_time_share_pct", "time_share_over_flop_share",
               "encoder_tflops_per_second", "language_tflops_per_second", "achieved_tflops_per_second"]
    return rows[columns].sort_values("time_share_over_flop_share").reset_index(drop=True)


def prefill_in_decode_tokens(table: pd.DataFrame, input_key: str = PRIMARY_INPUT) -> pd.DataFrame:
    """Prefill latency expressed as the number of decode steps it equals."""
    rows = table[(table["input"] == input_key) & table["decode_ms_per_token"].notna()].copy()
    rows["prefill_in_decode_tokens"] = rows["prefill_ms_median"] / rows["decode_ms_per_token"]
    return rows[["model", "prefill_ms_median", "decode_ms_per_token", "prefill_in_decode_tokens",
                 "weights_resident_gb"]].sort_values("prefill_in_decode_tokens").reset_index(drop=True)


# ---------------------------------------------------------------------------
# The per-pass floor (decision log N28)
# ---------------------------------------------------------------------------

# A language-model prefill counts as "on the floor" when it takes at most this many decode steps.
FLOOR_TOLERANCE_DECODE_STEPS = 1.2
# Routed-expert language models: a prefill over many tokens reaches most experts, a decode step only a few,
# so their prefill-to-decode ratio is not comparable with dense models.
MIXTURE_OF_EXPERTS_MODELS = {"DeepSeek-VL2-Small", "Gemma-4-26B-A4B"}
# Processors that resize every image to a fixed soft-token budget (decision log N25).
TOKEN_BUDGET_MODELS = {"Gemma-4-12B", "Gemma-4-26B-A4B"}


def prefill_floor_table(table: pd.DataFrame) -> pd.DataFrame:
    """Language-model prefill time in decode steps, against the tokens the language model sees (every input)."""
    rows = table.dropna(subset=["decode_ms_per_token", f"{LANGUAGE}_ms_median"]).copy()
    rows["language_tokens"] = rows["language_visual_tokens"] + rows["text_tokens"]
    rows["language_prefill_in_decode_steps"] = rows[f"{LANGUAGE}_ms_median"] / rows["decode_ms_per_token"]
    rows["mixture_of_experts"] = rows["model"].isin(MIXTURE_OF_EXPERTS_MODELS)
    rows["on_floor"] = rows["language_prefill_in_decode_steps"] <= FLOOR_TOLERANCE_DECODE_STEPS
    columns = ["model", "input", "language_tokens", f"{LANGUAGE}_ms_median", "decode_ms_per_token",
               "language_prefill_in_decode_steps", "on_floor", "mixture_of_experts"]
    return rows[columns].sort_values(["language_tokens", "model", "input"]).reset_index(drop=True)


def floor_summary(floor_table: pd.DataFrame) -> Dict[str, object]:
    """Dense measurements on and above the floor, and whether the token count separates them."""
    dense = floor_table[~floor_table["mixture_of_experts"]]
    on_floor = dense[dense["on_floor"]]
    above_floor = dense[~dense["on_floor"]]
    summary: Dict[str, object] = {"dense_measurements": len(dense), "on_floor": len(on_floor),
                                  "tolerance_decode_steps": FLOOR_TOLERANCE_DECODE_STEPS}
    if not on_floor.empty:
        summary.update({"on_floor_ratio_min": float(on_floor["language_prefill_in_decode_steps"].min()),
                        "on_floor_ratio_max": float(on_floor["language_prefill_in_decode_steps"].max()),
                        "on_floor_max_tokens": int(on_floor["language_tokens"].max())})
    if not above_floor.empty:
        summary["above_floor_min_tokens"] = int(above_floor["language_tokens"].min())
    if not on_floor.empty and not above_floor.empty:
        summary["separated_by_token_count"] = bool(summary["on_floor_max_tokens"] < summary["above_floor_min_tokens"])
    moe = floor_table[floor_table["mixture_of_experts"]]
    summary["mixture_of_experts_rows"] = moe[["model", "input", "language_tokens",
                                              "language_prefill_in_decode_steps"]].to_dict("records")
    return summary


def library_release_by_model(results: List[dict]) -> Dict[str, str]:
    """The transformers release each model's GPU result was measured with."""
    return {result["model"]: (result.get("library_versions") or {}).get("transformers") for result in results}


def matched_operator_counts(operator_counts: pd.DataFrame, results: List[dict]) -> pd.DataFrame:
    """For each model, the operator count taken under the transformers release of its GPU measurement."""
    if operator_counts.empty:
        return operator_counts
    complete = operator_counts[operator_counts["status"] == "complete"].copy()
    releases = library_release_by_model(results)
    complete["measured_release"] = complete["model"].map(releases)
    return complete[complete["transformers_version"] == complete["measured_release"]].reset_index(drop=True)


def decode_versus_operator_calls(table: pd.DataFrame, matched_counts: pd.DataFrame,
                                 input_key: str = PRIMARY_INPUT, seed: int = 0) -> Dict[str, object]:
    """Decode time per token against operator calls per decode step, and against weights on the same models."""
    decode = table[table["input"] == input_key].dropna(subset=["decode_ms_per_token"])
    merged = decode[["model", "decode_ms_per_token", "weights_resident_gb", "active_parameter_count"]].merge(
        matched_counts[["model", "calls_per_decode_step", "transformers_version", "host_synchronisations_reduced"]],
        on="model", how="inner")
    merged["microseconds_per_call"] = 1000.0 * merged["decode_ms_per_token"] / merged["calls_per_decode_step"]
    summary: Dict[str, object] = {"per_model": merged.sort_values("calls_per_decode_step").reset_index(drop=True),
                                  "sample_size": len(merged),
                                  "not_counted": sorted(set(decode["model"]) - set(merged["model"]))}
    if len(merged) < 4:
        return summary
    for predictor in ("calls_per_decode_step", "weights_resident_gb", "active_parameter_count"):
        test = spearman_permutation_test(merged[predictor], merged["decode_ms_per_token"], seed=seed)
        summary[f"spearman_with_{predictor}"] = test["rho"]
        summary[f"p_with_{predictor}"] = test["p_value"]
        summary[f"pearson_with_{predictor}"] = float(np.corrcoef(merged[predictor].astype(float),
                                                                 merged["decode_ms_per_token"])[0, 1])
    slope, intercept = np.polyfit(merged["calls_per_decode_step"].astype(float), merged["decode_ms_per_token"], 1)
    summary["fit_microseconds_per_call"] = float(1000.0 * slope)
    summary["fit_intercept_ms"] = float(intercept)
    return summary


def floor_markdown(floor: Dict[str, object], dispatch: Dict[str, object], budget_free_proxies: pd.DataFrame,
                   bridge: Optional[pd.DataFrame] = None) -> str:
    """Plain summary of the per-pass floor analysis (numbers only)."""
    lines = ["", "## Per-pass floor (decision log N28)", ""]
    if "on_floor_ratio_min" in floor:
        separation = (f"; every dense measurement with at most {floor['on_floor_max_tokens']} language tokens is on the "
                      f"floor and every one from {floor['above_floor_min_tokens']} tokens is above it"
                      if floor.get("separated_by_token_count") else "")
        lines.append(f"- Language-model prefill within {floor['tolerance_decode_steps']} decode steps: "
                     f"{floor['on_floor']} of {floor['dense_measurements']} dense measurements "
                     f"({floor['on_floor_ratio_min']:.2f}–{floor['on_floor_ratio_max']:.2f} decode steps){separation}.")
    for row in floor.get("mixture_of_experts_rows", []):
        lines.append(f"- Mixture of experts, {row['model']} at {row['input']}: {row['language_tokens']} language tokens, "
                     f"{row['language_prefill_in_decode_steps']:.2f} decode steps.")
    if "spearman_with_calls_per_decode_step" in dispatch:
        lines.append(f"- Decode time per token vs operator calls per decode step (n = {dispatch['sample_size']}): "
                     f"Spearman ρ = {dispatch['spearman_with_calls_per_decode_step']:+.2f} "
                     f"({format_p_value(dispatch['p_with_calls_per_decode_step'])}), Pearson r = "
                     f"{dispatch['pearson_with_calls_per_decode_step']:+.3f}; fit {dispatch['fit_microseconds_per_call']:.1f} µs "
                     f"per call + {dispatch['fit_intercept_ms']:.1f} ms.")
        lines.append(f"- Same models, decode vs resident weights: Spearman ρ = {dispatch['spearman_with_weights_resident_gb']:+.2f}, "
                     f"Pearson r = {dispatch['pearson_with_weights_resident_gb']:+.3f}; vs active parameters: ρ = "
                     f"{dispatch['spearman_with_active_parameter_count']:+.2f}, r = "
                     f"{dispatch['pearson_with_active_parameter_count']:+.3f}.")
        per_call = dispatch["per_model"]["microseconds_per_call"]
        lines.append(f"- Decode time / calls: {per_call.min():.1f}–{per_call.max():.1f} µs per call "
                     f"(median {per_call.median():.1f}).")
    if dispatch.get("not_counted"):
        lines.append(f"- Not counted (other environment or failed): {', '.join(dispatch['not_counted'])}.")
    if bridge is not None and len(bridge) > 1:
        counts = ", ".join(f"{row['calls_per_decode_step']} under transformers {row['transformers_version']}"
                           for _, row in bridge.iterrows())
        lines.append(f"- {bridge['model'].iloc[0]} counted in both environments: {counts}.")
    for _, row in budget_free_proxies.iterrows():
        lines.append(f"- Without the token-budget models ({', '.join(sorted(TOKEN_BUDGET_MODELS))}), {row['input']}: "
                     f"prefill vs {row['description']}: ρ = {row['spearman_rho']:+.2f} (n = {row['sample_size']}).")
    return "\n".join(lines) + "\n"


def format_p_value(p_value: float) -> str:
    """p = 0.0123, or p < 0.0001 (Monte Carlo p-values are never exactly zero)."""
    return "p < 0.0001" if p_value < 0.0001 else f"p = {p_value:.4f}"


def gpu_names(results: List[dict]) -> List[str]:
    """Distinct GPU names across the results (one is required for comparable latencies)."""
    return sorted({(result.get("gpu") or {}).get("name") for result in results if result.get("gpu")})


def findings_markdown(results: List[dict], validation: pd.DataFrame, table: pd.DataFrame,
                      proxies: pd.DataFrame, shares: pd.DataFrame, scaling: Dict[str, object],
                      decode: Dict[str, object]) -> str:
    """Plain summary of the numbers (no interpretation beyond what the tables show)."""
    lines = ["# Latency validation — summary of notebook 31", "",
             f"- Models with results: {len(results)}; GPUs: {', '.join(map(str, gpu_names(results))) or 'none'}."]
    if not validation.empty:
        components = validation[validation["component"] != "total"]
        worst = components.loc[components["relative_difference_pct"].abs().idxmax()]
        lines.append(f"- Cost model vs full-depth op-level FLOPs: {len(components)} component comparisons; largest "
                     f"|difference| {abs(worst.relative_difference_pct):.3f}% ({worst.model}, {worst.input}, {worst.component}).")
    elementwise = table["elementwise_share_pct"].dropna() if "elementwise_share_pct" in table else pd.Series(dtype=float)
    if not elementwise.empty:
        lines.append(f"- Element-wise work at full depth: {elementwise.min():.2f}–{elementwise.max():.2f}% of FLOPs "
                     f"(median {elementwise.median():.2f}%).")
    for _, row in proxies.iterrows():
        fit = (f"; log-log slope {row['log_log_slope']:.2f}, R² {row['log_log_r_squared']:.2f}"
               if "log_log_slope" in row and pd.notna(row.get("log_log_slope")) else "")
        lines.append(f"- {row['input']}: prefill latency vs {row['description']}: Spearman ρ = {row['spearman_rho']:+.2f} "
                     f"(n = {row['sample_size']}, {format_p_value(row['p_value'])}){fit}.")
    for _, row in shares.iterrows():
        lines.append(f"- {row['input']}: vision share of prefill time vs predicted vision share of FLOPs: ρ = "
                     f"{row['spearman_rho']:+.2f} (n = {row['sample_size']}); mean |difference| "
                     f"{row['mean_absolute_difference_pp']:.1f} pp (largest {row['largest_absolute_difference_pp']:.1f} pp, "
                     f"{row['largest_difference_model']}).")
    if "spearman_rho" in scaling:
        lines.append(f"- 448² → 1024²: latency ratio vs predicted FLOP ratio over the {scaling['models_whose_flops_change']} "
                     f"models whose input changes: ρ = {scaling['spearman_rho']:+.2f} ({format_p_value(scaling['p_value'])}).")
    for proxy in ("weights_resident_gb", "active_parameter_count", "language_visual_tokens"):
        if f"rho_with_{proxy}" in decode:
            lines.append(f"- Decode latency per token vs {proxy.replace('_', ' ')}: ρ = {decode[f'rho_with_{proxy}']:+.2f} "
                         f"(n = {decode[f'n_with_{proxy}']}, {format_p_value(decode[f'p_with_{proxy}'])}).")
    return "\n".join(lines) + "\n"


def diagnostics_markdown(llm_proxies: pd.DataFrame, executed: pd.DataFrame, rank_changes: Dict[str, object],
                         encoder: pd.DataFrame, prefill_decode: pd.DataFrame, excluded: Dict[str, str]) -> str:
    """Plain summary of the diagnostics (numbers only)."""
    lines = ["", "## Diagnostics", ""]
    for model_name, reason in excluded.items():
        lines.append(f"- Excluded: {model_name} ({reason}).")
    for _, row in llm_proxies.iterrows():
        lines.append(f"- LLM-based models only, {row['input']}: prefill latency vs {row['description']}: "
                     f"ρ = {row['spearman_rho']:+.2f} (n = {row['sample_size']}, {format_p_value(row['p_value'])}).")
    for _, row in executed.iterrows():
        lines.append(f"- Executed / intrinsic FLOPs, {row['model']} at {row['input']}: {row['executed_over_intrinsic']:.2f}× "
                     f"({row['prefill_ms_median']:.0f} ms).")
    per_model = rank_changes["per_model"]
    changing = per_model[per_model["ratio_large_over_small"] > 1.1].sort_values("ratio_large_over_small")
    lines.append(f"- Latency at 1024² / 448²: {len(changing)} models change by more than 10% "
                 f"({', '.join(f'{name} {ratio:.1f}×' for name, ratio in zip(changing['model'], changing['ratio_large_over_small']))}); "
                 f"Kendall τ between the two latency rankings {rank_changes['kendall_tau']:.2f}; "
                 f"{len(rank_changes['flipped_pairs'])} of {rank_changes['pairs']} model pairs change order (gaps > 5%).")
    lines.append(f"- Vision encoder, share of prefill time / share of FLOPs (LLM-based, 1024²): median "
                 f"{encoder['time_share_over_flop_share'].median():.2f}, range {encoder['time_share_over_flop_share'].min():.2f}–"
                 f"{encoder['time_share_over_flop_share'].max():.2f}; encoder throughput "
                 f"{encoder['encoder_tflops_per_second'].min():.0f}–{encoder['encoder_tflops_per_second'].max():.0f} TFLOP/s, "
                 f"language-model throughput {encoder['language_tflops_per_second'].min():.0f}–"
                 f"{encoder['language_tflops_per_second'].max():.0f} TFLOP/s.")
    lines.append(f"- Prefill at 1024² equals {prefill_decode['prefill_in_decode_tokens'].min():.1f}–"
                 f"{prefill_decode['prefill_in_decode_tokens'].max():.1f} decode steps "
                 f"(median {prefill_decode['prefill_in_decode_tokens'].median():.1f}).")
    return "\n".join(lines) + "\n"
