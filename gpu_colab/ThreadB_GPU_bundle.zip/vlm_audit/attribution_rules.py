"""Tensor-level component attribution and final-stage training sets (reviewer items A3, A7, A8).

One explicit rule table assigns EVERY parameter tensor of every roster model to
exactly one component. It is applied to the parameter names of the released
architecture (weightless skeleton, or the checkpoint header for remote-code
models). This is the "classification rules" table the manuscript promises as
supplementary material, and it replaces module-extractor heuristics with rules
a reader can check line by line.

Conventions (applied uniformly):

* ``vision``   — modality-specific image encoder(s), including patch / position
  embeddings of image tokens and any pooling head that belongs to the encoder.
* ``fusion``   — everything that converts encoder output into language-side input:
  projectors, Q-Formers, resamplers, mergers, pooling connectors, learned
  layout vectors (image newline / separators), modality-type embeddings,
  contrastive projections and temperatures.
* ``language`` — the language model or text tower: input embeddings, decoder or
  encoder layers (including inserted cross-attention layers), final norm.
  For the single-stream ViLT this is the shared transformer plus its text embeddings.
* ``head``     — output projections to the vocabulary or answer space (an untied
  LM head, the VQA classifier, a pooler feeding only the head).
* Janus-Pro's image-GENERATION modules are kept separate (``vision_gen``,
  ``fusion_gen``, ``head_gen``) and aggregated into V / F / Head in Table 2,
  as in the published convention. Chameleon's transformer is ``fused``; its VQ
  image tokenizer is ``vision_tokenizer``.

Changes against the A13 attribution (notebook 24) are deliberate and listed in
notebook 26: Molmo's connector, ViLT's text embeddings, the BLIP-2 / InstructBLIP
language projection, and the LM heads that sat inside L for five models.

Author: Sunita Sahu.
"""

import re
from typing import Dict, Iterable, List, Optional, Tuple

VISION, FUSION, LANGUAGE, HEAD = "vision", "fusion", "language", "head"
VISION_GEN, FUSION_GEN, HEAD_GEN = "vision_gen", "fusion_gen", "head_gen"
FUSED, VISION_TOKENIZER = "fused", "vision_tokenizer"
AUDIO = "audio"   # Gemma 4 12B's audio projection: idle in this image-text protocol, outside V / F / L / H

ATTRIBUTION_RULES: Dict[str, List[Tuple[str, str]]] = {
    "CLIP-ViT-L/14": [
        (r"^(logit_scale|visual_projection|text_projection)", FUSION),
        (r"^vision_model\.", VISION),
        (r"^text_model\.", LANGUAGE),
    ],
    "SigLIP-L/16": [
        (r"^(logit_scale|logit_bias)$", FUSION),
        (r"^vision_model\.", VISION),
        (r"^text_model\.", LANGUAGE),
    ],
    "BLIP-large": [
        (r"^vision_model\.", VISION),
        (r"^text_decoder\.cls\.", HEAD),
        (r"^text_decoder\.", LANGUAGE),
    ],
    "ViLT-B/32": [
        (r"^vilt\.embeddings\.text_embeddings\.", LANGUAGE),
        (r"^vilt\.embeddings\.token_type_embeddings", FUSION),     # modality-type embedding (image vs text)
        (r"^vilt\.embeddings\.", VISION),                          # patch projection, image CLS, image positions
        (r"^vilt\.(encoder|layernorm)\.", LANGUAGE),
        (r"^(vilt\.pooler|classifier)\.", HEAD),
    ],
    "BLIP-2-OPT-2.7B": [
        (r"^(query_tokens|qformer\.|language_projection\.)", FUSION),
        (r"^vision_model\.", VISION),
        (r"^language_model\.lm_head\.", HEAD),
        (r"^language_model\.", LANGUAGE),
    ],
    "LLaVA": [
        (r"^model\.vision_tower\.", VISION),
        (r"^model\.(multi_modal_projector\.|image_newline)", FUSION),
        (r"^lm_head\.", HEAD),
        (r"^model\.language_model\.", LANGUAGE),
    ],
    "Molmo-7B-D": [
        (r"^model\.vision_backbone\.image_vit\.", VISION),
        (r"^model\.vision_backbone\.", FUSION),                    # image_pooling_2d, image_projector, pad_embed
        (r"^model\.transformer\.ff_out\.", HEAD),
        (r"^model\.transformer\.", LANGUAGE),
    ],
    "IDEFICS-9B": [
        (r"^model\.vision_model\.", VISION),
        (r"^model\.perceiver_resampler\.", FUSION),
        (r"^lm_head\.", HEAD),
        (r"^model\.", LANGUAGE),                                   # incl. the 8 gated cross-attention blocks
    ],
    "Llama-3.2-11B-Vision": [
        (r"^model\.vision_model\.", VISION),
        (r"^model\.multi_modal_projector\.", FUSION),
        (r"^lm_head\.", HEAD),
        (r"^model\.language_model\.", LANGUAGE),                   # incl. the 8 cross-attention layers
    ],
    "Idefics2-8B": [
        (r"^model\.vision_model\.", VISION),
        (r"^model\.connector\.", FUSION),
        (r"^lm_head\.", HEAD),
        (r"^model\.text_model\.", LANGUAGE),
    ],
    "Qwen-VL": [
        (r"^model\.visual\.merger\.", FUSION),
        (r"^model\.visual\.", VISION),
        (r"^lm_head\.", HEAD),
        (r"^model\.language_model\.", LANGUAGE),
    ],
    "InternVL3-8B": [
        (r"^vision_model\.", VISION),
        (r"^mlp1\.", FUSION),
        (r"^language_model\.lm_head\.", HEAD),
        (r"^language_model\.", LANGUAGE),
    ],
    "Pixtral-12B": [
        (r"^model\.vision_tower\.", VISION),
        (r"^model\.multi_modal_projector\.", FUSION),
        (r"^lm_head\.", HEAD),
        (r"^model\.language_model\.", LANGUAGE),
    ],
    "DeepSeek-VL2-Small": [
        (r"^vision\.", VISION),
        (r"^(projector\.|image_newline$|view_seperator$)", FUSION),
        (r"^language\.lm_head\.", HEAD),
        (r"^language\.", LANGUAGE),
    ],
    "Chameleon-7B": [
        (r"^model\.vqmodel\.", VISION_TOKENIZER),
        (r"^lm_head\.", HEAD),
        (r"^model\.", FUSED),
    ],
    "Janus-Pro-7B": [
        (r"^vision_model\.", VISION),
        (r"^gen_vision_model\.", VISION_GEN),
        (r"^aligner\.", FUSION),
        (r"^(gen_aligner|gen_embed)\.", FUSION_GEN),
        (r"^gen_head\.", HEAD_GEN),
        (r"^language_model\.lm_head\.", HEAD),
        (r"^language_model\.", LANGUAGE),
    ],
}
ATTRIBUTION_RULES["SigLIP2-So400m/14"] = ATTRIBUTION_RULES["SigLIP-L/16"]
ATTRIBUTION_RULES["InstructBLIP-Vicuna-7B"] = ATTRIBUTION_RULES["BLIP-2-OPT-2.7B"]
for _alias in ("LLaVA-1.5-7B", "LLaVA-NeXT-7B"):
    ATTRIBUTION_RULES[_alias] = ATTRIBUTION_RULES["LLaVA"]
for _alias in ("Qwen2-VL-7B", "Qwen2.5-VL-7B"):
    ATTRIBUTION_RULES[_alias] = ATTRIBUTION_RULES["Qwen-VL"]
# Gemma 4 12B: the checkpoint names the vision embedder "vision_embedder" and the projection
# "embed_vision.embedding_projection"; transformers 5.x loads them as "embed_vision.*" and
# "embed_vision.multimodal_embedder.embedding_projection". Both spellings are matched.
ATTRIBUTION_RULES["Gemma-4-12B"] = [
    (r"^model\.embed_vision\.(multimodal_embedder\.)?embedding_projection", FUSION),
    (r"^model\.(vision_embedder|embed_vision)\.", VISION),   # patch projection, position table, norms
    (r"^model\.embed_audio\.", AUDIO),
    (r"^model\.language_model\.", LANGUAGE),
]
ATTRIBUTION_RULES["Gemma-4-26B-A4B"] = [
    (r"^model\.embed_vision\.", FUSION),
    (r"^model\.vision_tower\.", VISION),
    (r"^model\.language_model\.", LANGUAGE),
]
ATTRIBUTION_RULES["Qwen3-VL-8B"] = [
    (r"^model\.visual\.(merger|deepstack_merger_list)\.", FUSION),   # main merger and the three DeepStack mergers
    (r"^model\.visual\.", VISION),
    (r"^lm_head\.", HEAD),
    (r"^model\.language_model\.", LANGUAGE),
]


# ---------------------------------------------------------------------------
# Final multimodal training stage: which tensors were UPDATED (reviewer item A3).
# Each entry: (regexes of updated tensors, confidence, source summary).
# Everything not matched was frozen in that stage.
# ---------------------------------------------------------------------------
EVERYTHING = [r".*"]
LLAMA_CROSS_ATTENTION_LAYERS = (3, 8, 13, 18, 23, 28, 33, 38)   # cross_attention_layers in the released config

FINAL_STAGE_UPDATED: Dict[str, Tuple[Optional[List[str]], str, str]] = {
    "CLIP-ViT-L/14": (EVERYTHING, "verified", "Radford et al. 2021 Sec. 2.3: trained from scratch, jointly"),
    "SigLIP-L/16": (EVERYTHING, "partially verified", "Zhai et al. 2023 Sec. 4.6: 384-px stage continues both towers"),
    "SigLIP2-So400m/14": (EVERYTHING, "verified", "Tschannen et al. 2025 Sec. 2.4.1"),
    "BLIP-large": (EVERYTHING, "verified", "BLIP COCO captioning fine-tune; official train_caption.py optimises all parameters"),
    "ViLT-B/32": (EVERYTHING, "verified", "Kim et al. 2021 Sec. 4.3; official code fine-tunes all parameters"),
    "BLIP-2-OPT-2.7B": ([r"^(query_tokens|qformer\.|language_projection\.)", r"^vision_model\.post_layernorm\."],
                        "verified", "Li et al. 2023 Sec. 3.3; LAVIS freezes ViT and OPT; ln_vision trained"),
    "InstructBLIP-Vicuna-7B": ([r"^(query_tokens|qformer\.|language_projection\.)", r"^vision_model\.post_layernorm\."],
                               "verified", "Dai et al. 2023 Sec. 2.6; LAVIS keeps llm_proj trainable"),
    "LLaVA-1.5-7B": ([r"^model\.multi_modal_projector\.", r"^model\.language_model\.", r"^lm_head\."],
                     "verified", "Liu et al. 2023 (LLaVA) Sec. 4.2; vision tower identical across 7B/13B releases"),
    "LLaVA-NeXT-7B": (EVERYTHING, "verified", "LLaVA-NeXT blog 2024-01-30: Stage-2 trainable = 'Full model' (vision LR 2e-6)"),
    "Molmo-7B-D": (EVERYTHING, "verified", "Deitke et al. 2024 Sec. 4 and Table 6: all parameters, per-component LRs"),
    "IDEFICS-9B": ([r"^model\.perceiver_resampler\.", r"^model\.gated_cross_attn_layers\."],
                   "verified", "idefics-9b model card: backbones frozen, new parameters trained (base checkpoint)"),
    "Llama-3.2-11B-Vision": ([r"^model\.vision_model\.", r"^model\.multi_modal_projector\.",
                              r"^model\.language_model\.layers\.(" + "|".join(map(str, LLAMA_CROSS_ATTENTION_LAYERS)) + r")\."],
                             "verified (SFT); DPO names only 'vision adapters'",
                             "Llama 3 paper Secs. 7.2, 7.4, 7.5.2; Meta Llama 3.2 blog: LLM never updated"),
    "Idefics2-8B": (EVERYTHING, "verified (backbones low-rank adapted, merged)",
                    "Laurencon et al. 2024 Secs. 3.2, 4.1-4.2: connector full, backbones LoRA/DoRA"),
    "Qwen2-VL-7B": ([r"^model\.visual\.merger\.", r"^model\.language_model\.", r"^lm_head\."],
                    "verified (ViT locked); merger from released weights",
                    "Wang et al. 2024 Sec. 2.2: 'we lock the ViT parameters' in the final stage"),
    "Qwen2.5-VL-7B": ([r"^model\.visual\.merger\.", r"^model\.language_model\.", r"^lm_head\."],
                      "verified (ViT frozen); merger source silent",
                      "Qwen2.5-VL report Sec. 2.3.4: SFT and DPO with the ViT frozen"),
    "InternVL3-8B": (EVERYTHING, "partially verified (paper silent; official MPO script)",
                     "InternVL3 report Sec. 2.2; official internvl3_8b_mpo.sh freezes nothing"),
    "Pixtral-12B": (EVERYTHING, "source silent; released weights differ from base in all components",
                    "Agrawal et al. 2024 (no freezing statement)"),
    "DeepSeek-VL2-Small": (EVERYTHING, "verified", "Wu et al. 2024 Sec. 4.1: all parameters in SFT (vision LR x0.1)"),
    "Chameleon-7B": ([r"^model\.(?!vqmodel\.)", r"^lm_head\."],
                     "partially verified (tokenizer status source silent)",
                     "Chameleon Team 2024 Sec. 3.2; discrete image codes give the tokenizer no gradient"),
    "Janus-Pro-7B": ([r"^(?!gen_vision_model\.)"], "partially verified",
                     "Janus Sec. 3.2 Stage III, restated in Janus-Pro Sec. 2.2: all but the generation encoder"),
    # Roster extension (D9). Evidence: paper/revision_evidence/roster_extension_d9_sources.md; the weight
    # comparisons of pre-trained vs instruction-tuned Gemma 4 tensors were repeated independently.
    "Qwen3-VL-8B": (None, "not found (source silent; no base checkpoint to compare)",
                    "Qwen3-VL report (arXiv 2511.21631) does not say which components its final RL stage updates; "
                    "the trainable share is left unknown"),
    "Gemma-4-12B": (EVERYTHING, "not found (source silent); weights differ from the pre-trained checkpoint in all "
                    "components", "Gemma 4 report Sec. 2.3 (trained from scratch); instruction-tuning stage not described"),
    "Gemma-4-26B-A4B": ([r"^model\.embed_vision\.", r"^model\.language_model\."],
                        "partially verified (report statement; vision encoder bit-identical pre-trained vs instruction-tuned)",
                        "Gemma 4 report Sec. 1: 'Gemma 4 models have frozen vision and audio encoders'"),
}


def attribute_tensor(model: str, tensor_name: str) -> str:
    """Component of one tensor (first matching rule); raises if no rule matches."""
    for pattern, component in ATTRIBUTION_RULES[model]:
        if re.search(pattern, tensor_name):
            return component
    raise KeyError(f"{model}: no attribution rule for {tensor_name}")


def attribute_model(model: str, parameter_shapes: Dict[str, Tuple[int, ...]]) -> Dict[str, object]:
    """Partition every tensor of one model; return component counts, the residual and the trainable count.

    The residual (model total minus the attributed sum) is 0 by construction unless a
    tensor matches no rule, in which case ``attribute_tensor`` raises.
    """
    counts: Dict[str, int] = {}
    trainable = 0
    updated_patterns, _confidence, _source = FINAL_STAGE_UPDATED[model]   # None: not determinable from sources
    for tensor_name, shape in parameter_shapes.items():
        elements = 1
        for dimension in shape:
            elements *= dimension
        component = attribute_tensor(model, tensor_name)
        counts[component] = counts.get(component, 0) + elements
        if updated_patterns is not None and any(re.search(pattern, tensor_name) for pattern in updated_patterns):
            trainable += elements
    total = sum(elements_of(shape) for shape in parameter_shapes.values())
    return {"component_counts": counts, "total": total, "residual": total - sum(counts.values()),
            "trainable": None if updated_patterns is None else trainable}


def elements_of(shape: Iterable[int]) -> int:
    """Number of elements of a tensor shape."""
    elements = 1
    for dimension in shape:
        elements *= dimension
    return elements
