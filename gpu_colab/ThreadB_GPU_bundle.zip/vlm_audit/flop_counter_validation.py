"""Validate the tensor-level cost model against an op-level FLOP counter (reviewer item A5).

For every transformers-native model, a copy of the REAL architecture is built
with a reduced number of layers (two per stack, where the architecture allows),
random weights in bfloat16 on the CPU, and eager attention so that every score
and value product is an explicit matmul. One forward pass is run on the output
of the RELEASED processor for a real image size, inside
``torch.utils.flop_counter.FlopCounterMode``, which records the FLOPs of every
matmul, convolution and attention call per module.

The tensor-level model (``tensor_cost_model.forward_cost_revised``) is then
evaluated on the same reduced parameter layout and the same token account, and
the two are compared component by component. Agreement on the reduced models
validates the routing rules, the token streams and the attention terms; the
full-depth numbers use exactly the same code on the released layouts.

LM heads are compared separately: some forward signatures compute logits for
every position, while the cost model charges the one position that produces
the first generated token.

Author: Sunita Sahu.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .tensor_cost_model import VISION, FUSION, LANGUAGE, CROSS, HEAD, forward_cost_revised
from .token_accounting import TokenAccount, load_processor, synthetic_image, count_image_tokens


@dataclass
class ValidationSpec:
    """How to build, feed and read one reduced-depth validation model.

    Attributes:
        repository: config source (ungated mirror or transformers-native port).
        model_class: transformers class name.
        depth_overrides: dotted config path -> reduced value.
        image_size: (height, width) of the validation image.
        component_modules: component -> module paths (relative to the root) whose
            inclusive FLOPs are added; prefix a path with "-" to subtract it.
        processor_kwargs: extra processor arguments (e.g. disable image splitting).
        forward_kwargs: extra forward arguments (e.g. logits_to_keep).
        rebuild_config_from_json: apply the depth overrides to the released config.json and
            construct the configuration from it, for configurations that derive per-layer
            tables from the layer count at construction (Gemma 4: head size and key/value
            heads of the global layers); overriding the loaded object would leave them stale.
        model_kwargs: extra arguments for ``_from_config`` (Gemma 4 26B-A4B: the eager expert
            loop, whose matrix products the op-level counter sees; the default grouped kernel
            is invisible to it).
    """

    repository: str
    model_class: str
    depth_overrides: Dict[str, object]
    image_size: Tuple[int, int]
    component_modules: Dict[str, List[str]]
    processor_kwargs: Dict[str, object] = field(default_factory=dict)
    forward_kwargs: Dict[str, object] = field(default_factory=dict)
    qwen25_full_attention_layers: Optional[int] = None
    rebuild_config_from_json: bool = False
    model_kwargs: Dict[str, object] = field(default_factory=dict)


TWO_LAYERS = {"vision_config.num_hidden_layers": 2, "text_config.num_hidden_layers": 2}

VALIDATION_SPECS: Dict[str, ValidationSpec] = {
    "CLIP-ViT-L/14": ValidationSpec(
        "openai/clip-vit-large-patch14", "CLIPModel", TWO_LAYERS, (224, 224),
        {VISION: ["vision_model"], FUSION: ["visual_projection", "text_projection"], LANGUAGE: ["text_model"]}),
    "SigLIP-L/16": ValidationSpec(
        "google/siglip-large-patch16-384", "SiglipModel", TWO_LAYERS, (384, 384),
        {VISION: ["vision_model"], LANGUAGE: ["text_model"]}, processor_kwargs={"padding": "max_length"}),
    "SigLIP2-So400m/14": ValidationSpec(
        "google/siglip2-so400m-patch14-384", "SiglipModel", TWO_LAYERS, (384, 384),
        {VISION: ["vision_model"], LANGUAGE: ["text_model"]}, processor_kwargs={"padding": "max_length"}),
    "BLIP-large": ValidationSpec(
        "Salesforce/blip-image-captioning-large", "BlipForConditionalGeneration", TWO_LAYERS, (384, 384),
        {VISION: ["vision_model"], LANGUAGE: ["text_decoder.bert"], HEAD: ["text_decoder.cls"]}),
    "ViLT-B/32": ValidationSpec(
        "dandelin/vilt-b32-finetuned-vqa", "ViltForQuestionAnswering", {"num_hidden_layers": 2}, (384, 384),
        {VISION: ["vilt.embeddings"], LANGUAGE: ["vilt.encoder"], HEAD: ["vilt.pooler", "classifier"]}),
    "BLIP-2-OPT-2.7B": ValidationSpec(
        "Salesforce/blip2-opt-2.7b", "Blip2ForConditionalGeneration",
        {"vision_config.num_hidden_layers": 2, "qformer_config.num_hidden_layers": 2, "text_config.num_hidden_layers": 2},
        (224, 224), {VISION: ["vision_model"], FUSION: ["qformer", "language_projection"],
                     LANGUAGE: ["language_model.model"], HEAD: ["language_model.lm_head"]}),
    "InstructBLIP-Vicuna-7B": ValidationSpec(
        "Salesforce/instructblip-vicuna-7b", "InstructBlipForConditionalGeneration",
        {"vision_config.num_hidden_layers": 2, "qformer_config.num_hidden_layers": 2, "text_config.num_hidden_layers": 2},
        (224, 224), {VISION: ["vision_model"], FUSION: ["qformer", "language_projection"],
                     LANGUAGE: ["language_model.model"], HEAD: ["language_model.lm_head"]}),
    "LLaVA-1.5-7B": ValidationSpec(
        "llava-hf/llava-1.5-7b-hf", "LlavaForConditionalGeneration", TWO_LAYERS, (336, 336),
        {VISION: ["model.vision_tower"], FUSION: ["model.multi_modal_projector"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "LLaVA-NeXT-7B": ValidationSpec(
        "llava-hf/llava-v1.6-mistral-7b-hf", "LlavaNextForConditionalGeneration", TWO_LAYERS, (1024, 1024),
        {VISION: ["model.vision_tower"], FUSION: ["model.multi_modal_projector"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "IDEFICS-9B": ValidationSpec(
        "HuggingFaceM4/idefics-9b", "IdeficsForVisionText2Text",
        {"num_hidden_layers": 4, "vision_config.num_hidden_layers": 2, "perceiver_config.resampler_depth": 1}, (224, 224),
        {VISION: ["model.vision_model"], FUSION: ["model.perceiver_resampler"],
         LANGUAGE: ["model.layers", "model.gated_cross_attn_layers"], HEAD: ["lm_head"]}),
    "Llama-3.2-11B-Vision": ValidationSpec(
        "unsloth/Llama-3.2-11B-Vision-Instruct", "MllamaForConditionalGeneration",
        {"vision_config.num_hidden_layers": 5, "vision_config.num_global_layers": 1,
         "vision_config.intermediate_layers_indices": [0, 1, 2, 3, 4],
         "text_config.num_hidden_layers": 2, "text_config.cross_attention_layers": [1]}, (1024, 1024),
        {VISION: ["model.vision_model"], FUSION: ["model.multi_modal_projector"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "Idefics2-8B": ValidationSpec(
        "HuggingFaceM4/idefics2-8b", "Idefics2ForConditionalGeneration",
        {"vision_config.num_hidden_layers": 2, "perceiver_config.resampler_depth": 1, "text_config.num_hidden_layers": 2},
        (980, 980), {VISION: ["model.vision_model"], FUSION: ["model.connector"],
                     LANGUAGE: ["model.text_model"], HEAD: ["lm_head"]},
        processor_kwargs={"do_image_splitting": False}, forward_kwargs={"logits_to_keep": 1}),
    "Qwen2-VL-7B": ValidationSpec(
        "Qwen/Qwen2-VL-7B-Instruct", "Qwen2VLForConditionalGeneration",
        {"vision_config.depth": 2, "text_config.num_hidden_layers": 2, "num_hidden_layers": 2}, (448, 448),
        {VISION: ["model.visual", "-model.visual.merger"], FUSION: ["model.visual.merger"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "Qwen2.5-VL-7B": ValidationSpec(
        "Qwen/Qwen2.5-VL-7B-Instruct", "Qwen2_5_VLForConditionalGeneration",
        {"vision_config.depth": 2, "vision_config.fullatt_block_indexes": [1], "text_config.num_hidden_layers": 2,
         "num_hidden_layers": 2}, (448, 448),
        {VISION: ["model.visual", "-model.visual.merger"], FUSION: ["model.visual.merger"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1},
        qwen25_full_attention_layers=1),
    "Qwen3-VL-8B": ValidationSpec(
        "Qwen/Qwen3-VL-8B-Instruct", "Qwen3VLForConditionalGeneration",
        {"vision_config.depth": 2, "vision_config.deepstack_visual_indexes": [0, 1],
         "text_config.num_hidden_layers": 2}, (448, 448),
        # The container path covers every DeepStack merger, however many the config has: two in this
        # reduced copy, three in the release. Naming them one by one missed the third at full depth.
        {VISION: ["model.visual", "-model.visual.merger", "-model.visual.deepstack_merger_list"],
         FUSION: ["model.visual.merger", "model.visual.deepstack_merger_list"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "InternVL3-8B": ValidationSpec(
        "OpenGVLab/InternVL3-8B-hf", "InternVLForConditionalGeneration", TWO_LAYERS, (1024, 1024),
        {VISION: ["model.vision_tower"], FUSION: ["model.multi_modal_projector"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "Pixtral-12B": ValidationSpec(
        "mistral-community/pixtral-12b", "LlavaForConditionalGeneration", TWO_LAYERS, (512, 512),
        {VISION: ["model.vision_tower"], FUSION: ["model.multi_modal_projector"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
    "Chameleon-7B": ValidationSpec(
        "FriendliAI/chameleon-7b", "ChameleonForConditionalGeneration", {"num_hidden_layers": 2}, (512, 512),
        {VISION: ["model.vqmodel"], LANGUAGE: ["model", "-model.vqmodel"], HEAD: ["lm_head"]},
        forward_kwargs={"logits_to_keep": 1}),
    "Janus-Pro-7B": ValidationSpec(
        "deepseek-community/Janus-Pro-7B", "JanusForConditionalGeneration", TWO_LAYERS, (384, 384),
        {VISION: ["model.vision_model"], FUSION: ["model.aligner"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1}),
}

PLACEHOLDER_FOR_VALIDATION = {
    "CLIP-ViT-L/14": "", "SigLIP-L/16": "", "BLIP-large": "", "ViLT-B/32": "", "BLIP-2-OPT-2.7B": "",
    "InstructBLIP-Vicuna-7B": "", "IDEFICS-9B": None,
}


# Models whose architecture needs transformers >= 5.5 (Gemma 4). Kept apart from VALIDATION_SPECS so that
# the transformers 4.57 notebooks (27, 29) never try to build them; validated and timed in a 5.x environment.
GEMMA4_TWO_LAYER_TEXT = {"text_config.num_hidden_layers": 2,
                         "text_config.layer_types": ["sliding_attention", "full_attention"]}
TRANSFORMERS5_VALIDATION_SPECS: Dict[str, ValidationSpec] = {
    "Gemma-4-12B": ValidationSpec(
        "google/gemma-4-12B-it", "Gemma4UnifiedForConditionalGeneration", GEMMA4_TWO_LAYER_TEXT, (448, 448),
        {VISION: ["model.embed_vision", "-model.embed_vision.multimodal_embedder"],
         FUSION: ["model.embed_vision.multimodal_embedder"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1},
        rebuild_config_from_json=True),
    "Gemma-4-26B-A4B": ValidationSpec(
        "google/gemma-4-26B-A4B-it", "Gemma4ForConditionalGeneration",
        dict(GEMMA4_TWO_LAYER_TEXT, **{"vision_config.num_hidden_layers": 2}), (448, 448),
        {VISION: ["model.vision_tower"], FUSION: ["model.embed_vision"],
         LANGUAGE: ["model.language_model"], HEAD: ["lm_head"]}, forward_kwargs={"logits_to_keep": 1},
        rebuild_config_from_json=True, model_kwargs={"experts_implementation": "eager"}),
}


def validation_spec(model_name: str) -> ValidationSpec:
    """The validation spec of any roster model (transformers 4.57 or 5.x)."""
    if model_name in VALIDATION_SPECS:
        return VALIDATION_SPECS[model_name]
    return TRANSFORMERS5_VALIDATION_SPECS[model_name]


def _reduced_config_from_json(spec: ValidationSpec):
    """Configuration built from the released config.json with the depth overrides applied to the raw values."""
    import json
    from huggingface_hub import hf_hub_download
    from transformers import AutoConfig

    with open(hf_hub_download(spec.repository, "config.json"), encoding="utf-8") as handle:
        raw_config = json.load(handle)
    for dotted_path, value in spec.depth_overrides.items():
        *parents, key = dotted_path.split(".")
        container = raw_config
        for parent in parents:
            container = container[parent]
        container[key] = value
    return type(AutoConfig.from_pretrained(spec.repository)).from_dict(raw_config)


def _set_config_value(configuration, dotted_path: str, value) -> None:
    """Set ``a.b.c`` on a (nested) transformers config."""
    *parents, leaf = dotted_path.split(".")
    target = configuration
    for parent in parents:
        target = getattr(target, parent)
    setattr(target, leaf, value)


def reduced_configuration(model_name: str):
    """The released configuration with the depth overrides of the validation spec."""
    from transformers import AutoConfig

    spec = validation_spec(model_name)
    if spec.rebuild_config_from_json:
        return _reduced_config_from_json(spec)
    configuration = AutoConfig.from_pretrained(spec.repository)
    for dotted_path, value in spec.depth_overrides.items():
        parent_path = dotted_path.rsplit(".", 1)[0] if "." in dotted_path else None
        try:
            if parent_path is None or getattr(configuration, parent_path.split(".")[0], None) is not None:
                _set_config_value(configuration, dotted_path, value)
        except AttributeError:
            pass
    return configuration


def build_reduced_model(model_name: str):
    """Instantiate the reduced-depth real architecture (random bf16 weights, eager attention, CPU)."""
    import torch
    import transformers

    spec = validation_spec(model_name)
    configuration = reduced_configuration(model_name)
    model_class = getattr(transformers, spec.model_class)
    torch.manual_seed(0)
    model = model_class._from_config(configuration, attn_implementation="eager", dtype=torch.bfloat16,
                                     **spec.model_kwargs)
    model.requires_grad_(False)   # the counter's module tracker expects no autograd state under no_grad
    return model.to(torch.bfloat16).eval()   # sub-configs may carry their own dtype; unify


def build_validation_inputs(model_name: str, image_size: Optional[Tuple[int, int]] = None,
                            processor_kwargs: Optional[Dict[str, object]] = None, image=None):
    """Processor outputs for one input image (bf16 pixel values).

    Args:
        model_name: roster name (key of ``VALIDATION_SPECS``).
        image_size: (height, width); defaults to the validation image size of the spec.
        processor_kwargs: processor arguments; defaults to the validation overrides of the
            spec (the GPU latency run passes the released defaults instead).
        image: a PIL image to use instead of the uniform synthetic one.
    """
    import torch

    spec = validation_spec(model_name)
    height, width = image_size or spec.image_size
    extra_kwargs = spec.processor_kwargs if processor_kwargs is None else processor_kwargs
    processor = load_processor(model_name) if model_name in _PROCESSOR_FROM_ACCOUNTING else _load_other_processor(spec)
    image = synthetic_image(height, width) if image is None else image
    prompt = "Describe this image in detail."
    if model_name == "IDEFICS-9B":
        batch = processor(text=[[prompt, image]], return_tensors="pt")
    elif model_name in ("CLIP-ViT-L/14", "SigLIP-L/16", "SigLIP2-So400m/14", "BLIP-large", "ViLT-B/32",
                        "BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B"):
        batch = processor(text=prompt, images=image, return_tensors="pt", **extra_kwargs)
    else:
        from .token_accounting import PLACEHOLDER
        batch = processor(text=f"{PLACEHOLDER[model_name]} {prompt}", images=image, return_tensors="pt",
                          **extra_kwargs)
    for key, value in batch.items():
        if hasattr(value, "dtype") and value.dtype == torch.float32:
            batch[key] = value.to(torch.bfloat16)
    if model_name == "InstructBLIP-Vicuna-7B" and batch["pixel_values"].dim() == 5:
        batch["pixel_values"] = batch["pixel_values"].flatten(0, 1)   # one image per sample
    return batch


_PROCESSOR_FROM_ACCOUNTING = {"LLaVA-1.5-7B", "LLaVA-NeXT-7B", "Llama-3.2-11B-Vision", "Idefics2-8B", "Qwen2-VL-7B",
                              "Qwen2.5-VL-7B", "Qwen3-VL-8B", "Gemma-4-12B", "Gemma-4-26B-A4B", "InternVL3-8B", "Pixtral-12B", "Chameleon-7B", "Janus-Pro-7B", "ViLT-B/32"}


# Processor classes pinned where AutoProcessor resolves to the wrong one. The released
# Salesforce/instructblip-vicuna-7b repo declares "InstructBlipVideoProcessor" in its
# processor_config.json: it treats one image as a clip (5-D pixel values) and inserts
# 128 "<video>" placeholders, which InstructBlipForConditionalGeneration does not
# recognise (it scatters the 32 Q-Former outputs into "<image>" positions), so the
# language model silently runs without the image. Found by the GPU latency run (N20).
PROCESSOR_CLASS_OVERRIDES = {"Salesforce/instructblip-vicuna-7b": "InstructBlipProcessor"}


def _load_other_processor(spec: ValidationSpec):
    """Processor for models not used by token_accounting's processor route."""
    import transformers
    from transformers import AutoProcessor

    class_name = PROCESSOR_CLASS_OVERRIDES.get(spec.repository)
    if class_name is not None:
        return getattr(transformers, class_name).from_pretrained(spec.repository)
    return AutoProcessor.from_pretrained(spec.repository)


def measure_component_flops(model_name: str, model, batch) -> Tuple[Dict[str, float], float, Dict[str, float]]:
    """Run one forward pass under FlopCounterMode; return (component FLOPs, total FLOPs, raw module FLOPs)."""
    import torch
    from torch.utils.flop_counter import FlopCounterMode

    spec = validation_spec(model_name)
    counter = FlopCounterMode(display=False)
    with torch.no_grad(), counter:
        model(**batch, **spec.forward_kwargs)
    root = type(model).__name__
    module_flops = {name: float(sum(operations.values())) for name, operations in counter.get_flop_counts().items()}
    components = {}
    for component, paths in spec.component_modules.items():
        total = 0.0
        for path in paths:
            sign = -1.0 if path.startswith("-") else 1.0
            total += sign * inclusive_module_flops(module_flops, f"{root}.{path.lstrip('-')}")
        components[component] = total
    return components, float(counter.get_total_flops()), module_flops


def inclusive_module_flops(module_flops: Dict[str, float], key: str) -> float:
    """Inclusive FLOPs of one module path.

    The counter records only modules that are *called*; containers such as a
    ModuleList, or a wrapper whose forward is bypassed, have no entry. In that
    case the called children one level down are summed.
    """
    if key in module_flops:
        return module_flops[key]
    depth = key.count(".") + 1
    return sum(value for name, value in module_flops.items()
               if name.startswith(key + ".") and name.count(".") == depth)


def validation_token_account(model_name: str, batch, model=None,
                             image_size: Optional[Tuple[int, int]] = None) -> TokenAccount:
    """Token account of the EXECUTED input (same rules as token_accounting).

    ``image_size`` is the (height, width) of the image given to the processor; it
    defaults to the validation image size of the spec.
    """
    from .token_accounting import account_visual_tokens

    spec = validation_spec(model_name)
    height, width = image_size or spec.image_size
    if model_name == "Idefics2-8B":
        # The reference implementation pads every sub-image to the largest one and runs the
        # padded patches through the encoder and connector; validate against what it executes.
        sub_images, padded_height, padded_width = (int(batch["pixel_values"].shape[index]) for index in (1, 3, 4))
        patches = (padded_height // 14) * (padded_width // 14)
        return TokenAccount(model=model_name, image_height=height, image_width=width,
                            encoder_sequences=[patches] * sub_images, patch_positions=patches * sub_images,
                            fusion_input_tokens=patches * sub_images, fusion_output_tokens=64 * sub_images,
                            language_visual_tokens=count_image_tokens(model_name, batch["input_ids"][0]))
    if model_name == "Llama-3.2-11B-Vision":
        # Executed: every tile slot (4) is run, and each tile's 1,601 tokens are padded to 1,608.
        tile_slots = int(batch["pixel_values"].shape[2])
        return TokenAccount(model=model_name, image_height=height, image_width=width,
                            encoder_sequences=[1608] * tile_slots, patch_positions=1600 * tile_slots,
                            fusion_input_tokens=1601 * tile_slots, fusion_output_tokens=1601 * tile_slots,
                            cross_attended_tokens=1601 * tile_slots)
    if model_name in ("Gemma-4-12B", "Gemma-4-26B-A4B"):
        # Executed: the padded patch slots of the processor (encoder / embedder and, for 26B, the pooling product).
        from .token_accounting import account_gemma4
        return account_gemma4(model_name, height, width, executed=True)
    account = account_visual_tokens(model_name, height, width)
    if model_name == "InstructBLIP-Vicuna-7B":
        account.details["qformer_instruction_tokens"] = int(batch["qformer_input_ids"].shape[1])
    return account


def executed_text_tokens(model_name: str, batch, account: TokenAccount) -> int:
    """Text tokens actually fed to the language side of the validation input."""
    sequence_length = int(batch["input_ids"].shape[1])
    if model_name in ("BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B"):
        # The processor already expanded the 32 query placeholders into input_ids.
        return sequence_length - account.language_visual_tokens
    if account.language_visual_tokens and model_name != "ViLT-B/32":
        return sequence_length - account.language_visual_tokens
    return sequence_length


def validate_model(model_name: str, measured_encoder_gflops: float = 0.0) -> Dict[str, object]:
    """Measured vs predicted FLOPs per component for one reduced-depth model."""
    model = build_reduced_model(model_name)
    batch = build_validation_inputs(model_name)
    measured, measured_total, module_flops = measure_component_flops(model_name, model, batch)
    account = validation_token_account(model_name, batch, model)
    text_tokens = executed_text_tokens(model_name, batch, account)
    shapes = {name: tuple(parameter.shape) for name, parameter in model.named_parameters()}
    spec = validation_spec(model_name)
    extra = {}
    if spec.qwen25_full_attention_layers is not None:
        extra["qwen25_full_attention_layers"] = spec.qwen25_full_attention_layers
    if model_name == "Chameleon-7B":
        extra["measured_encoder_gflops"] = measured[VISION] / 1e9
    predicted = forward_cost_revised(model_name, shapes, account, text_tokens=text_tokens, **extra)
    predicted_components = {
        VISION: predicted.encoder_g * 1e9,
        FUSION: predicted.fusion_g * 1e9,
        LANGUAGE: (predicted.llm_visual_g + predicted.llm_text_g) * 1e9,
        HEAD: predicted.head_g * 1e9,
    }
    rows = []
    for component in (VISION, FUSION, LANGUAGE):
        if component not in measured and predicted_components[component] == 0:
            continue
        measured_value = measured.get(component, 0.0)
        predicted_value = predicted_components[component]
        rows.append({"model": model_name, "component": component, "measured_gflops": measured_value / 1e9,
                     "predicted_gflops": predicted_value / 1e9,
                     "relative_difference_pct": 100 * (predicted_value - measured_value) / measured_value
                     if measured_value else float("nan")})
    del model
    return {"rows": rows, "account": account, "text_tokens": text_tokens, "measured_total_gflops": measured_total / 1e9,
            "measured_head_gflops": measured.get(HEAD, 0.0) / 1e9, "predicted_head_gflops": predicted.head_g,
            "layer_counts": predicted.layer_counts, "unrouted": predicted.unrouted_parameters,
            "module_flops": module_flops}


# ---------------------------------------------------------------------------
# Element-wise work omitted by the matmul count (reviewer item A5 (i))
# ---------------------------------------------------------------------------

# FLOPs charged per OUTPUT element for fused kernels that do several operations;
# every other floating-point aten op is charged 1 per output element. Matmul,
# convolution and attention-product ops are excluded (they are the counted part),
# as are pure data movement and creation ops.
FUSED_KERNEL_COST = {"native_layer_norm": 8, "_softmax": 5, "gelu": 8, "silu": 4, "_safe_softmax": 5,
                     "native_group_norm": 8, "rsqrt": 2, "sigmoid": 4, "tanh": 4, "exp": 2, "erf": 4}
COUNTED_ELSEWHERE = {"mm", "addmm", "bmm", "baddbmm", "convolution", "matmul", "linear",
                     "_scaled_dot_product_efficient_attention", "_scaled_dot_product_flash_attention",
                     "_scaled_dot_product_flash_attention_for_cpu", "_scaled_dot_product_cudnn_attention"}
DATA_MOVEMENT = {"view", "_unsafe_view", "reshape", "permute", "transpose", "t", "expand", "clone", "contiguous",
                 "copy_", "_to_copy", "cat", "stack", "slice", "select", "index", "index_select", "embedding",
                 "split", "split_with_sizes", "unsqueeze", "squeeze", "flatten", "unflatten", "detach", "alias",
                 "zeros", "ones", "empty", "full", "arange", "new_zeros", "new_ones", "new_empty", "zero_", "fill_",
                 "masked_fill", "masked_fill_", "masked_scatter", "where", "constant_pad_nd", "pad", "repeat",
                 "gather", "scatter", "lift_fresh", "_unsafe_index", "index_put_", "repeat_interleave", "unbind",
                 "as_strided", "narrow", "roll", "flip", "lt", "gt", "le", "ge", "eq", "ne", "logical_not",
                 "logical_and", "bitwise_and", "bitwise_or", "bitwise_not", "any", "all", "argmax", "nonzero",
                 "_local_scalar_dense", "item", "sort", "topk", "cumsum", "triu", "tril", "ones_like",
                 "zeros_like", "full_like", "empty_like", "rand", "randn", "bernoulli_", "native_dropout", "dropout"}


def count_elementwise_flops(model, batch, forward_kwargs) -> float:
    """Element-wise FLOPs of one forward pass (dispatch-level count; see FUSED_KERNEL_COST)."""
    return elementwise_flops_of(lambda: model(**batch, **forward_kwargs))


def elementwise_flops_of(run_once) -> float:
    """Element-wise FLOPs of whatever ``run_once`` executes (dispatch-level count; see FUSED_KERNEL_COST)."""
    import torch
    from torch.utils._python_dispatch import TorchDispatchMode

    class ElementwiseCounter(TorchDispatchMode):
        """Accumulates per-output-element costs of non-matmul floating-point ops."""

        def __init__(self):
            super().__init__()
            self.flops = 0.0

        def __torch_dispatch__(self, func, types, args=(), kwargs=None):
            output = func(*args, **(kwargs or {}))
            operation = func.overloadpacket.__name__
            if operation in COUNTED_ELSEWHERE or operation in DATA_MOVEMENT:
                return output
            first = output[0] if isinstance(output, (tuple, list)) else output
            if isinstance(first, torch.Tensor) and first.is_floating_point():
                self.flops += FUSED_KERNEL_COST.get(operation.rstrip("_"), 1) * first.numel()
            return output

    counter = ElementwiseCounter()
    with torch.no_grad(), counter:
        run_once()
    return counter.flops


def measure_elementwise_share(model_name: str) -> Dict[str, float]:
    """Element-wise FLOPs as a share of (matmul + element-wise) FLOPs on the reduced-depth model.

    Both parts scale with depth in the same way, so the share of the reduced model
    approximates the share of the released model at the same input.
    """
    import torch
    from torch.utils.flop_counter import FlopCounterMode

    model = build_reduced_model(model_name)
    batch = build_validation_inputs(model_name)
    spec = validation_spec(model_name)
    counter = FlopCounterMode(display=False)
    with torch.no_grad(), counter:
        model(**batch, **spec.forward_kwargs)
    matmul_flops = float(counter.get_total_flops())
    elementwise_flops = count_elementwise_flops(model, batch, spec.forward_kwargs)
    del model
    return {"model": model_name, "matmul_gflops": matmul_flops / 1e9, "elementwise_gflops": elementwise_flops / 1e9,
            "elementwise_share_pct": 100 * elementwise_flops / (matmul_flops + elementwise_flops)}
