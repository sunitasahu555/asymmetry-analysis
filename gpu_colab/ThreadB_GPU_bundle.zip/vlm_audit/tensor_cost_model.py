"""Tensor-level analytic forward cost (revised compute protocol; reviewer items A5, A7, A9).

The published protocol (``analytic_compute.py``) priced each component as
``2·P·N + 4·L·N²·d`` with one aggregate parameter count P and one token count N.
That is exact only when every weight of the component multiplies the same N
tokens. On this roster it is not:

* embedding tables and LM heads were inside P for some models (no matmul per token);
* cross-attention key/value projections act on the visual tokens, with their real
  input/output widths (Llama-3.2-Vision uses grouped-query K/V of width 1,024;
  IDEFICS-9B projects from the 1,280-wide perceiver output), not a d x d matrix;
* fusion modules act on their input tokens (Q-Former and perceiver K/V, Idefics2's
  modality projection) as well as on the tokens they emit;
* mixture-of-experts layers activate 6 of 64 routed experts per token;
* tiled encoders attend within each tile, Qwen2.5-VL's ViT mostly within 8 x 8 windows.

The revised model charges **every weight matrix 2 FLOPs per element per token it
actually multiplies** (convolutions: per output position) and adds the attention
score and value-mixing products **per independent attention sequence**:
``2·n_query·n_key·(width_qk + width_v)`` per layer. These are exactly the
operations an op-level counter records (matmul, convolution, attention), which
is how the model is validated (notebook 26, ``torch.utils.flop_counter`` on
reduced-depth instantiations of the real architectures). Element-wise work
(normalisation, activations, softmax, residuals, rotary embeddings) is not in
this count; ``omitted_elementwise_flops`` bounds it separately.

Token routing: each parameter is mapped, by the first matching regular
expression in ``ROUTING_RULES[model]``, to a component and a *stream* whose
token count comes from the model's ``TokenAccount``.

Author: Sunita Sahu.
"""

from dataclasses import dataclass, field
import re
from typing import Dict, List, Optional, Tuple

from .token_accounting import TokenAccount

GIGA = 1e9

# Components used for reporting.
VISION, FUSION, LANGUAGE, CROSS, HEAD, IDLE = "vision", "fusion", "language", "cross", "head", "idle"


@dataclass
class AttentionSpec:
    """Attention products of one group of identical layers.

    ``sequences`` holds (query tokens, key tokens) for every independent attention
    computation in ONE layer (e.g. one entry per tile); the cost is multiplied by
    ``layers``. ``width_qk`` / ``width_value`` are heads x head-dim of the score and
    value products (they differ only for DeepSeek-VL2's latent attention).
    """

    component: str
    layers: int
    sequences: List[Tuple[int, int]]
    width_qk: int
    width_value: int
    label: str = ""

    def flops(self) -> float:
        """Score (QK^T) plus value-mixing (AV) FLOPs over all layers."""
        per_layer = sum(2 * queries * keys * (self.width_qk + self.width_value) for queries, keys in self.sequences)
        return self.layers * per_layer


@dataclass
class CostBreakdown:
    """Revised Table 3 row for one model plus the audit trail behind it."""

    model: str
    encoder_g: float
    fusion_g: float
    llm_visual_g: float
    llm_text_g: float
    head_g: float
    total_g: float
    vision_compute_share_pct: float
    vision_attributable_pct: float
    matmul_by_component_g: Dict[str, float] = field(default_factory=dict)
    attention_by_component_g: Dict[str, float] = field(default_factory=dict)
    stream_tokens: Dict[str, float] = field(default_factory=dict)
    unrouted_parameters: List[str] = field(default_factory=list)
    idle_parameters: int = 0
    layer_counts: Dict[str, int] = field(default_factory=dict)

    def to_row(self) -> Dict[str, float]:
        """The Table 3 columns."""
        return {
            "encoder_g": self.encoder_g, "fusion_g": self.fusion_g, "llm_visual_g": self.llm_visual_g,
            "llm_text_g": self.llm_text_g, "head_g": self.head_g, "total_g": self.total_g,
            "vision_compute_share_pct": self.vision_compute_share_pct,
            "vision_attributable_pct": self.vision_attributable_pct,
        }


# ---------------------------------------------------------------------------
# Routing rules: (regex on the parameter name, component, stream). First match wins.
# Streams: encoder, patch, fusion_in, fusion_out, sequence, text, cross_kv, pooled,
# last (LM head on the one position that produces the first generated token), zero,
# plus a few model-specific streams resolved in ``stream_token_counts``.
# Parameters with fewer than two dimensions are element-wise (biases, norms, gates)
# and are never charged here.
# ---------------------------------------------------------------------------

# Lookup and additive tables (no matmul). "positional_embedding" is Molmo's ViT table; before it was
# listed, the 577 x 1,024 table was charged as a matmul (+0.19% of Molmo's encoder, found by the
# full-model FLOP count of notebook 30's dry run).
_EMBEDDINGS = r"(embed_tokens|word_embeddings|token_embedding|position_embedding|positional_embedding|embed_positions|wte|class_embedding|cls_token|position_embeddings|token_type_embeddings|pos_embed|latents|probe|query_tokens|image_newline|view_seperator|pad_embed|tile_embedding|gated_positional_embedding|pre_tile_positional_embedding|post_tile_positional_embedding|additional_embedding|quantize\.embedding)"

ROUTING_RULES: Dict[str, List[Tuple[str, str, str]]] = {
    "CLIP-ViT-L/14": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^vision_model\.", VISION, "encoder"),
        (r"^visual_projection", FUSION, "pooled"),
        (r"^text_projection", FUSION, "pooled"),
        (r"^text_model\.", LANGUAGE, "text"),
    ],
    "SigLIP-L/16": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^vision_model\.head\.attention\.in_proj_weight", VISION, "siglip_head_qkv"),
        (r"^vision_model\.head\.", VISION, "pooled"),
        (r"^vision_model\.", VISION, "encoder"),
        (r"^text_model\.head", LANGUAGE, "pooled"),
        (r"^text_model\.", LANGUAGE, "text"),
    ],
    "BLIP-large": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^vision_model\.", VISION, "encoder"),
        (r"crossattention\.self\.(key|value)", CROSS, "cross_kv"),
        (r"^text_decoder\.cls\.", HEAD, "last"),
        (r"^text_decoder\.", LANGUAGE, "text"),
    ],
    "ViLT-B/32": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"patch_embeddings\.projection", VISION, "patch"),
        (r"^vilt\.encoder\.", LANGUAGE, "sequence"),
        (r"^vilt\.pooler\.", HEAD, "pooled"),
        (r"^classifier\.", HEAD, "pooled"),
    ],
    "BLIP-2-OPT-2.7B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^vision_model\.", VISION, "encoder"),
        (r"crossattention\.attention\.(key|value)", FUSION, "fusion_in"),
        (r"^qformer\.", FUSION, "fusion_out"),
        (r"^language_projection", FUSION, "fusion_out"),
        (r"^language_model\.lm_head", HEAD, "last"),
        (r"^language_model\.", LANGUAGE, "sequence"),
    ],
    "LLaVA": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"vision_tower\.vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"vision_tower\.", VISION, "encoder"),
        (r"multi_modal_projector\.", FUSION, "fusion_in"),
        (r"^lm_head", HEAD, "last"),
        (r"language_model\.", LANGUAGE, "sequence"),
    ],
    "Molmo-7B-D": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"image_vit\.patch_embedding", VISION, "patch"),
        (r"image_vit\.", VISION, "encoder"),
        (r"image_pooling_2d\.(wk|wv)", FUSION, "fusion_in"),
        (r"image_pooling_2d\.(wq|wo)", FUSION, "fusion_out"),
        (r"image_projector\.", FUSION, "fusion_out"),
        (r"^model\.transformer\.ff_out", HEAD, "last"),
        (r"^model\.transformer\.", LANGUAGE, "sequence"),
    ],
    "IDEFICS-9B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^model\.vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^model\.vision_model\.", VISION, "encoder"),
        (r"perceiver_resampler\.blocks\.#\.#\.(k_proj|v_proj)", FUSION, "perceiver_kv"),
        (r"^model\.perceiver_resampler\.", FUSION, "fusion_out"),
        (r"gated_cross_attn_layers\.#\.cross_attn\.(k_proj|v_proj)", CROSS, "cross_kv"),
        (r"^lm_head", HEAD, "last"),
        (r"^model\.", LANGUAGE, "text"),
    ],
    "Llama-3.2-11B-Vision": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^model\.vision_model\.patch_embedding", VISION, "patch"),
        (r"^model\.vision_model\.", VISION, "encoder"),
        (r"^model\.multi_modal_projector", FUSION, "fusion_in"),
        (r"cross_attn\.(k_proj|v_proj)", CROSS, "cross_kv"),
        (r"^lm_head", HEAD, "last"),
        (r"^model\.language_model\.", LANGUAGE, "text"),
    ],
    "Idefics2-8B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"vision_model\.", VISION, "encoder"),
        (r"connector\.modality_projection\.", FUSION, "fusion_in"),
        (r"perceiver_resampler\.layers\.#\.self_attn\.(k_proj|v_proj)", FUSION, "perceiver_kv"),
        (r"connector\.perceiver_resampler\.", FUSION, "fusion_out"),
        (r"^lm_head", HEAD, "last"),
        (r"text_model\.", LANGUAGE, "sequence"),
    ],
    "Qwen-VL": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"visual\.patch_embed", VISION, "patch"),
        (r"visual\.merger\.", FUSION, "fusion_out"),
        (r"visual\.", VISION, "encoder"),
        (r"^lm_head", HEAD, "last"),
        (r"language_model\.", LANGUAGE, "sequence"),
    ],
    "InternVL3-8B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^vision_model\.", VISION, "encoder"),
        (r"^mlp1\.", FUSION, "fusion_in"),
        (r"^language_model\.lm_head", HEAD, "last"),
        (r"^language_model\.", LANGUAGE, "sequence"),
        # transformers-native port (OpenGVLab/InternVL3-8B-hf), used for validation
        (r"vision_tower\.embeddings\.patch_embeddings", VISION, "patch"),
        (r"vision_tower\.", VISION, "encoder"),
        (r"multi_modal_projector\.", FUSION, "fusion_in"),
        (r"^lm_head", HEAD, "last"),
        (r"model\.language_model\.", LANGUAGE, "sequence"),
    ],
    "Pixtral-12B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"vision_tower\.patch_conv", VISION, "patch"),
        (r"vision_tower\.", VISION, "encoder"),
        (r"multi_modal_projector\.", FUSION, "fusion_in"),
        (r"^lm_head", HEAD, "last"),
        (r"language_model\.", LANGUAGE, "sequence"),
    ],
    "DeepSeek-VL2-Small": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^vision\.attn_pool\.", IDLE, "zero"),       # SigLIP pooling head, unused by the VL2 adaptor
        (r"^vision\.patch_embed", VISION, "patch"),
        (r"^vision\.", VISION, "encoder"),
        (r"^projector\.", FUSION, "fusion_in"),
        (r"^language\.lm_head", HEAD, "last"),
        (r"mlp\.experts\.#\.", LANGUAGE, "routed_experts"),
        (r"^language\.", LANGUAGE, "sequence"),
    ],
    "Chameleon-7B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^model\.vqmodel\.", VISION, "vq_measured"),    # VQ encoder: conv FLOPs measured, see below
        (r"^lm_head", HEAD, "last"),
        (r"^model\.", LANGUAGE, "sequence"),
    ],
    "Janus-Pro-7B": [
        (_EMBEDDINGS, IDLE, "zero"),
        (r"^(gen_vision_model|gen_aligner|gen_embed|gen_head)\.", IDLE, "zero"),   # generation path idle in VQA
        (r"vision_tower\.attn_pool\.", IDLE, "zero"),   # SigLIP pooling head; patch features are used
        (r"^vision_model\.vision_tower\.patch_embed", VISION, "patch"),
        (r"^vision_model\.", VISION, "encoder"),
        (r"^aligner\.", FUSION, "fusion_in"),
        (r"^language_model\.lm_head", HEAD, "last"),
        (r"^language_model\.", LANGUAGE, "sequence"),
        # transformers-native port (deepseek-community/Janus-Pro-7B), used for validation
        (r"^model\.(vqmodel|generation_)", IDLE, "zero"),
        (r"^model\.vision_model\.embeddings\.patch_embedding", VISION, "patch"),
        (r"^model\.vision_model\.", VISION, "encoder"),
        (r"^model\.aligner\.", FUSION, "fusion_in"),
        (r"^lm_head", HEAD, "last"),
        (r"^model\.language_model\.", LANGUAGE, "sequence"),
    ],
}
ROUTING_RULES["SigLIP2-So400m/14"] = ROUTING_RULES["SigLIP-L/16"]
ROUTING_RULES["InstructBLIP-Vicuna-7B"] = [
    (r"qformer\.encoder\.layer\.#\.(intermediate|output)\.dense", FUSION, "qformer_text"),
    (r"qformer\.encoder\.layer\.#\.attention\.", FUSION, "qformer_joint"),
] + ROUTING_RULES["BLIP-2-OPT-2.7B"]
for _alias in ("LLaVA-1.5-7B", "LLaVA-NeXT-7B"):
    ROUTING_RULES[_alias] = ROUTING_RULES["LLaVA"]
for _alias in ("Qwen2-VL-7B", "Qwen2.5-VL-7B"):
    ROUTING_RULES[_alias] = ROUTING_RULES["Qwen-VL"]
# Qwen3-VL: the three DeepStack mergers (features of ViT layers 8, 16, 24, added to the first three LLM
# layers) are MLPs on the merged tokens, like the main merger.
# Gemma 4 12B (encoder-free): the 48-px patch projection is the whole vision path; the projection into
# the language model runs on the padded patch slots ("fusion_in"); the audio projection is idle here.
ROUTING_RULES["Gemma-4-12B"] = [
    (_EMBEDDINGS, IDLE, "zero"),
    (r"embed_audio\.", IDLE, "zero"),
    (r"embed_vision\.(multimodal_embedder\.)?embedding_projection", FUSION, "fusion_in"),
    (r"(vision_embedder|embed_vision)\.patch_dense", VISION, "patch"),
    (r"language_model\.", LANGUAGE, "sequence"),
]
# Gemma 4 26B-A4B: every decoder layer runs a dense MLP and 8 of 128 routed experts on every token.
ROUTING_RULES["Gemma-4-26B-A4B"] = [
    (_EMBEDDINGS, IDLE, "zero"),
    (r"vision_tower\.patch_embedder\.input_proj", VISION, "patch"),
    (r"vision_tower\.", VISION, "encoder"),
    (r"embed_vision\.embedding_projection", FUSION, "fusion_out"),
    (r"language_model\.layers\.#\.experts\.", LANGUAGE, "routed_experts"),
    (r"language_model\.", LANGUAGE, "sequence"),
]
ROUTING_RULES["Qwen3-VL-8B"] = [
    (_EMBEDDINGS, IDLE, "zero"),
    (r"visual\.patch_embed", VISION, "patch"),
    (r"visual\.(merger|deepstack_merger_list)\.", FUSION, "fusion_out"),
    (r"visual\.", VISION, "encoder"),
    (r"^lm_head", HEAD, "last"),
    (r"language_model\.", LANGUAGE, "sequence"),
]

# Mixture-of-experts: routed experts activated per token (DeepSeek-VL2-Small config:
# 64 routed experts, 6 per token; the 2 shared experts are dense and routed as "sequence").
MOE_ACTIVE_FRACTION = {"DeepSeek-VL2-Small": 6 / 64, "Gemma-4-26B-A4B": 8 / 128}

# LM heads tied to the input embedding (absent from named_parameters): (vocabulary, width).
# Charged like every other head: one position, the one that yields the first generated token.
# BLIP-2's released embedding has 50,304 rows (OPT's 50,272 padded to a multiple of 64); the
# full-model FLOP count of the GPU-harness dry run showed the head charged with 50,272 (-0.064%).
TIED_LM_HEAD = {"BLIP-2-OPT-2.7B": (50304, 2560), "BLIP-large": (30524, 768),
                "Gemma-4-12B": (262144, 3840), "Gemma-4-26B-A4B": (262144, 2816)}

INSTRUCTION_TOKENS_IN_QFORMER = 32   # InstructBLIP feeds the instruction to the Q-Former as well
SIGLIP_TEXT_TOKENS = 64              # SigLIP text towers are trained on max-length (64) padding


def stream_token_counts(model: str, account: TokenAccount, text_tokens: int) -> Dict[str, float]:
    """Token count of every stream for one model and one TokenAccount."""
    is_cross_attention = account.cross_attended_tokens > 0 and account.language_visual_tokens == 0
    sequence = account.language_visual_tokens + text_tokens
    counts = {
        "zero": 0, "pooled": 1, "last": 1,
        "encoder": account.encoder_tokens,
        "patch": account.patch_positions,
        "fusion_in": account.fusion_input_tokens,
        "fusion_out": account.fusion_output_tokens,
        "sequence": sequence,
        "text": SIGLIP_TEXT_TOKENS if model.startswith("SigLIP") else text_tokens,
        "cross_kv": account.cross_attended_tokens,
        "siglip_head_qkv": 0,
    }
    if model.startswith("SigLIP"):
        # Packed MAP-head projection: Q acts on the 1 probe, K and V on every patch -> mean cost per row.
        counts["siglip_head_qkv"] = (1 + 2 * account.encoder_tokens) / 3
    if model in ("BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B"):
        instruction_tokens = account.details.get("qformer_instruction_tokens", INSTRUCTION_TOKENS_IN_QFORMER)
        counts["qformer_joint"] = account.fusion_output_tokens + instruction_tokens
        counts["qformer_text"] = instruction_tokens
        if model == "BLIP-2-OPT-2.7B":
            counts["qformer_joint"] = account.fusion_output_tokens
    if model == "IDEFICS-9B":
        counts["perceiver_kv"] = account.fusion_input_tokens + account.fusion_output_tokens
    if model == "Idefics2-8B":
        counts["perceiver_kv"] = account.fusion_input_tokens + account.fusion_output_tokens
    if model in MOE_ACTIVE_FRACTION:
        counts["routed_experts"] = sequence * MOE_ACTIVE_FRACTION[model]
    if is_cross_attention:
        counts["sequence"] = text_tokens
    return counts


# Layer-group patterns: the number of distinct indices captured gives the layer count of
# each attention group, so the model follows the parameter layout it is given (released
# depth, or the reduced depth used for validation) instead of hard-coded depths.
LAYER_PATTERNS: Dict[str, Dict[str, List[str]]] = {
    "CLIP-ViT-L/14": {"vision": [r"^vision_model\.encoder\.layers\.(\d+)\."], "text": [r"^text_model\.encoder\.layers\.(\d+)\."]},
    "SigLIP-L/16": {"vision": [r"^vision_model\.encoder\.layers\.(\d+)\."], "text": [r"^text_model\.encoder\.layers\.(\d+)\."]},
    "BLIP-large": {"vision": [r"^vision_model\.encoder\.layers\.(\d+)\."],
                   "text": [r"text_decoder\.bert\.encoder\.layer\.(\d+)\.attention\."],
                   "cross": [r"text_decoder\.bert\.encoder\.layer\.(\d+)\.crossattention\."]},
    "ViLT-B/32": {"shared": [r"^vilt\.encoder\.layer\.(\d+)\."]},
    "BLIP-2-OPT-2.7B": {"vision": [r"^vision_model\.encoder\.layers\.(\d+)\."],
                        "qformer": [r"^qformer\.encoder\.layer\.(\d+)\.attention\."],
                        "qformer_cross": [r"^qformer\.encoder\.layer\.(\d+)\.crossattention\."],
                        "language": [r"language_model\.model\.(?:decoder\.)?layers\.(\d+)\."]},
    "LLaVA": {"vision": [r"vision_tower\.vision_model\.encoder\.layers\.(\d+)\."], "language": [r"language_model\.layers\.(\d+)\."]},
    "Molmo-7B-D": {"vision": [r"image_vit\.transformer\.resblocks\.(\d+)\."], "language": [r"transformer\.blocks\.(\d+)\."]},
    "IDEFICS-9B": {"vision": [r"vision_model\.encoder\.layers\.(\d+)\."], "perceiver": [r"perceiver_resampler\.blocks\.(\d+)\."],
                   "language": [r"^model\.layers\.(\d+)\."], "cross": [r"gated_cross_attn_layers\.(\d+)\."]},
    "Llama-3.2-11B-Vision": {"vision": [r"vision_model\.transformer\.layers\.(\d+)\."],
                             "vision_global": [r"vision_model\.global_transformer\.layers\.(\d+)\."],
                             "language": [r"language_model\.layers\.(\d+)\.self_attn\."],
                             "cross": [r"language_model\.layers\.(\d+)\.cross_attn\."]},
    "Idefics2-8B": {"vision": [r"vision_model\.encoder\.layers\.(\d+)\."], "perceiver": [r"perceiver_resampler\.layers\.(\d+)\."],
                    "language": [r"text_model\.layers\.(\d+)\."]},
    "Qwen-VL": {"vision": [r"visual\.blocks\.(\d+)\."], "language": [r"language_model\.layers\.(\d+)\."]},
    "InternVL3-8B": {"vision": [r"^vision_model\.encoder\.layers\.(\d+)\.", r"vision_tower\.encoder\.layer\.(\d+)\."],
                     "language": [r"language_model\.(?:model\.)?layers\.(\d+)\."]},
    "Pixtral-12B": {"vision": [r"vision_tower\.transformer\.layers\.(\d+)\."], "language": [r"language_model\.layers\.(\d+)\."]},
    "DeepSeek-VL2-Small": {"vision": [r"^vision\.blocks\.(\d+)\."], "language": [r"^language\.model\.layers\.(\d+)\."]},
    "Chameleon-7B": {"language": [r"^model\.layers\.(\d+)\."]},
    "Janus-Pro-7B": {"vision": [r"vision_tower\.blocks\.(\d+)\.", r"model\.vision_model\.encoder\.layers\.(\d+)\."],
                     "language": [r"language_model\.(?:model\.)?layers\.(\d+)\."]},
}
LAYER_PATTERNS["SigLIP2-So400m/14"] = LAYER_PATTERNS["SigLIP-L/16"]
LAYER_PATTERNS["InstructBLIP-Vicuna-7B"] = LAYER_PATTERNS["BLIP-2-OPT-2.7B"]
for _alias in ("LLaVA-1.5-7B", "LLaVA-NeXT-7B"):
    LAYER_PATTERNS[_alias] = LAYER_PATTERNS["LLaVA"]
for _alias in ("Qwen2-VL-7B", "Qwen2.5-VL-7B", "Qwen3-VL-8B"):
    LAYER_PATTERNS[_alias] = LAYER_PATTERNS["Qwen-VL"]
# Gemma 4: global-attention layers reuse the key projection as values (attention_k_eq_v), so the layers
# that carry a v_proj are exactly the sliding-window layers; global = all layers - sliding.
LAYER_PATTERNS["Gemma-4-12B"] = {"language": [r"language_model\.layers\.(\d+)\.self_attn\.q_proj"],
                                 "sliding": [r"language_model\.layers\.(\d+)\.self_attn\.v_proj"]}
LAYER_PATTERNS["Gemma-4-26B-A4B"] = dict(LAYER_PATTERNS["Gemma-4-12B"],
                                     vision=[r"vision_tower\.encoder\.layers\.(\d+)\."])

QWEN25_FULL_ATTENTION_LAYERS = 4      # fullatt_block_indexes = [7, 15, 23, 31] in the released config


def count_layers(model: str, parameter_names) -> Dict[str, int]:
    """Number of distinct layer indices per attention group of one model."""
    counts = {}
    names = list(parameter_names)
    for group, patterns in LAYER_PATTERNS[model].items():
        indices = set()
        for name in names:
            for pattern in patterns:
                match = re.search(pattern, name)
                if match:
                    indices.add(int(match.group(1)))
        counts[group] = len(indices)
    return counts


MLA_ATTENTION_FORMS = ("decompressed", "absorbed")


def attention_specs(model: str, account: TokenAccount, text_tokens: int, layers: Dict[str, int],
                    qwen25_full_attention_layers: int = QWEN25_FULL_ATTENTION_LAYERS,
                    mla_attention_form: str = "decompressed") -> List[AttentionSpec]:
    """Attention products per layer group; widths are heads x head-dim from the released configs.

    ``mla_attention_form`` selects how DeepSeek-VL2's multi-head latent attention is costed:
    "decompressed" (keys and values up-projected to 16 heads x 192 / 128, the minimum for a
    prefill pass) or "absorbed" (the released reference code: the up-projection is folded into
    the queries and outputs, so scores use the 512-wide latent plus the 64-wide rotary key and
    values are mixed in the 512-wide latent, 16 heads). The weight term is the same in both
    forms when queries and keys are the same tokens (prefill).
    """
    sequence = account.language_visual_tokens + text_tokens
    encoder = [(tokens, tokens) for tokens in account.encoder_sequences]
    if model == "CLIP-ViT-L/14":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "ViT-L/14"),
                AttentionSpec(LANGUAGE, layers["text"], [(text_tokens, text_tokens)], 768, 768, "text tower")]
    if model in ("SigLIP-L/16", "SigLIP2-So400m/14"):
        width = 1024 if model == "SigLIP-L/16" else 1152
        return [AttentionSpec(VISION, layers["vision"], encoder, width, width, "ViT"),
                AttentionSpec(VISION, 1, [(1, account.encoder_tokens)], width, width, "attention-pooling head"),
                AttentionSpec(LANGUAGE, layers["text"], [(SIGLIP_TEXT_TOKENS, SIGLIP_TEXT_TOKENS)], width, width, "text tower")]
    if model == "BLIP-large":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "ViT-L/16"),
                AttentionSpec(LANGUAGE, layers["text"], [(text_tokens, text_tokens)], 768, 768, "decoder self-attention"),
                AttentionSpec(CROSS, layers["cross"], [(text_tokens, account.cross_attended_tokens)], 768, 768,
                              "decoder cross-attention")]
    if model == "ViLT-B/32":
        return [AttentionSpec(LANGUAGE, layers["shared"], [(sequence, sequence)], 768, 768, "shared transformer")]
    if model in ("BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B"):
        queries = account.fusion_output_tokens
        instruction_tokens = account.details.get("qformer_instruction_tokens", INSTRUCTION_TOKENS_IN_QFORMER)
        joint = queries + (instruction_tokens if model.startswith("Instruct") else 0)
        llm_width = 2560 if model.startswith("BLIP-2") else 4096
        return [AttentionSpec(VISION, layers["vision"], encoder, 1408, 1408, "EVA ViT-g"),
                AttentionSpec(FUSION, layers["qformer"], [(joint, joint)], 768, 768, "Q-Former self-attention"),
                AttentionSpec(FUSION, layers["qformer_cross"], [(queries, account.fusion_input_tokens)], 768, 768,
                              "Q-Former cross-attention"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], llm_width, llm_width, "LLM")]
    if model in ("LLaVA-1.5-7B", "LLaVA-NeXT-7B"):
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "CLIP ViT-L/14-336 (every layer runs)"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 4096, 4096, "LLM")]
    if model == "Molmo-7B-D":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "CLIP ViT-L/14-336 (23 layers released)"),
                AttentionSpec(FUSION, 1, [(1, 4)] * account.fusion_output_tokens, 1024, 1024, "2x2 attention pooling"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 3584, 3584, "LLM")]
    if model == "IDEFICS-9B":
        latents = account.fusion_output_tokens
        return [AttentionSpec(VISION, layers["vision"], encoder, 1280, 1280, "ViT-H/14"),
                AttentionSpec(FUSION, layers["perceiver"], [(latents, account.fusion_input_tokens + latents)], 1536, 1536,
                              "perceiver"),
                AttentionSpec(LANGUAGE, layers["language"], [(text_tokens, text_tokens)], 4096, 4096, "LLM self-attention"),
                AttentionSpec(CROSS, layers["cross"], [(text_tokens, account.cross_attended_tokens)], 4096, 4096,
                              "gated cross-attention")]
    if model == "Llama-3.2-11B-Vision":
        # Both the 32 "local" and the 8 global layers attend over the patches of ALL tiles at once
        # (the tiles are concatenated into one sequence; only padding is masked).
        global_sequence = account.encoder_tokens
        return [AttentionSpec(VISION, layers["vision"], [(global_sequence, global_sequence)], 1280, 1280,
                              "local transformer (all tiles in one sequence)"),
                AttentionSpec(VISION, layers["vision_global"], [(global_sequence, global_sequence)], 1280, 1280,
                              "global transformer"),
                AttentionSpec(LANGUAGE, layers["language"], [(text_tokens, text_tokens)], 4096, 4096, "LLM self-attention"),
                AttentionSpec(CROSS, layers["cross"], [(text_tokens, account.cross_attended_tokens)], 4096, 4096,
                              "cross-attention")]
    if model == "Idefics2-8B":
        perceiver = [(64, patches + 64) for patches in account.encoder_sequences]
        return [AttentionSpec(VISION, layers["vision"], encoder, 1152, 1152, "SigLIP so400m (per sub-image)"),
                AttentionSpec(FUSION, layers["perceiver"], perceiver, 1536, 1536, "perceiver resampler"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 4096, 4096, "LLM")]
    if model == "Qwen2-VL-7B":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1280, 1280, "ViT (full attention)"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 3584, 3584, "LLM")]
    if model in ("Gemma-4-12B", "Gemma-4-26B-A4B"):
        # Sliding-window layers (window 1,024) and global layers. Every sequence of this protocol is
        # shorter than the window (at most 280 soft tokens + prompt), so both attend over the whole prefix.
        global_layers = layers["language"] - layers["sliding"]
        specs = [AttentionSpec(LANGUAGE, layers["sliding"], [(sequence, sequence)], 16 * 256, 16 * 256,
                               "sliding-window layers, 16 heads x 256"),
                 AttentionSpec(LANGUAGE, global_layers, [(sequence, sequence)], 16 * 512, 16 * 512,
                               "global layers, 16 heads x 512 (values = keys)")]
        if model == "Gemma-4-26B-A4B":
            specs.insert(0, AttentionSpec(VISION, layers["vision"], encoder, 1152, 1152, "vision encoder, 16 heads x 72"))
        return specs
    if model == "Qwen3-VL-8B":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1152, 1152, "ViT (full attention per image, 16 heads x 72)"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 4096, 4096, "LLM (32 heads x 128)")]
    if model == "Qwen2.5-VL-7B":
        windows = [(tokens, tokens) for tokens in account.details["window_sequences"]]
        full_layers = qwen25_full_attention_layers
        return [AttentionSpec(VISION, full_layers, encoder, 1280, 1280, "ViT full-attention layers"),
                AttentionSpec(VISION, layers["vision"] - full_layers, windows, 1280, 1280, "ViT window-attention layers"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 3584, 3584, "LLM")]
    if model == "InternVL3-8B":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "InternViT-300M (per tile)"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 3584, 3584, "LLM")]
    if model == "Pixtral-12B":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "Pixtral-ViT"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 4096, 4096, "LLM (32 heads x 128)")]
    if model == "DeepSeek-VL2-Small":
        if mla_attention_form not in MLA_ATTENTION_FORMS:
            raise ValueError(f"mla_attention_form must be one of {MLA_ATTENTION_FORMS}, not {mla_attention_form!r}")
        if mla_attention_form == "absorbed":
            language_attention = AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 16 * (512 + 64),
                                               16 * 512, "latent attention, absorbed form (released code), 16 heads")
        else:
            language_attention = AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 16 * 192, 16 * 128,
                                               "latent attention, decompressed form, 16 heads")
        return [AttentionSpec(VISION, layers["vision"], encoder, 1152, 1152, "SigLIP so400m (per tile)"),
                language_attention]
    if model == "Chameleon-7B":
        return [AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 4096, 4096, "fused transformer")]
    if model == "Janus-Pro-7B":
        return [AttentionSpec(VISION, layers["vision"], encoder, 1024, 1024, "SigLIP-L/16"),
                AttentionSpec(LANGUAGE, layers["language"], [(sequence, sequence)], 4096, 4096, "LLM")]
    raise KeyError(model)


def route_parameter(model: str, parameter_name: str) -> Optional[Tuple[str, str]]:
    """Return (component, stream) for one parameter, or None if no rule matches."""
    collapsed = re.sub(r"\.\d+\.", ".#.", parameter_name)
    collapsed = re.sub(r"\.\d+\.", ".#.", collapsed)
    for pattern, component, stream in ROUTING_RULES[model]:
        if re.search(pattern, collapsed):
            return component, stream
    return None


def forward_cost_revised(model: str, parameter_shapes: Dict[str, Tuple[int, ...]], account: TokenAccount,
                         text_tokens: int = 32, measured_encoder_gflops: float = 0.0,
                         qwen25_full_attention_layers: int = QWEN25_FULL_ATTENTION_LAYERS,
                         mla_attention_form: str = "decompressed") -> CostBreakdown:
    """Revised forward cost of one model for one input image.

    Args:
        model: roster name (key of ``ROUTING_RULES``).
        parameter_shapes: every parameter name -> shape (meta skeleton or checkpoint header).
        account: visual-token account for the chosen input image.
        text_tokens: prompt length (32, as in the published protocol).
        measured_encoder_gflops: encoder FLOPs measured with an op-level counter for
            modules whose cost is not a token-wise matmul (Chameleon's convolutional
            VQ-VAE encoder at several resolutions); added to the encoder.
        qwen25_full_attention_layers: full-attention ViT layers of Qwen2.5-VL (4 released;
            set explicitly for reduced-depth validation models).
        mla_attention_form: DeepSeek-VL2 latent attention, "decompressed" or "absorbed"
            (see ``attention_specs``).
    """
    tokens = stream_token_counts(model, account, text_tokens)
    matmul = {VISION: 0.0, FUSION: 0.0, LANGUAGE: 0.0, CROSS: 0.0, HEAD: 0.0}
    unrouted, idle_parameters = [], 0
    for name, shape in parameter_shapes.items():
        elements = 1
        for dimension in shape:
            elements *= dimension
        if len(shape) < 2:
            continue  # biases, norm scales, gates: element-wise, see omitted_elementwise_flops
        routed = route_parameter(model, name)
        if routed is None:
            unrouted.append(name)
            continue
        component, stream = routed
        if component == IDLE:
            idle_parameters += elements
            continue
        if len(shape) < 2 or stream == "vq_measured":
            continue
        matmul[component] += 2 * elements * tokens[stream]

    attention = {VISION: 0.0, FUSION: 0.0, LANGUAGE: 0.0, CROSS: 0.0, HEAD: 0.0}
    layers = count_layers(model, parameter_shapes.keys())
    for spec in attention_specs(model, account, text_tokens, layers, qwen25_full_attention_layers, mla_attention_form):
        attention[spec.component] += spec.flops()

    if model in TIED_LM_HEAD:
        vocabulary, width = TIED_LM_HEAD[model]
        matmul[HEAD] += 2 * vocabulary * width * tokens["last"]

    # Executed accounts only: Gemma 4 26B-A4B averages 3 x 3 patches with a one-hot matrix product over
    # all padded patch slots (the intrinsic average is element-wise and not counted).
    if "dense_pooling_product" in account.details:
        output_slots, input_slots, width = account.details["dense_pooling_product"]
        matmul[VISION] += 2 * output_slots * input_slots * width

    encoder = matmul[VISION] + attention[VISION] + measured_encoder_gflops * GIGA
    if model == "Chameleon-7B" and measured_encoder_gflops == 0.0:
        raise ValueError("Chameleon needs the measured VQ-encoder FLOPs (measured_encoder_gflops)")
    fusion = matmul[FUSION] + attention[FUSION]
    language = matmul[LANGUAGE] + attention[LANGUAGE]
    cross_visual = matmul[CROSS] + attention[CROSS]
    head = matmul[HEAD]
    if cross_visual > 0 or model in ("CLIP-ViT-L/14", "SigLIP-L/16", "SigLIP2-So400m/14"):
        # Cross-attention and contrastive designs: no visual tokens in the language sequence.
        llm_visual, llm_text = cross_visual, language
    else:
        # Inserted-token and shared-stream designs: apportion by sequence share (published convention).
        sequence = account.language_visual_tokens + text_tokens
        llm_visual = language * account.language_visual_tokens / sequence
        llm_text = language - llm_visual
    total = encoder + fusion + llm_visual + llm_text + head
    return CostBreakdown(
        model=model,
        encoder_g=encoder / GIGA, fusion_g=fusion / GIGA, llm_visual_g=llm_visual / GIGA,
        llm_text_g=llm_text / GIGA, head_g=head / GIGA, total_g=total / GIGA,
        vision_compute_share_pct=100 * encoder / total,
        vision_attributable_pct=100 * (encoder + fusion + llm_visual) / total,
        matmul_by_component_g={key: value / GIGA for key, value in matmul.items()},
        attention_by_component_g={key: value / GIGA for key, value in attention.items()},
        stream_tokens=tokens, unrouted_parameters=unrouted, idle_parameters=idle_parameters,
        layer_counts=layers,
    )


# ---------------------------------------------------------------------------
# Element-wise work left out of the matmul count (reviewer item A5 (i))
# ---------------------------------------------------------------------------

# FLOPs per element, deliberately generous: LayerNorm (mean, variance, normalise,
# scale, shift) 8; RMSNorm 6; GELU (tanh form) 8; SiLU-gated MLP (sigmoid, product,
# gate product) 6 per intermediate element; softmax (max, subtract, exp, sum,
# divide) 5 per score; residual add 1; rotary embedding 3 per rotated q/k element.
ELEMENTWISE_COST = {"layer_norm": 8, "rms_norm": 6, "gelu": 8, "swiglu": 6, "softmax": 5, "residual": 1, "rotary": 3}


@dataclass
class StackShape:
    """Element-wise profile of one transformer stack (one entry per layer group)."""

    layers: int
    tokens: float              # tokens through the stack (sum over independent sequences)
    width: int                 # residual width
    mlp_width: int             # MLP intermediate width (per active expert path for MoE)
    activation: str            # "gelu" or "swiglu"
    norm: str                  # "layer_norm" or "rms_norm"
    attention_scores: float    # sum over sequences of n_query * n_key * heads, per layer
    rotary_width: int = 0      # q + k widths rotated per token (0 if no rotary)
    norms_per_layer: int = 2

    def elementwise_flops(self) -> float:
        """Upper-bound element-wise FLOPs of the stack."""
        per_layer = (self.norms_per_layer * ELEMENTWISE_COST[self.norm] * self.tokens * self.width
                     + ELEMENTWISE_COST[self.activation] * self.tokens * self.mlp_width
                     + ELEMENTWISE_COST["softmax"] * self.attention_scores
                     + 2 * ELEMENTWISE_COST["residual"] * self.tokens * self.width
                     + ELEMENTWISE_COST["rotary"] * self.tokens * self.rotary_width)
        return self.layers * per_layer
