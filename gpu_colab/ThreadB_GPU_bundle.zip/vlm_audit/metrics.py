"""The measurement primitives.

Public API:
* ``count_params(module, trainable_only=False) -> int``
* ``measure_flops(module, kwargs, logger=None) -> (float | None, str)``  — Phase-2 returns (value_g, source)
* ``measure_peak_memory(module, kwargs, device="cuda", repeats=3, logger=None) -> float | None``
* ``count_fusion_boundary_tokens(model_spec, image_hw=None) -> int | None``

Phase-2 additions:
* ``count_active_params(module, n_experts_total, n_experts_active_per_token) -> int``
* ``count_image_token_vocab(model, vocab_size_image=None) -> int | None``
* ``count_dynamic_tile_tokens(model_spec, image_hw) -> int``
* ``compute_trainable_from_policy(spec, comps) -> Dict[str, int]``

Phase-2 bug fix (F-2): manual-fallback FLOPs estimate now uses ``patch_count``
instead of ``H*W`` for image-like 4-D tensors. Previously this caused
100-200x overestimates for SigLIP / LLaVA / ViLT vision towers when calflops
failed (EXPERIMENT_LOG.md issue F-2).
"""

from typing import Any, Dict, Optional, Tuple


# ---------------------------------------------------------------------------
# Parameter counting
# ---------------------------------------------------------------------------

def count_params(module, trainable_only: bool = False) -> int:
    """Sum of ``p.numel()`` across the module. Returns 0 for ``None``.

    ``trainable_only=True`` filters by ``requires_grad`` — note this is
    almost always misleading on a fresh ``from_pretrained`` load. Use
    ``compute_trainable_from_policy`` for the canonical-recipe answer.
    """
    if module is None:
        return 0
    if trainable_only:
        return sum(p.numel() for p in module.parameters() if p.requires_grad)
    return sum(p.numel() for p in module.parameters())


def count_active_params(
    module,
    n_experts_total: Optional[int] = None,
    n_experts_active_per_token: Optional[int] = None,
) -> int:
    """For MoE modules: total parameters minus the inactive expert fraction.

    If the module is dense, this returns ``count_params(module)``. For MoE
    LLMs we approximate active params as::

        non_expert_params + expert_params * (k_active / k_total)

    The "non_expert" portion is detected heuristically by looking for
    submodules named ``mlp.experts`` / ``moe`` / ``experts``.

    This is approximate — exact bookkeeping requires walking each MoE layer's
    routing logic. For the headline figure (e.g. DeepSeek-VL2-Small: 27B total
    -> ~2.8B activated) the approximation is correct within a few percent.
    """
    if module is None:
        return 0
    total = count_params(module)
    if not n_experts_total or not n_experts_active_per_token:
        return total
    if n_experts_active_per_token >= n_experts_total:
        return total

    # Sum parameters in expert submodules.
    expert_params = 0
    for name, sub in module.named_modules():
        lower = name.lower()
        if "experts" in lower and lower.endswith("experts"):
            # Top-level "experts" container; count its children.
            expert_params += sum(p.numel() for p in sub.parameters())
            break
    # Fallback: scan named_parameters for the routing pattern.
    if expert_params == 0:
        for n, p in module.named_parameters():
            if ".experts." in n or n.startswith("experts."):
                expert_params += p.numel()

    non_expert = total - expert_params
    fraction_active = n_experts_active_per_token / n_experts_total
    return int(non_expert + expert_params * fraction_active)


def count_image_token_vocab(model, vocab_size_image: Optional[int] = None) -> Optional[int]:
    """Native-fusion (Chameleon) image-token vocab size.

    Chameleon's tokenizer uses a unified vocabulary where a known prefix /
    suffix maps to image tokens (default 8192 image entries). If the model
    config exposes ``vocabulary_map`` we count directly; otherwise we fall
    back to a hand-specified default for known models.
    """
    cfg = getattr(model, "config", None)
    if cfg is None:
        return vocab_size_image
    # Chameleon stores image-vocab metadata in ``config.image_token_id`` and
    # ``config.vocabulary_map``; lengths vary across releases.
    v_map = getattr(cfg, "vocabulary_map", None)
    if v_map is not None:
        try:
            # Image tokens conventionally use the prefix "IMGIMG" in Chameleon.
            n = sum(1 for k in v_map if isinstance(k, str) and k.startswith("IMGIMG"))
            if n > 0:
                return n
        except Exception:
            pass
    # Hand-specified default for Chameleon-7B per its tokenizer.
    return vocab_size_image if vocab_size_image is not None else 8192


def count_dynamic_tile_tokens(model_spec, image_hw: Tuple[int, int]) -> int:
    """How many tokens a dynamic-tile vision encoder produces at the given resolution.

    Approximation: ``(H // patch) * (W // patch)`` with the canonical patch
    size for the family. Dynamic-tile models additionally compress (pixel-
    shuffle 4x for InternVL3) — that's accounted for in the per-family table
    in ``count_fusion_boundary_tokens``.
    """
    family = model_spec.family
    H, W = image_hw
    # Patch sizes by family / model:
    if "patch14" in model_spec.hf_id:
        ps = 14
    elif "patch16" in model_spec.hf_id:
        ps = 16
    elif family in ("dynamic_tile_adapter_llm", "moe_adapter_llm"):
        ps = 14  # Qwen2-VL / InternVL3 / SigLIP-SO400M use patch-14
    elif family == "single_stream_fused":
        ps = 32
    else:
        ps = 14
    return max(1, (H // ps) * (W // ps))


# ---------------------------------------------------------------------------
# FLOPs
# ---------------------------------------------------------------------------

def parse_gflops_string(flops_str) -> Optional[float]:
    """Convert calflops' string output to a float in G-FLOPs."""
    if flops_str is None:
        return None
    if isinstance(flops_str, (int, float)):
        return float(flops_str)
    if not isinstance(flops_str, str):
        return None
    parts = flops_str.strip().split()
    if len(parts) != 2:
        try:
            return float(parts[0]) if parts else None
        except Exception:
            return None
    try:
        v = float(parts[0])
    except Exception:
        return None
    unit = parts[1].upper()
    if unit in ("GFLOPS", "G"):
        return v
    if unit in ("MFLOPS", "M"):
        return v / 1000.0
    if unit in ("TFLOPS", "T"):
        return v * 1000.0
    if unit in ("KFLOPS", "K"):
        return v / 1_000_000.0
    if unit in ("FLOPS",):
        return v / 1e9
    return v


def _strip_underscore_keys(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    """Remove placeholder keys (start with '_') that we use to pass hints
    through dummy_inputs.py — these are not real forward kwargs."""
    if not kwargs:
        return {}
    return {k: v for k, v in kwargs.items() if not k.startswith("_")}


def _try_calflops(module, kwargs, logger=None) -> Optional[float]:
    try:
        from calflops import calculate_flops
    except ImportError:
        if logger:
            logger.warn("calflops not installed; skipping primary")
        return None
    try:
        kw = _strip_underscore_keys(kwargs) if kwargs else None
        flops, _macs, _params = calculate_flops(
            model=module,
            kwargs=kw,
            print_results=False,
            output_as_string=True,
            output_precision=4,
        )
        g = parse_gflops_string(flops)
        if logger:
            logger.info(f"calflops returned raw={flops!r} parsed={g} GFLOPs")
        return g
    except Exception as e:
        if logger:
            logger.warn(f"calflops failed: {type(e).__name__}: {e}")
        return None


def _try_fvcore(module, kwargs, logger=None) -> Optional[float]:
    try:
        from fvcore.nn import FlopCountAnalysis
    except ImportError:
        if logger:
            logger.warn("fvcore not installed; skipping fallback #1")
        return None
    try:
        kw = _strip_underscore_keys(kwargs) if kwargs else {}
        if not kw:
            return None
        ordered = tuple(kw.values())
        fca = FlopCountAnalysis(module, ordered).unsupported_ops_warnings(False)
        # fvcore reports MACs (multiply-accumulate operations) but labels them
        # "FLOPs" in its API. 1 MAC == 2 FLOPs by the convention used in
        # calflops / Sunita-1 reference values. ptflops below already doubles
        # explicitly; we now match that convention here.
        macs = fca.total()
        g = (macs * 2) / 1e9
        if logger:
            logger.info(f"fvcore returned {g:.4f} GFLOPs (from {macs} MACs ×2)")
        return g
    except Exception as e:
        if logger:
            logger.warn(f"fvcore failed: {type(e).__name__}: {e}")
        return None


def _try_ptflops(module, kwargs, logger=None) -> Optional[float]:
    try:
        from ptflops import get_model_complexity_info
    except ImportError:
        if logger:
            logger.warn("ptflops not installed; skipping fallback #2")
        return None
    try:
        kw = _strip_underscore_keys(kwargs) if kwargs else {}
        if not kw:
            return None
        def constructor(_resolution):
            return kw
        first = next(iter(kw.values()))
        shape = tuple(first.shape[1:]) if hasattr(first, "shape") else (1,)
        macs, _params = get_model_complexity_info(
            module, shape,
            input_constructor=constructor,
            as_strings=False,
            print_per_layer_stat=False,
            verbose=False,
        )
        g = (macs * 2) / 1e9
        if logger:
            logger.info(f"ptflops returned {g:.4f} GFLOPs (from {macs} MACs)")
        return g
    except Exception as e:
        if logger:
            logger.warn(f"ptflops failed: {type(e).__name__}: {e}")
        return None


def _manual_estimate(module, kwargs, logger=None) -> Optional[float]:
    """Last-resort FLOPs estimate.

    Phase-2 fix: for image-like 4-D tensors (B, C, H, W) we previously used
    ``H*W`` as ``seq_len``, which overestimates by 100-200x for transformer
    vision towers that only see (H/patch)*(W/patch) patches.

    The new heuristic:
    * If the kwargs contain an image tensor (4-D, channels=3), set
      ``seq_len = (H/14) * (W/14)`` — the typical ViT patch count. This
      yields the right order of magnitude for ViT-L/14 (256 patches at 224).
    * Otherwise, use the largest 2-D token-axis size from the kwargs.
    Returns ``2 * params * seq_len / 1e9``.
    """
    if module is None:
        return None
    n_params = count_params(module)
    seq_len = 1
    if kwargs:
        for v in _strip_underscore_keys(kwargs).values():
            if not hasattr(v, "shape") or not hasattr(v, "dim"):
                continue
            if v.dim() == 4 and v.shape[1] == 3:
                # Image-like (B, 3, H, W) — use patch count.
                H, W = int(v.shape[2]), int(v.shape[3])
                patch = 14  # typical ViT patch size; conservative
                seq_len = max(seq_len, (H // patch) * (W // patch))
            elif v.dim() >= 2:
                seq_len = max(seq_len, int(v.shape[1]))
    g = (2 * n_params * seq_len) / 1e9
    if logger:
        logger.warn(
            f"All FLOPs counters failed; manual estimate "
            f"2*params*seq = 2*{n_params}*{seq_len} = {g:.4f} GFLOPs "
            f"(flagged as estimate; mark `estimate=True` in record)"
        )
    return g


def measure_flops(
    module,
    kwargs: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Tuple[Optional[float], str]:
    """Forward FLOPs in G-FLOPs.

    Returns ``(value_g, source)`` where source is one of
    ``"calflops"``, ``"fvcore"``, ``"ptflops"``, ``"manual_estimate"``, ``""``.
    """
    if module is None or kwargs is None:
        return (None, "")
    for fn, source in (
        (_try_calflops, "calflops"),
        (_try_fvcore, "fvcore"),
        (_try_ptflops, "ptflops"),
    ):
        g = fn(module, kwargs, logger=logger)
        if g is not None and g > 0:
            return (g, source)
    est = _manual_estimate(module, kwargs, logger=logger)
    return (est, "manual_estimate" if est is not None else "")


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------

def measure_peak_memory(
    module,
    kwargs: Optional[Dict[str, Any]] = None,
    device: str = "cuda",
    repeats: int = 3,
    logger=None,
) -> Optional[float]:
    """Peak activation memory in MB, median of ``repeats`` runs.

    Robust to ``TypeError`` from kwargs-vs-positional forward signatures;
    catches per-pass exceptions and logs the full traceback before continuing.
    """
    if module is None or kwargs is None:
        return None
    try:
        import torch
    except ImportError:
        return None
    if not torch.cuda.is_available():
        if logger:
            logger.warn("CUDA not available; skipping memory measurement")
        return None

    kw = _strip_underscore_keys(kwargs)
    if not kw:
        return None

    module = module.to(device).eval()
    try:
        target_dtype = next(module.parameters()).dtype
    except StopIteration:
        target_dtype = torch.float32

    moved = {}
    for k, v in kw.items():
        if hasattr(v, "to"):
            try:
                if v.dtype.is_floating_point:
                    moved[k] = v.to(device).to(target_dtype)
                else:
                    moved[k] = v.to(device)
            except Exception as e:
                if logger:
                    logger.warn(f"Could not move kwarg {k!r} to {device}: {e}")
                moved[k] = v
        else:
            moved[k] = v

    measurements = []
    for i in range(repeats):
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats(device)
        try:
            with torch.no_grad():
                try:
                    _ = module(**moved)
                except TypeError as te:
                    if logger:
                        logger.warn(
                            f"kwarg call failed ({te}); retrying with positional args"
                        )
                    _ = module(*moved.values())
            peak = torch.cuda.max_memory_allocated(device) / 1024**2
        except Exception as e:
            if logger:
                logger.error(f"Memory pass {i+1}/{repeats} forward failed", e)
            continue
        measurements.append(peak)
        if logger:
            logger.iteration(f"Memory pass {i+1}/{repeats}", peak_mb=round(peak, 2))
            logger.metric("peak_mb", round(peak, 2), unit="MB")

    if not measurements:
        return None
    measurements.sort()
    median = measurements[len(measurements) // 2]
    if logger:
        logger.info(
            f"Peak memory median across {len(measurements)} runs: "
            f"{median:.2f} MB (min={min(measurements):.2f}, max={max(measurements):.2f})"
        )
    return median


# ---------------------------------------------------------------------------
# Fusion-boundary token count (static)
# ---------------------------------------------------------------------------

def count_fusion_boundary_tokens(model_spec, image_hw: Optional[Tuple[int, int]] = None) -> Optional[int]:
    """How many tokens cross from the visual side into the language model?

    Static per architecture / family. For dynamic-tile families the number
    depends on input resolution; we report the value at the model's *native*
    resolution. ``count_dynamic_tile_tokens`` returns the same at an
    arbitrary input resolution.
    """
    family = model_spec.family
    if family == "dual_encoder_contrastive":
        return 1  # pooled
    if family == "bridge_module_precursor":
        return 1
    if family in ("bridge_module", "bridge_module_adapter_llm"):
        return 32  # Q-Former queries
    if family == "adapter_llm":
        # LLaVA-1.5 = 576 at 336; LLaVA-NeXT base = 576; Molmo = 576 (multi-crop yields more).
        return 576
    if family == "cross_attention_llm":
        # IDEFICS-1 = 64 perceiver latents.
        # Llama-3.2-Vision uses tile-based cross-attention; tile count varies.
        if "idefics" in model_spec.hf_id.lower():
            return 64
        if "llama-3.2" in model_spec.hf_id.lower() or "llama-3-2" in model_spec.hf_id.lower():
            return 1601  # Llama-3.2-Vision uses 1601 vision tokens per tile (approx)
        return 64
    if family == "perceiver_adapter_llm":
        return 64
    if family == "single_stream_fused":
        hw = image_hw or model_spec.native_image_hw
        ps = 32
        return (hw[0] // ps) * (hw[1] // ps)
    # --- Phase 2 ---
    if family == "dynamic_tile_adapter_llm":
        hw = image_hw or model_spec.native_image_hw
        if "internvl3" in model_spec.hf_id.lower():
            # InternVL3 uses pixel-shuffle 4x compression: (H/14)*(W/14)/4
            return max(1, (hw[0] // 14) * (hw[1] // 14) // 4)
        # Qwen2-VL / Qwen2.5-VL: ViT-L/14 with 2x2 merger -> (H/28)*(W/28)
        return max(1, (hw[0] // 28) * (hw[1] // 28))
    if family == "adapter_llm_own_encoder":
        # Pixtral natively variable; report value at default 1024x1024 with patch-16.
        hw = image_hw or model_spec.native_image_hw
        return max(1, (hw[0] // 16) * (hw[1] // 16))
    if family == "moe_adapter_llm":
        # DeepSeek-VL2 dynamic-tile with SigLIP-SO400M; varies per image. Report base tile (384/14=27 -> 729).
        return 729
    if family == "native_early_fusion":
        # Chameleon: image tokens are interleaved with text in the same sequence.
        # There is no fusion boundary; report image-token count from the tokenizer.
        return None
    if family == "native_decoupled_encoder":
        # Janus-Pro: SigLIP-L at 384 with 24x24 patches = 576 tokens to LLM.
        return 576
    return None


# ---------------------------------------------------------------------------
# Compute trainable from documented freezing policy (Phase-2 F-5 fix)
# ---------------------------------------------------------------------------

def compute_trainable_from_policy(
    model_spec,
    comps: Dict[str, Any],
    partitioned_counts: Optional[Dict[str, int]] = None,
    inserted_cross_attention_params: int = 0,
) -> Dict[str, int]:
    """Per-component trainable-parameter count derived from the family's
    *documented training recipe*, not from ``requires_grad``.

    Returns ``{component_name: trainable_param_count}``.

    Rationale: on a fresh ``from_pretrained`` load, every parameter has
    ``requires_grad=True`` by default, which makes Phase-1 Finding F5
    (freezing-induced compute asymmetry) degenerate. The canonical training
    recipe for each family is documented in
    ``components.trainable_components_for_family``.

    Revision fix A13: counts are taken from ``partitioned_counts`` (every
    parameter owned by exactly one component) when supplied, per-model
    ``ModelSpec.trainable_policy_override`` entries take precedence over the
    family policy, and ``INSERTED_CROSS_ATTENTION_ONLY`` marks a component of
    which only the inserted cross-attention blocks are trained.
    """
    from .components import trainable_components_for_family, INSERTED_CROSS_ATTENTION_ONLY
    policy = dict(trainable_components_for_family(model_spec.family))
    policy.update(getattr(model_spec, "trainable_policy_override", None) or {})
    out: Dict[str, int] = {}
    for cname, module in comps.items():
        if partitioned_counts is not None and cname in partitioned_counts:
            n_total = partitioned_counts[cname]
        else:
            n_total = count_params(module)
        is_trainable = policy.get(cname, True)  # unknown components default to trainable
        if is_trainable == INSERTED_CROSS_ATTENTION_ONLY:
            out[cname] = inserted_cross_attention_params
        else:
            out[cname] = n_total if is_trainable else 0
    return out


# ---------------------------------------------------------------------------
# Parameter-attribution residual check (revision fix A13)
# ---------------------------------------------------------------------------

def count_model_params(model) -> int:
    """Total unique parameters of the whole model (tied weights counted once)."""
    return sum(parameter.numel() for parameter in model.parameters())


def _collapse_layer_indices(parameter_name: str, depth: int = 3) -> str:
    """Turn ``model.layers.17.mlp.up_proj.weight`` into ``model.layers.N`` for grouping."""
    path_parts = parameter_name.split(".")[:-1] or [parameter_name]
    collapsed = ["N" if part.isdigit() else part for part in path_parts]
    return ".".join(collapsed[:depth])


def partition_component_params(model, components: Dict[str, Any]) -> Dict[str, Any]:
    """Give every model parameter exactly one owning component and report the residual.

    Ownership rules, applied in order:

    1. Aliased components (the same module object under two names, e.g.
       Janus-Pro ``vision`` / ``vision_und``) are counted once, under the
       specific name; the alias reports the same count but is excluded from sums.
    2. A parameter contained in several extracted modules is owned by the most
       specific one, i.e. the module with the fewest parameters. This resolves
       Qwen-VL's ``visual.merger`` (owned by fusion, not vision), InternVL3's
       ``language_model.lm_head`` (owned by head) and Chameleon's
       ``embed_tokens`` (owned by embeddings, not the fused transformer).
    3. Loose top-level parameters listed in ``LOOSE_PARAMETER_COMPONENT``
       (Q-Former query tokens, contrastive logit scale, tile separators) and
       small un-extracted modules listed in ``UNEXTRACTED_MODULE_COMPONENT``
       (ViLT's pooler and final LayerNorm) go to the component named there.
    4. Anything left is *unattributed* and is reported by module path.

    Returns a dict with ``model_total``, ``component_counts`` (aliases
    included, mirroring their canonical component), ``alias_of``,
    ``attributed_total`` (aliases excluded), ``residual`` (model_total minus
    attributed_total; zero when attribution is complete),
    ``unattributed_by_path`` and ``overlaps_resolved``.
    """
    from .components import (
        find_component_aliases,
        LOOSE_PARAMETER_COMPONENT,
        UNEXTRACTED_MODULE_COMPONENT,
    )

    alias_of = find_component_aliases(components)
    owning_components = {
        name: module for name, module in components.items()
        if module is not None and name not in alias_of
    }
    component_sizes = {name: count_params(module) for name, module in owning_components.items()}

    candidate_owners: Dict[int, list] = {}
    for component_name, module in owning_components.items():
        for parameter in module.parameters():
            candidate_owners.setdefault(id(parameter), []).append(component_name)

    component_counts = {name: 0 for name in owning_components}
    unattributed_by_path: Dict[str, int] = {}
    overlaps_resolved: Dict[Tuple[str, str], int] = {}
    model_total = 0
    for parameter_name, parameter in model.named_parameters():
        element_count = parameter.numel()
        model_total += element_count
        candidates = candidate_owners.get(id(parameter), [])
        if candidates:
            owner = min(candidates, key=lambda name: component_sizes[name])
            component_counts[owner] += element_count
            for other_component in candidates:
                if other_component != owner:
                    overlap_key = (owner, other_component)
                    overlaps_resolved[overlap_key] = overlaps_resolved.get(overlap_key, 0) + element_count
            continue
        loose_owner = LOOSE_PARAMETER_COMPONENT.get(parameter_name.split(".")[-1])
        if loose_owner is None:
            loose_owner = next(
                (component for path_prefix, component in UNEXTRACTED_MODULE_COMPONENT.items()
                 if parameter_name.startswith(path_prefix)),
                None,
            )
        if loose_owner is not None:
            component_counts[loose_owner] = component_counts.get(loose_owner, 0) + element_count
            continue
        group_path = _collapse_layer_indices(parameter_name)
        unattributed_by_path[group_path] = unattributed_by_path.get(group_path, 0) + element_count

    attributed_total = sum(component_counts.values())
    for alias_name, canonical_name in alias_of.items():
        component_counts[alias_name] = component_counts.get(canonical_name, 0)

    return {
        "model_total": model_total,
        "component_counts": component_counts,
        "alias_of": alias_of,
        "attributed_total": attributed_total,
        "residual": model_total - attributed_total,
        "unattributed_by_path": unattributed_by_path,
        "overlaps_resolved": [
            {"owned_by": owner, "also_inside": other, "params": count}
            for (owner, other), count in sorted(overlaps_resolved.items())
        ],
    }


def count_inserted_cross_attention_params(model) -> int:
    """Parameters in cross-attention blocks inserted into the LLM (0 if none)."""
    from .components import find_inserted_cross_attention_modules
    counted_ids = set()
    total = 0
    for _module_path, module in find_inserted_cross_attention_modules(model):
        for parameter in module.parameters():
            if id(parameter) not in counted_ids:
                counted_ids.add(id(parameter))
                total += parameter.numel()
    return total
