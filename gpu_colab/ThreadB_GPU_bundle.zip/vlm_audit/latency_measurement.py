"""Measured latency, memory and full-depth FLOPs of the released checkpoints (reviewer item A5 iii).

The tensor-level cost model (``tensor_cost_model.forward_cost_revised``) predicts
the arithmetic of one prefill pass. Reviewer item A5 (iii) asks whether that
prediction tracks what a deployment would see. For every released checkpoint,
on one GPU, in bfloat16, batch size 1, this module measures:

* **prefill latency** of the whole model (median of timed repeats after warm-up),
  as wall-clock time between two device synchronisations and as CUDA-event time;
* **prefill latency per component** (vision encoder, fusion, language model, LM
  head), from CUDA events recorded at the forward boundaries of the component
  modules (the same module paths that ``flop_counter_validation`` uses);
* **decode latency per generated token**, from two greedy ``generate`` calls that
  differ only in the number of new tokens (both include the same prefill);
* **memory**: resident weights and peak memory of one prefill pass;
* **full-depth FLOPs**, counted op by op with ``torch.utils.flop_counter`` on the
  released weights, with the math attention backend so that every score and
  value product is an explicit matmul, next to the prediction of
  ``forward_cost_revised`` for the same *executed* input (padding tiles and
  padded sub-images included, as the reference implementations run them).

The same harness runs as a **dry run** on the CPU: reduced-depth copies of the
real architectures with random weights (``flop_counter_validation.build_reduced_model``),
so every code path can be checked before GPU time is spent.

Two remote-code models need an older transformers release (Molmo's remote code
needs the GenerationMixin that ``PreTrainedModel`` dropped in 4.50; DeepSeek-VL2's
package calls ``DynamicCache.get_usable_length``). They have their own harnesses
here and run in a separate notebook with transformers 4.46.3.

Author: Sunita Sahu.
"""

import contextlib
from dataclasses import dataclass, field, asdict
from datetime import datetime
import inspect
import json
import math
import os
from pathlib import Path
import platform
import re
import statistics
import subprocess
import sys
import time
import traceback
from typing import Callable, Dict, List, Optional, Tuple

from .flop_counter_validation import (
    TRANSFORMERS5_VALIDATION_SPECS,
    VALIDATION_SPECS,
    build_reduced_model,
    build_validation_inputs,
    elementwise_flops_of,
    executed_text_tokens,
    validation_spec,
    validation_token_account,
)
from .tensor_cost_model import VISION, FUSION, LANGUAGE, HEAD, MOE_ACTIVE_FRACTION, forward_cost_revised
from .token_accounting import TEXT_PROMPT, TokenAccount, account_deepseek_vl2, account_molmo, account_visual_tokens

COMPONENTS = (VISION, FUSION, LANGUAGE, HEAD)
# Routed-expert tensors: one module per expert (DeepSeek-VL2) or one 3-D tensor for all experts (Gemma 4).
ROUTED_EXPERT_PATTERN = r"(mlp\.experts\.\d+\.|\.experts\.(gate_up_proj|down_proj)$)"

# The 19 transformers-native architectures (18 + Qwen3-VL-8B, decision D9) (same build, input and module paths as the
# reduced-depth validation of notebook 27) and the two remote-code models.
NATIVE_MODELS = tuple(VALIDATION_SPECS)                       # transformers 4.57 (notebook 29)
TRANSFORMERS5_MODELS = tuple(TRANSFORMERS5_VALIDATION_SPECS)  # Gemma 4, transformers >= 5.10 (notebook 34)
REMOTE_CODE_MODELS = ("Molmo-7B-D", "DeepSeek-VL2-Small")

NON_GENERATIVE_MODELS = {"CLIP-ViT-L/14", "SigLIP-L/16", "SigLIP2-So400m/14", "ViLT-B/32"}

# Models whose forward signature computes logits for every position (no logits_to_keep).
HEAD_ON_EVERY_POSITION = {"BLIP-large", "IDEFICS-9B", "BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B",
                          "DeepSeek-VL2-Small"}

# Processor arguments of the released checkpoints. Notebook 27 validated some models with
# overrides (Idefics2 without image splitting, at 980 x 980); the latency run uses the
# released defaults, as the token accounting does. SigLIP towers are trained on max-length
# padding (64 text tokens), which the cost model also assumes.
RELEASED_PROCESSOR_KWARGS = {
    "SigLIP-L/16": {"padding": "max_length"},
    "SigLIP2-So400m/14": {"padding": "max_length"},
}

# Chameleon's VQ-VAE encoder is convolutional; its FLOPs are measured, not predicted.
# FlopCounterMode on the released encoder at the 512 x 512 input that the processor always
# produces (notebook 27). Used only when the FLOP pass of this run is switched off.
CHAMELEON_VQ_ENCODER_GFLOPS = 554.252107776

MOLMO_REPOSITORY = "allenai/Molmo-7B-D-0924"
DEEPSEEK_VL2_REPOSITORY = "deepseek-ai/deepseek-vl2-small"
DEEPSEEK_VL2_CODE_COMMIT = "ef9f91e2b6426536b83294c11742c27be66361b1"   # github.com/deepseek-ai/DeepSeek-VL2

MOLMO_IMAGE_TOKEN_STRINGS = ("<im_patch>", "<im_start>", "<im_end>", "<im_col>")


@dataclass
class MeasurementSettings:
    """Repetition counts and inputs of one measurement run.

    Attributes:
        image_sides: square input images (pixels per side) given to each released processor.
        warmup_runs: untimed passes before each timed series.
        timed_runs: timed prefill passes (whole model and per component).
        decode_new_tokens: extra tokens of the long generate call (decode cost per token).
        decode_runs: timed repeats of each generate call.
        count_flops: run the full-depth FLOP count (one extra pass with math attention).
        count_elementwise: count the element-wise work of the full-depth pass (reviewer item
            A5 i; one extra pass through a Python dispatch mode, slow but untimed).
    """

    image_sides: Tuple[int, ...] = (448, 1024)
    warmup_runs: int = 3
    timed_runs: int = 10
    decode_new_tokens: int = 64
    decode_runs: int = 3
    count_flops: bool = True
    count_elementwise: bool = True

    @classmethod
    def dry_run(cls, image_sides: Tuple[int, ...] = (448,)) -> "MeasurementSettings":
        """Minimal repeats for the CPU dry run of the code paths."""
        return cls(image_sides=image_sides, warmup_runs=1, timed_runs=2, decode_new_tokens=4, decode_runs=1)


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

def structured_test_image(height: int, width: int, seed: int = 0):
    """Deterministic RGB test image with natural-image-like structure.

    Colour gradients, a smooth texture, sensor-like noise and 24 filled shapes.
    Token counts do not depend on image content, but the expert routing of
    DeepSeek-VL2 does: a uniform image would send every visual token to the same
    experts and make the mixture-of-experts layers unrealistically fast.
    """
    import numpy
    from PIL import Image, ImageDraw

    generator = numpy.random.default_rng(seed)
    rows = numpy.linspace(0.0, 1.0, height)[:, None]
    columns = numpy.linspace(0.0, 1.0, width)[None, :]
    red = 255 * rows * numpy.ones_like(columns)
    green = 255 * columns * numpy.ones_like(rows)
    blue = 127 + 64 * numpy.sin(12 * rows) * numpy.cos(9 * columns)
    pixels = numpy.stack([red, green, blue], axis=-1) + generator.normal(0, 12, (height, width, 3))
    image = Image.fromarray(numpy.clip(pixels, 0, 255).astype(numpy.uint8))
    canvas = ImageDraw.Draw(image)
    shortest_side = min(height, width)
    for shape_index in range(24):
        left, top = int(generator.integers(0, width)), int(generator.integers(0, height))
        size = int(generator.integers(max(2, shortest_side // 20), max(3, shortest_side // 4)))
        colour = tuple(int(value) for value in generator.integers(0, 256, 3))
        if shape_index % 2:
            canvas.ellipse([left, top, left + size, top + size], fill=colour)
        else:
            canvas.rectangle([left, top, left + size, top + size // 2], fill=colour)
    return image


def move_to_device(batch, device: str, float_dtype=None) -> dict:
    """Plain dict of the batch with every tensor on ``device`` (floats cast to ``float_dtype`` if given)."""
    import torch

    moved = {}
    for key, value in dict(batch).items():
        if isinstance(value, torch.Tensor):
            value = value.to(device)
            if float_dtype is not None and value.is_floating_point():
                value = value.to(float_dtype)
        moved[key] = value
    return moved


# ---------------------------------------------------------------------------
# Timing primitives
# ---------------------------------------------------------------------------

def is_gpu(device: str) -> bool:
    """True for a CUDA device string."""
    return str(device).startswith("cuda")


def synchronize(device: str) -> None:
    """Wait for all queued GPU work (no-op on the CPU)."""
    import torch

    if is_gpu(device):
        torch.cuda.synchronize()


def time_call(function: Callable[[], object], device: str) -> Tuple[float, float, object]:
    """Run ``function`` once; return (wall-clock ms, device ms, result).

    Wall-clock time is taken between two device synchronisations, so it includes
    kernel-launch gaps and host-side work (the deployment-relevant number). Device
    time comes from CUDA events on the current stream; on the CPU it equals wall time.
    """
    import torch

    start_event = end_event = None
    if is_gpu(device):
        torch.cuda.synchronize()
        start_event = torch.cuda.Event(enable_timing=True)
        end_event = torch.cuda.Event(enable_timing=True)
        start_event.record()
    begin = time.perf_counter()
    result = function()
    if is_gpu(device):
        end_event.record()
        torch.cuda.synchronize()
    wall_milliseconds = 1000.0 * (time.perf_counter() - begin)
    device_milliseconds = start_event.elapsed_time(end_event) if is_gpu(device) else wall_milliseconds
    return wall_milliseconds, device_milliseconds, result


def describe_samples(samples) -> Dict[str, float]:
    """Median, quartiles, minimum and count of a list of timings."""
    values = sorted(float(value) for value in samples if value is not None and math.isfinite(float(value)))
    if not values:
        return {"median": float("nan"), "q1": float("nan"), "q3": float("nan"), "minimum": float("nan"), "count": 0}
    if len(values) == 1:
        first_quartile = third_quartile = values[0]
    else:
        first_quartile, _, third_quartile = statistics.quantiles(values, n=4, method="inclusive")
    return {"median": statistics.median(values), "q1": first_quartile, "q3": third_quartile,
            "minimum": values[0], "count": len(values)}


# ---------------------------------------------------------------------------
# Component modules: which modules to time and count
# ---------------------------------------------------------------------------

def called_module_names(model, run_once: Callable[[], object]) -> set:
    """Names of the modules whose forward is entered through ``__call__`` during one pass."""
    names_by_identity = {id(module): name for name, module in model.named_modules()}
    called = set()

    def record_call(module, arguments):
        """Pre-hook: remember that this module ran."""
        called.add(names_by_identity.get(id(module), "<unnamed>"))

    handles = [module.register_forward_pre_hook(record_call) for module in model.modules()]
    try:
        run_once()
    finally:
        for handle in handles:
            handle.remove()
    return called


def covering_modules(modules_by_name: Dict[str, object], path: str, called: set) -> List[str]:
    """Modules whose summed work equals the inclusive work of ``path``.

    The path itself if its forward runs; otherwise (containers such as ModuleList or
    ModuleDict, or modules whose methods are called directly, like Chameleon's VQ
    ``encode``) the top-most descendants that do run, found recursively.
    """
    if path in called:
        return [path]
    module = modules_by_name.get(path)
    if module is None:
        return []
    covering = []
    for child_name, _ in module.named_children():
        child_path = f"{path}.{child_name}" if path else child_name
        covering.extend(covering_modules(modules_by_name, child_path, called))
    return covering


def resolve_component_modules(model, component_paths: Dict[str, List[str]],
                              called: set) -> Dict[str, List[Tuple[int, str]]]:
    """Component -> list of (sign, module name); a path prefixed with "-" is subtracted."""
    modules_by_name = dict(model.named_modules())
    resolved = {}
    for component, paths in component_paths.items():
        entries = []
        for path in paths:
            sign = -1 if path.startswith("-") else 1
            for module_name in covering_modules(modules_by_name, path.lstrip("-"), called):
                entries.append((sign, module_name))
        resolved[component] = entries
    return resolved


class ComponentClock:
    """Time spent inside chosen modules, recorded at their forward boundaries.

    On a GPU each boundary records a CUDA event on the current stream, so the
    interval is the stream time between entering and leaving the module; on the
    CPU it is ``time.perf_counter``. Repeated calls of one module are summed.
    """

    def __init__(self, modules_by_name: Dict[str, object], device: str):
        """Prepare (but do not attach) the hooks for the given modules."""
        self.modules_by_name = modules_by_name
        self.device = device
        self.intervals: Dict[str, list] = {name: [] for name in modules_by_name}
        self.open_marks: Dict[str, list] = {name: [] for name in modules_by_name}
        self.handles = []

    def _mark(self):
        """A timestamp: a recorded CUDA event on the GPU, perf_counter seconds on the CPU."""
        import torch

        if is_gpu(self.device):
            event = torch.cuda.Event(enable_timing=True)
            event.record()
            return event
        return time.perf_counter()

    def _opener(self, module_name: str):
        """Forward pre-hook that opens an interval for one module."""
        def open_interval(module, arguments):
            """Record the entry mark."""
            self.open_marks[module_name].append(self._mark())
        return open_interval

    def _closer(self, module_name: str):
        """Forward hook that closes the latest open interval of one module."""
        def close_interval(module, arguments, output):
            """Record the exit mark."""
            if self.open_marks[module_name]:
                self.intervals[module_name].append((self.open_marks[module_name].pop(), self._mark()))
        return close_interval

    def attach(self) -> None:
        """Register the hooks."""
        for module_name, module in self.modules_by_name.items():
            self.handles.append(module.register_forward_pre_hook(self._opener(module_name)))
            self.handles.append(module.register_forward_hook(self._closer(module_name), always_call=True))

    def detach(self) -> None:
        """Remove the hooks."""
        for handle in self.handles:
            handle.remove()
        self.handles = []

    def reset(self) -> None:
        """Forget all recorded intervals."""
        for module_name in self.intervals:
            self.intervals[module_name] = []
            self.open_marks[module_name] = []

    def elapsed_milliseconds(self) -> Dict[str, float]:
        """Total time inside each module since the last reset."""
        synchronize(self.device)
        totals = {}
        for module_name, pairs in self.intervals.items():
            if is_gpu(self.device):
                totals[module_name] = sum(start.elapsed_time(end) for start, end in pairs)
            else:
                totals[module_name] = sum(1000.0 * (end - start) for start, end in pairs)
        return totals


# ---------------------------------------------------------------------------
# FLOPs, memory, prediction
# ---------------------------------------------------------------------------

def count_flops_by_module(model, run_once: Callable[[], object]) -> Tuple[Dict[str, float], float]:
    """Inclusive FLOPs of one forward pass per module (names relative to the root), and the total.

    The math attention backend is forced so that attention appears as explicit
    matmuls (as with the eager attention of the notebook 27 validation).
    """
    import torch
    from torch.nn.attention import SDPBackend, sdpa_kernel
    from torch.utils.flop_counter import FlopCounterMode

    counter = FlopCounterMode(display=False)
    with torch.no_grad(), sdpa_kernel(SDPBackend.MATH), counter:
        run_once()
    root = type(model).__name__
    flops_by_module = {}
    for key, operations in counter.get_flop_counts().items():
        if key == "Global":
            continue
        if key == root:
            relative_name = ""
        elif key.startswith(root + "."):
            relative_name = key[len(root) + 1:]
        else:
            relative_name = key
        flops_by_module[relative_name] = float(sum(operations.values()))
    return flops_by_module, float(counter.get_total_flops())


def component_values(module_values: Dict[str, float],
                     component_modules: Dict[str, List[Tuple[int, str]]]) -> Dict[str, float]:
    """Signed sum of per-module values (milliseconds or FLOPs) for every component."""
    return {component: sum(sign * module_values.get(module_name, 0.0) for sign, module_name in entries)
            for component, entries in component_modules.items()}


def peak_memory_during(run_once: Callable[[], object], device: str) -> Dict[str, Optional[float]]:
    """Resident and peak allocated GPU memory (GB) around one call; None on the CPU."""
    import torch

    if not is_gpu(device):
        return {"resident_gb": None, "peak_gb": None, "activation_peak_gb": None}
    torch.cuda.synchronize()
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    resident = torch.cuda.memory_allocated()
    run_once()
    torch.cuda.synchronize()
    peak = torch.cuda.max_memory_allocated()
    return {"resident_gb": resident / 1e9, "peak_gb": peak / 1e9, "activation_peak_gb": (peak - resident) / 1e9}


def predicted_components(model_name: str, parameter_shapes: Dict[str, Tuple[int, ...]], account: TokenAccount,
                         text_tokens: int, head_positions: int = 1, **cost_options) -> Dict[str, float]:
    """Predicted GFLOPs per component for one input (LM head charged at ``head_positions``)."""
    breakdown = forward_cost_revised(model_name, parameter_shapes, account, text_tokens=text_tokens, **cost_options)
    language = breakdown.llm_visual_g + breakdown.llm_text_g
    head = breakdown.head_g * head_positions
    total = breakdown.encoder_g + breakdown.fusion_g + language + head
    return {VISION: breakdown.encoder_g, FUSION: breakdown.fusion_g, LANGUAGE: language, HEAD: head,
            "total": total, "vision_compute_share_pct": 100.0 * breakdown.encoder_g / total if total else float("nan"),
            "head_positions": head_positions, "unrouted_parameters": len(breakdown.unrouted_parameters)}


# ---------------------------------------------------------------------------
# Harnesses
# ---------------------------------------------------------------------------

@dataclass
class ModelHarness:
    """Everything the measurement loop needs to drive one model.

    Attributes:
        model_name: roster name.
        repository: weights repository actually loaded.
        model: the loaded model (eval mode, no gradients).
        device: "cuda" or "cpu".
        mode: "released" (real weights) or "reduced" (dry run).
        component_paths: component -> module paths (prefix "-" to subtract).
        build_batch: (height, width) -> model inputs on the device.
        run_forward: one prefill forward pass on a batch.
        run_generate: (batch, new tokens) -> greedy generation; None if not generative.
        executed_account: (batch, height, width) -> TokenAccount of what actually runs.
        intrinsic_account: (height, width) -> TokenAccount of the revised protocol (no padding).
        text_tokens: (batch, account) -> prompt tokens on the language side.
        head_positions: batch -> positions at which the forward computes LM-head logits.
        cost_options: extra arguments for ``forward_cost_revised`` (both predictions).
        counting_context: optional context-manager factory entered only for the FLOP-counting
            passes (Gemma 4 26B-A4B: the eager expert loop, whose products the counter sees;
            timing keeps the released default kernel).
        executed_cost_options: extra arguments for the prediction of the executed input only
            (how the released code computes an operation, e.g. DeepSeek-VL2's absorbed latent attention).
        notes: free-text remarks stored with the result.
        load_seconds: time to load the model.
    """

    model_name: str
    repository: str
    model: object
    device: str
    mode: str
    component_paths: Dict[str, List[str]]
    build_batch: Callable[[int, int], dict]
    run_forward: Callable[[dict], object]
    run_generate: Optional[Callable[[dict, int], object]]
    executed_account: Callable[[dict, int, int], TokenAccount]
    intrinsic_account: Callable[[int, int], TokenAccount]
    text_tokens: Callable[[dict, TokenAccount], int]
    head_positions: Callable[[dict], int]
    cost_options: Dict[str, object] = field(default_factory=dict)
    executed_cost_options: Dict[str, object] = field(default_factory=dict)
    notes: List[str] = field(default_factory=list)
    load_seconds: float = 0.0
    counting_context: Optional[Callable[[], object]] = None


def dtype_keyword() -> str:
    """``dtype`` on transformers >= 4.56 (preferred), ``torch_dtype`` on older releases."""
    import transformers
    from packaging import version

    return "dtype" if version.parse(transformers.__version__) >= version.parse("4.56") else "torch_dtype"


def load_pretrained(model_class, repository: str, device: str, **load_kwargs):
    """Load released weights in bfloat16 straight onto ``device``; fall back to load-then-move."""
    import torch

    load_kwargs = dict(load_kwargs, **{dtype_keyword(): torch.bfloat16})
    try:
        model = model_class.from_pretrained(repository, device_map=device, **load_kwargs)
    except (ValueError, NotImplementedError, KeyError) as error:
        # Some remote-code classes cannot be dispatched by accelerate; load on the CPU first.
        print(f"    device_map load failed ({type(error).__name__}: {error}); loading on CPU, then moving")
        model = model_class.from_pretrained(repository, low_cpu_mem_usage=True, **load_kwargs).to(device)
    model.requires_grad_(False)
    return model.eval()


def set_padding_token(model) -> None:
    """Give generation a pad token (the end-of-sequence token) when the checkpoint has none."""
    generation_config = getattr(model, "generation_config", None)
    if generation_config is None or generation_config.pad_token_id is not None:
        return
    end_of_sequence = generation_config.eos_token_id
    if isinstance(end_of_sequence, (list, tuple)):
        end_of_sequence = end_of_sequence[0] if end_of_sequence else None
    if end_of_sequence is not None:
        generation_config.pad_token_id = end_of_sequence


def processor_class_name(model_name: str) -> str:
    """Class of the processor that builds this model's inputs (recorded so wrong resolutions are auditable)."""
    from .flop_counter_validation import _PROCESSOR_FROM_ACCOUNTING, _load_other_processor
    from .token_accounting import load_processor

    spec = validation_spec(model_name)
    processor = load_processor(model_name) if model_name in _PROCESSOR_FROM_ACCOUNTING else _load_other_processor(spec)
    return type(processor).__name__


def native_harness(model_name: str, mode: str = "released", device: str = "cuda") -> ModelHarness:
    """Harness for a transformers-native model (4.57: notebook 29; Gemma 4, transformers >= 5.10: notebook 34)."""
    import transformers

    spec = validation_spec(model_name)
    started = time.perf_counter()
    if mode == "released":
        model = load_pretrained(getattr(transformers, spec.model_class), spec.repository, device)
    elif mode == "reduced":
        model = build_reduced_model(model_name).to(device)
    else:
        raise ValueError(f"mode must be 'released' or 'reduced', not {mode!r}")
    load_seconds = time.perf_counter() - started
    set_padding_token(model)
    processor_kwargs = RELEASED_PROCESSOR_KWARGS.get(model_name, {})

    def build_batch(height: int, width: int) -> dict:
        """Released processor on the structured test image, moved to the device."""
        batch = build_validation_inputs(model_name, image_size=(height, width), processor_kwargs=processor_kwargs,
                                        image=structured_test_image(height, width))
        return move_to_device(batch, device)

    def run_forward(batch: dict):
        """One prefill pass with the forward arguments validated in notebook 27."""
        return model(**batch, **spec.forward_kwargs)

    def run_generate(batch: dict, new_tokens: int):
        """Greedy generation of exactly ``new_tokens`` tokens."""
        return model.generate(**batch, max_new_tokens=new_tokens, min_new_tokens=new_tokens, do_sample=False)

    def executed_account(batch: dict, height: int, width: int) -> TokenAccount:
        """Token account of the executed input (padding included where the implementation runs it)."""
        return validation_token_account(model_name, batch, model, image_size=(height, width))

    def text_tokens(batch: dict, account: TokenAccount) -> int:
        """Prompt tokens on the language side of the executed input."""
        return executed_text_tokens(model_name, batch, account)

    # Some forward signatures silently drop logits_to_keep (Qwen2-VL in transformers 4.57) and
    # compute logits at every position; that is the work executed, so the prediction follows it.
    requests_last_position = "logits_to_keep" in spec.forward_kwargs
    honours_last_position = "logits_to_keep" in inspect.signature(model.forward).parameters

    def head_positions(batch: dict) -> int:
        """Positions with LM-head logits in this forward signature."""
        every_position = model_name in HEAD_ON_EVERY_POSITION or (requests_last_position and not honours_last_position)
        if every_position and "input_ids" in batch:
            return int(batch["input_ids"].shape[1])
        return 1

    cost_options = {}
    if mode == "reduced" and spec.qwen25_full_attention_layers is not None:
        cost_options["qwen25_full_attention_layers"] = spec.qwen25_full_attention_layers
    notes = [f"processor class: {processor_class_name(model_name)}"]
    if requests_last_position and not honours_last_position:
        notes.append("forward ignores logits_to_keep: LM-head logits are computed at every position")
    counting_context = None
    if spec.model_kwargs.get("experts_implementation") == "eager" and hasattr(model, "set_experts_implementation"):
        @contextlib.contextmanager
        def eager_experts():
            """The eager expert loop during counting only (same products; the default kernel is invisible to the counter)."""
            previous = model.get_experts_implementation()
            model.set_experts_implementation("eager")
            try:
                yield
            finally:
                model.set_experts_implementation(previous)

        counting_context = eager_experts
        notes.append(f"experts: timed with the released default kernel {model.get_experts_implementation()}; "
                     "FLOPs counted with the eager expert loop")
    return ModelHarness(
        model_name=model_name, repository=spec.repository, model=model, device=device, mode=mode,
        component_paths=spec.component_modules, build_batch=build_batch, run_forward=run_forward,
        run_generate=None if model_name in NON_GENERATIVE_MODELS else run_generate,
        executed_account=executed_account,
        intrinsic_account=lambda height, width: account_visual_tokens(model_name, height, width),
        text_tokens=text_tokens, head_positions=head_positions, cost_options=cost_options, notes=notes,
        load_seconds=load_seconds, counting_context=counting_context,
    )


def install_xformers_shim() -> bool:
    """Route ``xformers.ops.memory_efficient_attention`` to PyTorch SDPA when xformers is absent.

    DeepSeek-VL2's SigLIP attention imports xformers inside its forward. The two
    compute the same attention; xformers uses (batch, sequence, heads, head_dim)
    and SDPA (batch, heads, sequence, head_dim). Returns True if the shim was installed.
    """
    import types

    import torch

    try:
        import xformers.ops  # noqa: F401
        return False
    except ImportError:
        pass

    def memory_efficient_attention(query, key, value, attn_bias=None, p=0.0, scale=None):
        """SDPA with the xformers tensor layout."""
        output = torch.nn.functional.scaled_dot_product_attention(
            query.transpose(1, 2), key.transpose(1, 2), value.transpose(1, 2),
            attn_mask=attn_bias, dropout_p=p, scale=scale)
        return output.transpose(1, 2)

    package = types.ModuleType("xformers")
    operations = types.ModuleType("xformers.ops")
    operations.memory_efficient_attention = memory_efficient_attention
    package.ops = operations
    sys.modules["xformers"] = package
    sys.modules["xformers.ops"] = operations
    return True


def randomise_parameters(model, seed: int = 0) -> None:
    """Fill every parameter with N(0, 0.02) values (dry run of classes that leave weights uninitialised)."""
    import torch

    torch.manual_seed(seed)
    with torch.no_grad():
        for parameter in model.parameters():
            parameter.normal_(0.0, 0.02)


def molmo_harness(mode: str = "released", device: str = "cuda") -> ModelHarness:
    """Harness for Molmo-7B-D (remote code; transformers 4.46.x)."""
    import torch
    from transformers import AutoConfig, AutoModelForCausalLM, AutoProcessor, GenerationConfig

    started = time.perf_counter()
    processor = AutoProcessor.from_pretrained(MOLMO_REPOSITORY, trust_remote_code=True)
    if mode == "released":
        model = load_pretrained(AutoModelForCausalLM, MOLMO_REPOSITORY, device, trust_remote_code=True)
    elif mode == "reduced":
        configuration = AutoConfig.from_pretrained(MOLMO_REPOSITORY, trust_remote_code=True)
        configuration.num_hidden_layers = 2          # the vision backbone keeps its released depth
        model = AutoModelForCausalLM.from_config(configuration, trust_remote_code=True)
        randomise_parameters(model)
        model = model.to(device=device, dtype=torch.bfloat16).eval()
        model.requires_grad_(False)
    else:
        raise ValueError(f"mode must be 'released' or 'reduced', not {mode!r}")
    load_seconds = time.perf_counter() - started
    tokenizer = processor.tokenizer
    image_token_ids = {tokenizer.convert_tokens_to_ids(token) for token in MOLMO_IMAGE_TOKEN_STRINGS}

    def build_batch(height: int, width: int) -> dict:
        """Released processor (``process``) on the test image, batched and moved to the device."""
        inputs = processor.process(images=[structured_test_image(height, width)], text=TEXT_PROMPT)
        batch = {key: value.unsqueeze(0) for key, value in inputs.items()}
        return move_to_device(batch, device, float_dtype=torch.bfloat16)

    def run_forward(batch: dict):
        """One prefill pass; logits at the last position only."""
        return model(**batch, last_logits_only=True)

    def run_generate(batch: dict, new_tokens: int):
        """Greedy generation of exactly ``new_tokens`` tokens through Molmo's own entry point."""
        configuration = GenerationConfig(max_new_tokens=new_tokens, min_new_tokens=new_tokens, do_sample=False,
                                         use_cache=True)
        return model.generate_from_batch(batch, configuration, tokenizer=tokenizer)

    def executed_account(batch: dict, height: int, width: int) -> TokenAccount:
        """Re-implemented Molmo tiling, checked against what the processor produced."""
        account = account_molmo(height, width)
        crops_executed = int(batch["images"].shape[1])
        image_tokens = sum(1 for token_id in batch["input_ids"][0].tolist() if token_id in image_token_ids)
        account.details["crops_executed"] = crops_executed
        account.details["language_image_tokens_executed"] = image_tokens
        account.details["matches_processor"] = (crops_executed == account.details["crops_plus_global"]
                                                and image_tokens == account.language_visual_tokens)
        return account

    def text_tokens(batch: dict, account: TokenAccount) -> int:
        """Prompt tokens: every input id that is not an image token."""
        sequence = batch["input_ids"][0].tolist()
        return sum(1 for token_id in sequence if token_id not in image_token_ids)

    harness = ModelHarness(
        model_name="Molmo-7B-D", repository=MOLMO_REPOSITORY, model=model, device=device, mode=mode,
        component_paths={VISION: ["model.vision_backbone.image_vit"],
                         FUSION: ["model.vision_backbone", "-model.vision_backbone.image_vit"],
                         LANGUAGE: ["model.transformer", "-model.transformer.ff_out"],
                         HEAD: ["model.transformer.ff_out"]},
        build_batch=build_batch, run_forward=run_forward, run_generate=run_generate,
        executed_account=executed_account, intrinsic_account=account_molmo,
        text_tokens=text_tokens, head_positions=lambda batch: 1, load_seconds=load_seconds,
    )
    if mode == "reduced":
        harness.notes.append("dry run: 2 language layers, random weights; vision backbone at released depth")
    return harness


def deepseek_vl2_harness(mode: str = "released", device: str = "cuda") -> ModelHarness:
    """Harness for DeepSeek-VL2-Small (deepseek_vl2 package at DEEPSEEK_VL2_CODE_COMMIT; transformers 4.46.x)."""
    import torch

    shim_installed = install_xformers_shim()
    import transformers.models.llama.modeling_llama as llama_module
    if not hasattr(llama_module, "LlamaFlashAttention2"):
        # Imported at module level by the package, never used without flash-attn.
        llama_module.LlamaFlashAttention2 = llama_module.LlamaAttention
    from deepseek_vl2.models import DeepseekVLV2ForCausalLM, DeepseekVLV2Processor
    from deepseek_vl2.models.modeling_deepseek_vl_v2 import DeepseekVLV2Config

    started = time.perf_counter()
    processor = DeepseekVLV2Processor.from_pretrained(DEEPSEEK_VL2_REPOSITORY)
    if mode == "released":
        model = load_pretrained(DeepseekVLV2ForCausalLM, DEEPSEEK_VL2_REPOSITORY, device)
    elif mode == "reduced":
        configuration = DeepseekVLV2Config.from_pretrained(DEEPSEEK_VL2_REPOSITORY)
        configuration.language_config.num_hidden_layers = 2      # layer 0 dense, layer 1 mixture-of-experts
        configuration.vision_config.layers = 2
        model = DeepseekVLV2ForCausalLM._from_config(configuration, **{dtype_keyword(): torch.bfloat16})
        model = model.to(device=device, dtype=torch.bfloat16).eval()
        model.requires_grad_(False)
    else:
        raise ValueError(f"mode must be 'released' or 'reduced', not {mode!r}")
    load_seconds = time.perf_counter() - started
    tokenizer = processor.tokenizer

    def build_batch(height: int, width: int) -> dict:
        """Released processor (one image, cropping on, as for one or two images) on the test image."""
        conversation = [{"role": "<|User|>", "content": f"<image>\n{TEXT_PROMPT}", "images": ["test-image"]},
                        {"role": "<|Assistant|>", "content": ""}]
        inputs = processor(conversations=conversation, images=[structured_test_image(height, width)],
                           force_batchify=True, system_prompt="")
        batch = {"input_ids": inputs.input_ids, "attention_mask": inputs.attention_mask, "images": inputs.images,
                 "images_seq_mask": inputs.images_seq_mask, "images_spatial_crop": inputs.images_spatial_crop}
        return move_to_device(batch, device, float_dtype=torch.bfloat16)

    def run_forward(batch: dict):
        """One prefill pass (this forward computes logits at every position)."""
        return model(**batch, use_cache=True)

    def run_generate(batch: dict, new_tokens: int):
        """Greedy generation of exactly ``new_tokens`` tokens."""
        return model.generate(**batch, max_new_tokens=new_tokens, min_new_tokens=new_tokens, do_sample=False,
                              pad_token_id=tokenizer.eos_token_id, bos_token_id=tokenizer.bos_token_id,
                              eos_token_id=tokenizer.eos_token_id, use_cache=True)

    def executed_account(batch: dict, height: int, width: int) -> TokenAccount:
        """Re-implemented DeepSeek-VL2 tiling, checked against what the processor produced."""
        account = account_deepseek_vl2(height, width)
        width_tiles, height_tiles = (int(value) for value in batch["images_spatial_crop"][0, 0].tolist())
        image_tokens = int(batch["images_seq_mask"][0].sum())
        account.details["tiles_executed"] = 1 + width_tiles * height_tiles
        account.details["language_image_tokens_executed"] = image_tokens
        account.details["matches_processor"] = (1 + width_tiles * height_tiles == account.details["tiles_plus_global"]
                                                and image_tokens == account.language_visual_tokens)
        return account

    def text_tokens(batch: dict, account: TokenAccount) -> int:
        """Prompt tokens: sequence length minus the image positions."""
        return int(batch["input_ids"].shape[1]) - int(batch["images_seq_mask"][0].sum())

    harness = ModelHarness(
        model_name="DeepSeek-VL2-Small", repository=DEEPSEEK_VL2_REPOSITORY, model=model, device=device, mode=mode,
        component_paths={VISION: ["vision"], FUSION: ["projector"], LANGUAGE: ["language.model"],
                         HEAD: ["language.lm_head"]},
        build_batch=build_batch, run_forward=run_forward, run_generate=run_generate,
        executed_account=executed_account, intrinsic_account=account_deepseek_vl2,
        text_tokens=text_tokens, head_positions=lambda batch: int(batch["input_ids"].shape[1]),
        executed_cost_options={"mla_attention_form": "absorbed"}, load_seconds=load_seconds,
    )
    harness.notes.append("released code computes latent attention in the absorbed form; the executed "
                         "prediction uses mla_attention_form='absorbed', the intrinsic one the Table 3 default")
    if shim_installed:
        harness.notes.append("xformers absent: SigLIP memory_efficient_attention routed to torch SDPA")
    if mode == "reduced":
        harness.notes.append("dry run: 2 language layers, 2 vision layers, random weights")
    return harness


def weights_repository(model_name: str) -> str:
    """The repository whose weights the harness of ``model_name`` downloads."""
    if model_name == "Molmo-7B-D":
        return MOLMO_REPOSITORY
    if model_name == "DeepSeek-VL2-Small":
        return DEEPSEEK_VL2_REPOSITORY
    return validation_spec(model_name).repository


def build_harness(model_name: str, mode: str = "released", device: str = "cuda") -> ModelHarness:
    """The right harness for any roster model."""
    if model_name == "Molmo-7B-D":
        return molmo_harness(mode, device)
    if model_name == "DeepSeek-VL2-Small":
        return deepseek_vl2_harness(mode, device)
    return native_harness(model_name, mode, device)


# ---------------------------------------------------------------------------
# Measurement loop
# ---------------------------------------------------------------------------

def _stage(stage_name: str, size_result: dict, logger, function: Callable[[], object]):
    """Run one measurement stage; on failure record the traceback and carry on."""
    import torch

    try:
        return function()
    except Exception as error:   # noqa: BLE001 - every failure is recorded, the run continues
        size_result.setdefault("errors", {})[stage_name] = "".join(traceback.format_exception(error))
        message = f"stage '{stage_name}' failed: {type(error).__name__}: {str(error)[:300]}"
        print(f"    ERROR {message}")
        if logger is not None:
            logger.error(message, error)
        if isinstance(error, torch.cuda.OutOfMemoryError):
            torch.cuda.empty_cache()
        return None


def measure_one_input(harness: ModelHarness, height: int, width: int, settings: MeasurementSettings,
                      logger=None) -> dict:
    """Every measurement for one model on one input image."""
    import torch

    def note(message: str) -> None:
        """Print and log one progress line."""
        print(f"    {message}")
        if logger is not None:
            logger.info(message)

    model, device = harness.model, harness.device
    size_result: dict = {"image_height": height, "image_width": width, "errors": {}}
    batch = _stage("build_batch", size_result, logger, lambda: harness.build_batch(height, width))
    if batch is None:
        size_result["status"] = "failed"
        return size_result

    def run_once():
        """One prefill pass without gradients."""
        with torch.no_grad():
            return harness.run_forward(batch)

    def run_once_counted():
        """Prefill pass for the FLOP counters (inside the harness's counting context, if any)."""
        if harness.counting_context is None:
            return run_once()
        with harness.counting_context():
            return run_once()

    # Token accounts: what actually runs, and the revised (intrinsic) protocol of Table 3.
    executed = _stage("executed_account", size_result, logger, lambda: harness.executed_account(batch, height, width))
    intrinsic = _stage("intrinsic_account", size_result, logger, lambda: harness.intrinsic_account(height, width))
    if executed is not None:
        size_result["executed_account"] = executed.to_row()
        text_tokens = _stage("text_tokens", size_result, logger, lambda: harness.text_tokens(batch, executed))
        if text_tokens is None:
            executed = None       # no prediction without the prompt length
        else:
            size_result["executed_text_tokens"] = text_tokens
    if intrinsic is not None:
        size_result["intrinsic_account"] = intrinsic.to_row()
    if "input_ids" in batch:
        size_result["sequence_length"] = int(batch["input_ids"].shape[1])
    size_result["head_positions"] = harness.head_positions(batch)
    note(f"{height}x{width}: executed visual tokens in LLM = {getattr(executed, 'language_visual_tokens', '?')}, "
         f"encoder tokens = {getattr(executed, 'encoder_tokens', '?')}, "
         f"text tokens = {size_result.get('executed_text_tokens', '?')}")

    # Discovery pass (also the first warm-up): which modules run, and the component boundaries.
    called = _stage("discover_modules", size_result, logger, lambda: called_module_names(model, run_once))
    if called is None:
        size_result["status"] = "failed"
        return size_result
    component_modules = resolve_component_modules(model, harness.component_paths, called)
    size_result["component_modules"] = {component: [[sign, name] for sign, name in entries]
                                        for component, entries in component_modules.items()}

    # Full-depth FLOP count and the cost-model prediction for the same executed input.
    measured_vision_gflops = None
    if settings.count_flops:
        counted = _stage("count_flops", size_result, logger, lambda: count_flops_by_module(model, run_once_counted))
        if counted is not None:
            flops_by_module, total_flops = counted
            measured = {component: value / 1e9 for component, value in
                        component_values(flops_by_module, component_modules).items()}
            measured["total"] = total_flops / 1e9
            size_result["measured_gflops"] = measured
            measured_vision_gflops = measured.get(VISION)
            note(f"measured FLOPs (full depth): {measured['total']:.1f} G")
    shapes = {name: tuple(parameter.shape) for name, parameter in model.named_parameters()}
    cost_options = dict(harness.cost_options)
    if harness.model_name == "Chameleon-7B":
        cost_options["measured_encoder_gflops"] = measured_vision_gflops or CHAMELEON_VQ_ENCODER_GFLOPS
    if executed is not None:
        executed_options = dict(cost_options, **harness.executed_cost_options)
        predicted = _stage("predict_executed", size_result, logger, lambda: predicted_components(
            harness.model_name, shapes, executed, size_result["executed_text_tokens"],
            head_positions=size_result["head_positions"], **executed_options))
        if predicted is not None:
            size_result["predicted_executed_gflops"] = predicted
            note(f"predicted FLOPs (executed input): {predicted['total']:.1f} G")
            if "measured_gflops" in size_result:
                size_result["flop_relative_difference_pct"] = {
                    component: 100.0 * (predicted[component] - size_result["measured_gflops"][component])
                    / size_result["measured_gflops"][component]
                    for component in COMPONENTS
                    if size_result["measured_gflops"].get(component)}
    if intrinsic is not None:
        size_result["predicted_intrinsic_gflops"] = _stage("predict_intrinsic", size_result, logger, lambda: (
            predicted_components(harness.model_name, shapes, intrinsic, 32, head_positions=1, **cost_options)))

    # Element-wise work (norms, activations, softmax, residuals) left out of the matmul count.
    if settings.count_elementwise and "measured_gflops" in size_result:
        elementwise = _stage("count_elementwise", size_result, logger, lambda: elementwise_flops_of(run_once_counted))
        if elementwise is not None:
            matmul_gflops = size_result["measured_gflops"]["total"]
            size_result["elementwise_gflops"] = elementwise / 1e9
            size_result["elementwise_share_pct"] = 100.0 * (elementwise / 1e9) / (matmul_gflops + elementwise / 1e9)
            note(f"element-wise work: {size_result['elementwise_share_pct']:.2f}% of all FLOPs")

    # Whole-model prefill latency.
    def prefill_series():
        """Warm-up, then timed prefill passes."""
        for _ in range(settings.warmup_runs):
            run_once()
        wall_samples, device_samples = [], []
        for _ in range(settings.timed_runs):
            wall_milliseconds, device_milliseconds, _ = time_call(run_once, device)
            wall_samples.append(wall_milliseconds)
            device_samples.append(device_milliseconds)
        return wall_samples, device_samples

    series = _stage("prefill_latency", size_result, logger, prefill_series)
    if series is not None:
        size_result["prefill_wall_ms"], size_result["prefill_device_ms"] = series
        size_result["prefill_wall_ms_summary"] = describe_samples(series[0])
        note(f"prefill latency: median {size_result['prefill_wall_ms_summary']['median']:.2f} ms "
             f"(n = {settings.timed_runs})")

    memory = _stage("prefill_memory", size_result, logger, lambda: peak_memory_during(run_once, device))
    if memory is not None:
        size_result["prefill_memory"] = memory

    # Per-component prefill latency (hooks attached only for this series).
    modules_by_name = dict(model.named_modules())
    timed_modules = {name: modules_by_name[name] for entries in component_modules.values() for _, name in entries}

    def component_series():
        """Warm-up with hooks attached, then timed passes; component ms per pass."""
        clock = ComponentClock(timed_modules, device)
        clock.attach()
        try:
            for _ in range(settings.warmup_runs):
                run_once()
            per_component = {component: [] for component in component_modules}
            totals = []
            for _ in range(settings.timed_runs):
                clock.reset()
                wall_milliseconds, _, _ = time_call(run_once, device)
                by_component = component_values(clock.elapsed_milliseconds(), component_modules)
                for component, milliseconds in by_component.items():
                    per_component[component].append(milliseconds)
                totals.append(wall_milliseconds)
            return per_component, totals
        finally:
            clock.detach()

    components = _stage("component_latency", size_result, logger, component_series)
    if components is not None:
        size_result["component_ms"], size_result["component_run_wall_ms"] = components
        size_result["component_ms_summary"] = {component: describe_samples(samples)
                                               for component, samples in components[0].items()}
        shares = ", ".join(f"{component} {summary['median']:.2f}"
                           for component, summary in size_result["component_ms_summary"].items())
        note(f"component latency (median ms): {shares}")

    # Decode latency per token: two generate calls that differ only in the number of new tokens.
    if harness.run_generate is not None:
        def decode_series():
            """Short (1 token) and long (1 + K tokens) greedy generations."""
            short_samples, long_samples, lengths = [], [], []
            with torch.no_grad():
                harness.run_generate(batch, 1)            # warm-up
                for _ in range(settings.decode_runs):
                    short_ms, _, _ = time_call(lambda: harness.run_generate(batch, 1), device)
                    long_ms, _, output = time_call(
                        lambda: harness.run_generate(batch, 1 + settings.decode_new_tokens), device)
                    short_samples.append(short_ms)
                    long_samples.append(long_ms)
                    sequences = getattr(output, "sequences", output)
                    lengths.append(int(sequences.shape[-1]) if hasattr(sequences, "shape") else None)
            per_token = ((statistics.median(long_samples) - statistics.median(short_samples))
                         / settings.decode_new_tokens)
            return {"new_tokens": settings.decode_new_tokens, "short_generate_ms": short_samples,
                    "long_generate_ms": long_samples, "output_lengths": lengths, "per_token_ms": per_token}

        decode = _stage("decode_latency", size_result, logger, decode_series)
        if decode is not None:
            size_result["decode"] = decode
            note(f"decode latency: {decode['per_token_ms']:.2f} ms per token")
        generate_memory = _stage("decode_memory", size_result, logger, lambda: peak_memory_during(
            lambda: harness.run_generate(batch, 1 + settings.decode_new_tokens), device))
        if generate_memory is not None:
            size_result["decode_memory"] = generate_memory

    required = ("measured_gflops", "predicted_executed_gflops", "prefill_wall_ms", "component_ms")
    required = required if settings.count_flops else required[1:]
    size_result["status"] = "complete" if not size_result["errors"] and all(
        key in size_result for key in required) else "partial"
    del batch
    if is_gpu(device):
        torch.cuda.empty_cache()
    return size_result


def measure_model(harness: ModelHarness, settings: MeasurementSettings, logger=None,
                  save: Optional[Callable[[dict], None]] = None, previous: Optional[dict] = None) -> dict:
    """Measure one model on every input size; ``save`` is called after each size (partial results survive)."""
    import torch

    model = harness.model
    parameter_count = sum(parameter.numel() for parameter in model.parameters())
    active_parameter_count = parameter_count
    if harness.model_name in MOE_ACTIVE_FRACTION:
        # Routed experts are read for the active fraction per token (DeepSeek-VL2 6 of 64, Gemma 4 26B-A4B 8 of
        # 128); shared experts, dense MLPs and everything else always.
        routed = sum(parameter.numel() for name, parameter in model.named_parameters()
                     if re.search(ROUTED_EXPERT_PATTERN, name))
        active_parameter_count = parameter_count - routed * (1.0 - MOE_ACTIVE_FRACTION[harness.model_name])
    result = previous or {}
    result.update({
        "model": harness.model_name, "repository": harness.repository, "mode": harness.mode,
        "device": harness.device, "dtype": "bfloat16",
        "resolved_commit": getattr(getattr(model, "config", None), "_commit_hash", None),
        "attention_implementation": getattr(getattr(model, "config", None), "_attn_implementation", None),
        "parameter_count": parameter_count, "active_parameter_count": active_parameter_count,
        "load_seconds": harness.load_seconds, "notes": harness.notes,
        "settings": asdict(settings), "gpu": gpu_description(harness.device),
        "library_versions": library_versions(),
    })
    result.setdefault("inputs", {})
    result["started"] = result.get("started") or datetime.now().isoformat(timespec="seconds")
    if is_gpu(harness.device):
        result["weights_resident_gb"] = torch.cuda.memory_allocated() / 1e9
    result["gpu_state_before"] = gpu_state()
    for side in settings.image_sides:
        key = f"{side}x{side}"
        if result["inputs"].get(key, {}).get("status") == "complete":
            print(f"  {key}: already complete, skipped")
            continue
        print(f"  input {key}")
        if logger is not None:
            logger.section(f"{harness.model_name} at {key}")
        result["inputs"][key] = measure_one_input(harness, side, side, settings, logger)
        if save is not None:
            save(result)
    result["gpu_state_after"] = gpu_state()
    statuses = [result["inputs"].get(f"{side}x{side}", {}).get("status") for side in settings.image_sides]
    result["status"] = ("complete" if all(status == "complete" for status in statuses)
                        else "failed" if all(status == "failed" for status in statuses) else "partial")
    result["finished"] = datetime.now().isoformat(timespec="seconds")
    if save is not None:
        save(result)
    return result


# ---------------------------------------------------------------------------
# Environment, results and cache
# ---------------------------------------------------------------------------

def library_versions() -> Dict[str, Optional[str]]:
    """Versions of the libraries that affect the measurements."""
    versions = {"python": platform.python_version()}
    for package_name in ("torch", "transformers", "accelerate", "huggingface_hub", "tokenizers", "timm"):
        try:
            module = __import__(package_name)
            versions[package_name] = getattr(module, "__version__", None)
        except ImportError:
            versions[package_name] = None
    try:
        import torch

        versions["cuda"] = torch.version.cuda
        versions["cudnn"] = str(torch.backends.cudnn.version()) if torch.backends.cudnn.is_available() else None
    except ImportError:
        pass
    return versions


def gpu_description(device: str) -> Dict[str, object]:
    """Name, memory and compute capability of the GPU (empty on the CPU)."""
    import torch

    if not is_gpu(device) or not torch.cuda.is_available():
        return {"name": "cpu", "processor": platform.processor()}
    properties = torch.cuda.get_device_properties(0)
    return {"name": properties.name, "total_memory_gb": properties.total_memory / 1e9,
            "compute_capability": f"{properties.major}.{properties.minor}",
            "multiprocessors": properties.multi_processor_count}


def gpu_state() -> Optional[str]:
    """One nvidia-smi line: clocks, temperature, power, memory (None without nvidia-smi)."""
    query = "name,clocks.sm,clocks.mem,clocks.max.sm,temperature.gpu,power.draw,memory.used,memory.total"
    try:
        completed = subprocess.run(["nvidia-smi", f"--query-gpu={query}", "--format=csv,noheader"],
                                   capture_output=True, text=True, timeout=30)
        return completed.stdout.strip() or None
    except (FileNotFoundError, subprocess.SubprocessError):
        return None


def environment_manifest() -> Dict[str, object]:
    """Everything needed to describe the measurement environment (no secrets)."""
    manifest = {"created": datetime.now().isoformat(timespec="seconds"), "platform": platform.platform(),
                "python_executable": sys.executable, "library_versions": library_versions(),
                "gpu": gpu_description("cuda"), "gpu_state": gpu_state()}
    try:
        manifest["nvidia_smi"] = subprocess.run(["nvidia-smi"], capture_output=True, text=True, timeout=30).stdout
    except (FileNotFoundError, subprocess.SubprocessError):
        manifest["nvidia_smi"] = None
    try:
        manifest["pip_freeze"] = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True,
                                                text=True, timeout=120).stdout.splitlines()
    except subprocess.SubprocessError:
        manifest["pip_freeze"] = None
    manifest["environment_variables"] = {name: value for name, value in os.environ.items()
                                         if name.startswith(("HF_HUB", "CUDA", "PYTORCH", "TRANSFORMERS"))
                                         and "TOKEN" not in name}
    return manifest


def result_path(results_directory, model_name: str) -> Path:
    """JSON file of one model's results."""
    safe_name = "".join(character if character.isalnum() or character in "-." else "_" for character in model_name)
    return Path(results_directory) / f"{safe_name}.json"


def save_result(result: dict, results_directory) -> Path:
    """Write one model's results atomically (temporary file, then rename)."""
    path = result_path(results_directory, result["model"])
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(result, indent=1, default=str), encoding="utf-8")
    os.replace(temporary, path)
    return path


def load_result(results_directory, model_name: str) -> Optional[dict]:
    """A previously saved result, or None."""
    path = result_path(results_directory, model_name)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def summary_rows(result: dict) -> List[Dict[str, object]]:
    """One flat row per (model, input size) for the summary tables."""
    rows = []
    for size_key, size_result in result.get("inputs", {}).items():
        executed = size_result.get("executed_account", {})
        predicted = size_result.get("predicted_executed_gflops") or {}
        intrinsic = size_result.get("predicted_intrinsic_gflops") or {}
        measured = size_result.get("measured_gflops") or {}
        prefill = size_result.get("prefill_wall_ms_summary") or {}
        components = size_result.get("component_ms_summary") or {}
        decode = size_result.get("decode") or {}
        memory = size_result.get("prefill_memory") or {}
        row = {
            "model": result["model"], "input": size_key, "status": size_result.get("status"),
            "gpu": (result.get("gpu") or {}).get("name"), "mode": result.get("mode"),
            "parameter_count": result.get("parameter_count"),
            "active_parameter_count": result.get("active_parameter_count", result.get("parameter_count")),
            "language_visual_tokens": executed.get("language_visual_tokens"),
            "encoder_tokens": executed.get("encoder_tokens"),
            "cross_attended_tokens": executed.get("cross_attended_tokens"),
            "text_tokens": size_result.get("executed_text_tokens"),
            "predicted_total_gflops": predicted.get("total"),
            "measured_total_gflops": measured.get("total"),
            "predicted_intrinsic_total_gflops": intrinsic.get("total"),
            "predicted_vision_share_pct": predicted.get("vision_compute_share_pct"),
            "elementwise_share_pct": size_result.get("elementwise_share_pct"),
            "prefill_ms_median": prefill.get("median"), "prefill_ms_q1": prefill.get("q1"),
            "prefill_ms_q3": prefill.get("q3"),
            "decode_ms_per_token": decode.get("per_token_ms"),
            "weights_resident_gb": result.get("weights_resident_gb"),
            "prefill_activation_peak_gb": memory.get("activation_peak_gb"),
            "errors": ";".join(sorted(size_result.get("errors", {}))),
        }
        for component in COMPONENTS:
            row[f"predicted_{component}_gflops"] = predicted.get(component)
            row[f"measured_{component}_gflops"] = measured.get(component)
            row[f"{component}_ms_median"] = (components.get(component) or {}).get("median")
        if row["predicted_total_gflops"] and row["prefill_ms_median"]:
            row["achieved_tflops_per_second"] = row["predicted_total_gflops"] / row["prefill_ms_median"]
        rows.append(row)
    return rows


def delete_cached_repository(repository: str) -> float:
    """Remove every cached revision of one Hugging Face repository; return GB freed."""
    from huggingface_hub import scan_cache_dir

    cache = scan_cache_dir()
    revisions = [revision.commit_hash for cached in cache.repos if cached.repo_id == repository
                 for revision in cached.revisions]
    if not revisions:
        return 0.0
    strategy = cache.delete_revisions(*revisions)
    freed = strategy.expected_freed_size
    strategy.execute()
    return freed / 1e9


def free_disk_gb(path: str = "/") -> float:
    """Free space on the file system that holds ``path`` (GB)."""
    import shutil

    return shutil.disk_usage(path).free / 1e9


def release_gpu_memory() -> None:
    """Return the memory of models no longer referenced to the GPU.

    The harness closures hold the model, so drop the harness itself first
    (``harness = None``), then call this.
    """
    import gc

    import torch

    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
