"""Visual-token accounting from each model's RELEASED preprocessing (reviewer items A9 / A5).

The published compute protocol (Section 3.2) priced each model at a hand-chosen
"default native configuration". Those choices were not comparable across the
roster (Pixtral at 1024 x 1024, Qwen2-VL at 448 x 448, LLaVA-NeXT at a 576-token
base view that its released processor never produces). This module replaces them
with token counts taken from the released preprocessing of every model for one
declared input image, so every model sees the same picture.

Two routes, both CPU-only and weightless:

* **Released processor** (transformers-native models): the processor is run on
  a synthetic image and the visual tokens are counted from its outputs. Visual
  tokens in the language sequence are the input ids that belong to the image:
  the expanded placeholders plus layout tokens (row breaks, begin/end markers).
* **Released preprocessing code, re-implemented** (Molmo-7B-D and DeepSeek-VL2,
  whose processors ship as remote code): the tiling rules are transcribed from
  the released files (``image_preprocessing_molmo.py``; the DeepSeek-VL2
  processor and its ``candidate_resolutions``) and documented inline.

All counts are *intrinsic*: padding tiles or padded patches that a reference
implementation may also push through the network are not counted.

Author: Sunita Sahu.
"""

from dataclasses import dataclass, field, asdict
from functools import lru_cache
import math
from typing import Dict, List, Tuple

TEXT_PROMPT = "Describe this image in detail."

# Ungated mirrors (identity verified in notebook 24) and transformers-native ports
# of remote-code checkpoints (same weights, converted).
PROCESSOR_REPOSITORY = {
    "LLaVA-1.5-7B": "llava-hf/llava-1.5-7b-hf",
    "LLaVA-NeXT-7B": "llava-hf/llava-v1.6-mistral-7b-hf",
    "Llama-3.2-11B-Vision": "unsloth/Llama-3.2-11B-Vision-Instruct",
    "Idefics2-8B": "HuggingFaceM4/idefics2-8b",
    "Qwen2-VL-7B": "Qwen/Qwen2-VL-7B-Instruct",
    "Qwen2.5-VL-7B": "Qwen/Qwen2.5-VL-7B-Instruct",
    "Qwen3-VL-8B": "Qwen/Qwen3-VL-8B-Instruct",
    "Gemma-4-12B": "google/gemma-4-12B-it",               # processor needs transformers >= 5.10
    "Gemma-4-26B-A4B": "google/gemma-4-26B-A4B-it",       # processor needs transformers >= 5.5
    "InternVL3-8B": "OpenGVLab/InternVL3-8B-hf",
    "Pixtral-12B": "mistral-community/pixtral-12b",
    "Chameleon-7B": "FriendliAI/chameleon-7b",
    "Janus-Pro-7B": "deepseek-community/Janus-Pro-7B",
    "ViLT-B/32": "dandelin/vilt-b32-finetuned-vqa",
}

# Image placeholder string used in the prompt for processors that expand a placeholder.
PLACEHOLDER = {
    "LLaVA-1.5-7B": "<image>",
    "LLaVA-NeXT-7B": "<image>",
    "Llama-3.2-11B-Vision": "<|image|>",
    "Idefics2-8B": "<image>",
    "Qwen2-VL-7B": "<|vision_start|><|image_pad|><|vision_end|>",
    "Qwen2.5-VL-7B": "<|vision_start|><|image_pad|><|vision_end|>",
    "Qwen3-VL-8B": "<|vision_start|><|image_pad|><|vision_end|>",
    "Gemma-4-12B": "<|image|>",
    "Gemma-4-26B-A4B": "<|image|>",
    "InternVL3-8B": "<IMG_CONTEXT>",
    "Pixtral-12B": "[IMG]",
    "Chameleon-7B": "<image>",
    "Janus-Pro-7B": "<image_placeholder>",
}


@dataclass
class TokenAccount:
    """Token counts seen by each stage of one model for one input image.

    Attributes:
        model: roster name.
        image_height, image_width: the input image fed to the released preprocessing.
        encoder_sequences: tokens in each independent vision-encoder pass
            (one entry per crop / tile / sub-image), including any CLS token.
        patch_positions: positions produced by the patch-embedding convolution, summed.
        fusion_input_tokens: tokens entering the fusion module.
        fusion_output_tokens: tokens leaving the fusion module (the fusion-boundary bandwidth).
        language_visual_tokens: tokens the image adds to the language-model sequence
            (placeholders plus layout tokens); 0 for cross-attention designs.
        cross_attended_tokens: visual tokens read by cross-attention layers; 0 otherwise.
        details: model-specific counts (tiles, windows, pooled tokens, ...).
    """

    model: str
    image_height: int
    image_width: int
    encoder_sequences: List[int] = field(default_factory=list)
    patch_positions: int = 0
    fusion_input_tokens: int = 0
    fusion_output_tokens: int = 0
    language_visual_tokens: int = 0
    cross_attended_tokens: int = 0
    details: Dict[str, object] = field(default_factory=dict)

    @property
    def encoder_tokens(self) -> int:
        """Total tokens processed by the vision encoder (all passes)."""
        return sum(self.encoder_sequences)

    def to_row(self) -> Dict[str, object]:
        """Flat dict for a results table."""
        row = asdict(self)
        row["encoder_passes"] = len(self.encoder_sequences)
        row["encoder_tokens"] = self.encoder_tokens
        row["encoder_sequences"] = ",".join(str(count) for count in self.encoder_sequences)
        row["details"] = "; ".join(f"{key}={value}" for key, value in self.details.items())
        return row


def synthetic_image(height: int, width: int):
    """Uniform grey RGB PIL image (content does not affect token counts)."""
    import numpy
    from PIL import Image

    return Image.fromarray(numpy.full((height, width, 3), 127, dtype=numpy.uint8))


@lru_cache(maxsize=None)
def load_processor(model_name: str):
    """Load (and cache) the released processor of one transformers-native model."""
    from transformers import AutoProcessor
    from transformers.utils import logging

    logging.set_verbosity_error()
    return AutoProcessor.from_pretrained(PROCESSOR_REPOSITORY[model_name])


# Token strings that an image adds to the language sequence (placeholders and layout tokens).
IMAGE_TOKEN_STRINGS = {
    "LLaVA-1.5-7B": ["<image>"],
    "LLaVA-NeXT-7B": ["<image>"],
    "Llama-3.2-11B-Vision": ["<|image|>"],
    "Idefics2-8B": ["<image>", "<fake_token_around_image>"],
    "Qwen2-VL-7B": ["<|image_pad|>", "<|vision_start|>", "<|vision_end|>"],
    "Qwen2.5-VL-7B": ["<|image_pad|>", "<|vision_start|>", "<|vision_end|>"],
    "Qwen3-VL-8B": ["<|image_pad|>", "<|vision_start|>", "<|vision_end|>"],
    "Gemma-4-12B": ["<|image|>", "<|image>", "<image|>"],
    "Gemma-4-26B-A4B": ["<|image|>", "<|image>", "<image|>"],
    "InternVL3-8B": ["<IMG_CONTEXT>", "<img>", "</img>"],
    "Pixtral-12B": ["[IMG]", "[IMG_BREAK]", "[IMG_END]"],
    "Chameleon-7B": ["<image>", "<racm3:break>", "<eoss>"],
    "Janus-Pro-7B": ["<image_placeholder>", "<begin_of_image>", "<end_of_image>"],
}


def count_image_tokens(model_name: str, input_ids) -> int:
    """Number of ids in one sequence that belong to the image (placeholders plus layout tokens)."""
    tokenizer = load_processor(model_name).tokenizer
    image_ids = set()
    for token_string in IMAGE_TOKEN_STRINGS[model_name]:
        token_id = tokenizer.convert_tokens_to_ids(token_string)
        if token_id is not None and token_id != tokenizer.unk_token_id:
            image_ids.add(token_id)
    return sum(1 for token_id in input_ids.tolist() if token_id in image_ids)


def run_processor(model_name: str, height: int, width: int) -> Tuple[object, int]:
    """Run the released processor on one image; return (batch, image tokens in the language sequence)."""
    processor = load_processor(model_name)
    image = synthetic_image(height, width)
    placeholder = PLACEHOLDER[model_name]
    batch = processor(text=f"{placeholder} {TEXT_PROMPT}", images=image, return_tensors="pt")
    return batch, count_image_tokens(model_name, batch["input_ids"][0])


# ---------------------------------------------------------------------------
# Re-implemented released preprocessing (remote-code models)
# ---------------------------------------------------------------------------

def molmo_select_tiling(height: float, width: float, crop_window_size: int, max_crops: int) -> Tuple[int, int]:
    """Molmo ``select_tiling`` (image_preprocessing_molmo.py): rows x columns of crops."""
    tilings = [(rows, columns) for rows in range(1, max_crops + 1) for columns in range(1, max_crops + 1)
               if rows * columns <= max_crops]
    tilings.sort(key=lambda tiling: (tiling[0] * tiling[1], tiling[0]))
    def ratio(numerator: float, denominator: float) -> float:
        """numpy-style division: a non-positive size gives an infinite scale (as in the released code)."""
        return numerator / denominator if denominator > 0 else float("inf")

    scales = [min(ratio(rows * crop_window_size, height), ratio(columns * crop_window_size, width)) for rows, columns in tilings]
    if all(scale < 1 for scale in scales):
        best_index = max(range(len(scales)), key=lambda index: (scales[index], -index))
    else:
        upscale = [scale if scale >= 1.0 else 10e9 for scale in scales]
        best_index = min(range(len(upscale)), key=lambda index: (upscale[index], index))
    return tilings[best_index]


def account_molmo(height: int, width: int) -> TokenAccount:
    """Molmo-7B-D multi-crop: a 336-px global view plus up to 12 overlapping 336-px crops.

    Released config: base 336, patch 14, max_crops 12, overlap margins (4, 4),
    2 x 2 attention pooling to 12 x 12 tokens per crop.
    """
    patch_size, base_size, max_crops, margin = 14, 336, 12, 4
    crop_patches = base_size // patch_size                         # 24
    crop_window_patches = crop_patches - 2 * margin                # 16
    crop_window_size = crop_window_patches * patch_size            # 224 px
    total_margin_pixels = patch_size * 2 * margin                  # 112 px
    rows, columns = molmo_select_tiling(height - total_margin_pixels, width - total_margin_pixels,
                                        crop_window_size, max_crops)
    crops = rows * columns
    pooled_side = (crop_patches + 1) // 2                          # 12
    # Language-sequence layout (image_to_patches_and_tokens): global view rows of 12 patch
    # tokens + 1 column token, framed by start/end; then the high-res crops the same way.
    global_tokens = pooled_side * (pooled_side + 1) + 2
    high_res_height = rows * crop_window_patches + 2 * margin
    high_res_width = columns * crop_window_patches + 2 * margin
    crop_tokens = ((high_res_height + 1) // 2) * ((high_res_width + 1) // 2 + 1) + 2
    passes = crops + 1
    return TokenAccount(
        model="Molmo-7B-D", image_height=height, image_width=width,
        encoder_sequences=[crop_patches * crop_patches + 1] * passes,
        patch_positions=crop_patches * crop_patches * passes,
        # The pooling attends over every patch of every pass; the projector runs on every pooled token.
        fusion_input_tokens=crop_patches * crop_patches * passes,
        fusion_output_tokens=pooled_side * pooled_side * passes,
        language_visual_tokens=global_tokens + crop_tokens,
        details={"tiling": f"{rows}x{columns}", "crops_plus_global": passes,
                 "pooled_tokens_executed": pooled_side * pooled_side * passes},
    )


def deepseek_select_best_resolution(height: int, width: int, candidates: List[Tuple[int, int]]) -> Tuple[int, int]:
    """LLaVA-NeXT-style best fit used by the DeepSeek-VL2 processor; candidates are (width, height)."""
    best_fit, best_effective, best_wasted = None, -1, float("inf")
    for candidate_width, candidate_height in candidates:
        scale = min(candidate_width / width, candidate_height / height)
        scaled_width, scaled_height = int(width * scale), int(height * scale)
        effective = min(scaled_width * scaled_height, width * height)
        wasted = candidate_width * candidate_height - effective
        if effective > best_effective or (effective == best_effective and wasted < best_wasted):
            best_fit, best_effective, best_wasted = (candidate_width, candidate_height), effective, wasted
    return best_fit


DEEPSEEK_VL2_CANDIDATES = [(384, 384), (384, 768), (768, 384), (384, 1152), (1152, 384), (384, 1536), (1536, 384),
                           (768, 768), (384, 1920), (1920, 384), (384, 2304), (2304, 384), (768, 1152), (1152, 768),
                           (384, 2688), (2688, 384), (384, 3072), (3072, 384), (768, 1536), (1536, 768),
                           (384, 3456), (3456, 384), (1152, 1152)]


def account_deepseek_vl2(height: int, width: int) -> TokenAccount:
    """DeepSeek-VL2-Small dynamic tiling: one 384-px global thumbnail plus m x n local 384-px tiles.

    Each tile gives 27 x 27 SigLIP patches; a 2 x 2 pixel shuffle compresses them to
    14 x 14 = 196 tokens. Layout: global 14 x (14 + 1 newline) = 210, one view
    separator, then local (14·m) x (14·n + 1) — from the released processor
    (``candidate_resolutions`` in processor_config.json, ``tile_tag`` = 2D, global view first).
    """
    tile_size, patch_size, downsample = 384, 14, 2
    best_width, best_height = deepseek_select_best_resolution(height, width, DEEPSEEK_VL2_CANDIDATES)
    width_tiles, height_tiles = best_width // tile_size, best_height // tile_size
    side = math.ceil((tile_size // patch_size) / downsample)       # 14
    patches_per_tile = (tile_size // patch_size) ** 2              # 729
    passes = 1 + width_tiles * height_tiles
    layout_tokens = side * (side + 1) + 1 + (height_tiles * side) * (width_tiles * side + 1)
    return TokenAccount(
        model="DeepSeek-VL2-Small", image_height=height, image_width=width,
        encoder_sequences=[patches_per_tile] * passes,
        patch_positions=patches_per_tile * passes,
        fusion_input_tokens=side * side * passes,                   # projector runs after the pixel shuffle
        fusion_output_tokens=side * side * passes,
        language_visual_tokens=layout_tokens,
        details={"local_tiles": f"{height_tiles}x{width_tiles}", "tiles_plus_global": passes},
    )


# ---------------------------------------------------------------------------
# Per-model accounting
# ---------------------------------------------------------------------------

def _fixed(model, height, width, **counts) -> TokenAccount:
    """Account for a fixed-resolution model (input is resized to one size)."""
    return TokenAccount(model=model, image_height=height, image_width=width, **counts)


def account_visual_tokens(model_name: str, height: int, width: int) -> TokenAccount:
    """Return the TokenAccount of one roster model for an input image of the given size."""
    if model_name == "CLIP-ViT-L/14":       # 224 px, patch 14, CLS; pooled embedding crosses the boundary
        return _fixed(model_name, height, width, encoder_sequences=[257], patch_positions=256, fusion_output_tokens=1)
    if model_name == "SigLIP-L/16":         # 384 px, patch 16, no CLS; attention-pooling head
        return _fixed(model_name, height, width, encoder_sequences=[576], patch_positions=576, fusion_output_tokens=1)
    if model_name == "SigLIP2-So400m/14":   # 384 px, patch 14
        return _fixed(model_name, height, width, encoder_sequences=[729], patch_positions=729, fusion_output_tokens=1)
    if model_name == "BLIP-large":          # captioning decoder cross-attends to all 577 image tokens
        return _fixed(model_name, height, width, encoder_sequences=[577], patch_positions=576,
                      fusion_output_tokens=577, cross_attended_tokens=577)
    if model_name in ("BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B"):   # 224 px EVA ViT-g; 32 queries
        return _fixed(model_name, height, width, encoder_sequences=[257], patch_positions=256,
                      fusion_input_tokens=257, fusion_output_tokens=32, language_visual_tokens=32)
    if model_name == "IDEFICS-9B":          # 224 px ViT-H/14; perceiver to 64 latents, cross-attended
        return _fixed(model_name, height, width, encoder_sequences=[257], patch_positions=256,
                      fusion_input_tokens=257, fusion_output_tokens=64, cross_attended_tokens=64)
    if model_name == "Molmo-7B-D":
        return account_molmo(height, width)
    if model_name == "DeepSeek-VL2-Small":
        return account_deepseek_vl2(height, width)
    if model_name in ("Gemma-4-12B", "Gemma-4-26B-A4B"):
        return account_gemma4(model_name, height, width)
    if model_name == "ViLT-B/32":
        processor = load_processor(model_name)
        pixel_values = processor.image_processor(images=synthetic_image(height, width), return_tensors="pt")["pixel_values"]
        patches = (pixel_values.shape[-2] // 32) * (pixel_values.shape[-1] // 32)
        return _fixed(model_name, height, width, patch_positions=patches,
                      fusion_output_tokens=patches + 1, language_visual_tokens=patches + 1,
                      details={"resized_to": f"{pixel_values.shape[-2]}x{pixel_values.shape[-1]}"})

    batch, sequence_image_tokens = run_processor(model_name, height, width)
    if model_name == "LLaVA-1.5-7B":
        return _fixed(model_name, height, width, encoder_sequences=[577], patch_positions=576,
                      fusion_input_tokens=576, fusion_output_tokens=576, language_visual_tokens=sequence_image_tokens)
    if model_name == "LLaVA-NeXT-7B":
        crops = int(batch["pixel_values"].shape[1])
        return _fixed(model_name, height, width, encoder_sequences=[577] * crops, patch_positions=576 * crops,
                      fusion_input_tokens=576 * crops, fusion_output_tokens=576 * crops,
                      language_visual_tokens=sequence_image_tokens, details={"crops": crops})
    if model_name == "Llama-3.2-11B-Vision":
        tiles = int(batch["aspect_ratio_mask"].sum())
        tile_tokens = (560 // 14) ** 2 + 1                                     # 1,601
        return _fixed(model_name, height, width, encoder_sequences=[tile_tokens] * tiles,
                      patch_positions=(tile_tokens - 1) * tiles,
                      fusion_input_tokens=tile_tokens * tiles, fusion_output_tokens=tile_tokens * tiles,
                      cross_attended_tokens=tile_tokens * tiles,
                      details={"tiles": tiles, "global_sequence": tile_tokens * tiles})
    if model_name == "Idefics2-8B":
        # Valid (unpadded) patches per sub-image: ceil(h/14) x ceil(w/14) of each sub-image's real region.
        masks = batch["pixel_attention_mask"][0]
        sequences = []
        for mask in masks:
            valid_rows = int(mask.any(dim=1).sum())
            valid_columns = int(mask.any(dim=0).sum())
            sequences.append(math.ceil(valid_rows / 14) * math.ceil(valid_columns / 14))
        sub_images = len(sequences)
        return _fixed(model_name, height, width, encoder_sequences=sequences, patch_positions=sum(sequences),
                      fusion_input_tokens=sum(sequences), fusion_output_tokens=64 * sub_images,
                      language_visual_tokens=sequence_image_tokens,
                      details={"sub_images": sub_images, "perceiver_latents_per_image": 64})
    if model_name in ("Qwen2-VL-7B", "Qwen2.5-VL-7B", "Qwen3-VL-8B"):
        frames, grid_height, grid_width = (int(value) for value in batch["image_grid_thw"][0])
        patches = frames * grid_height * grid_width
        details = {"grid": f"{grid_height}x{grid_width}"}
        if model_name == "Qwen2.5-VL-7B":
            details["window_sequences"] = qwen25_window_sequences(grid_height, grid_width)
        return _fixed(model_name, height, width, encoder_sequences=[patches], patch_positions=patches,
                      fusion_input_tokens=patches, fusion_output_tokens=patches // 4,
                      language_visual_tokens=sequence_image_tokens, details=details)
    if model_name == "InternVL3-8B":
        tiles = int(batch["pixel_values"].shape[0])
        return _fixed(model_name, height, width, encoder_sequences=[1025] * tiles, patch_positions=1024 * tiles,
                      fusion_input_tokens=256 * tiles, fusion_output_tokens=256 * tiles,
                      language_visual_tokens=sequence_image_tokens, details={"tiles": tiles})
    if model_name == "Pixtral-12B":
        resized_height, resized_width = (int(value) for value in batch["image_sizes"][0])
        patches = (resized_height // 16) * (resized_width // 16)
        return _fixed(model_name, height, width, encoder_sequences=[patches], patch_positions=patches,
                      fusion_input_tokens=patches, fusion_output_tokens=patches,
                      language_visual_tokens=sequence_image_tokens, details={"resized_to": f"{resized_height}x{resized_width}"})
    if model_name == "Chameleon-7B":        # VQ tokenizer at 512 px -> 32 x 32 codes
        return _fixed(model_name, height, width, patch_positions=0, fusion_output_tokens=1024,
                      language_visual_tokens=sequence_image_tokens, details={"vq_input": "512x512"})
    if model_name == "Janus-Pro-7B":        # SigLIP-L/16 at 384 px, no CLS
        return _fixed(model_name, height, width, encoder_sequences=[576], patch_positions=576,
                      fusion_input_tokens=576, fusion_output_tokens=576, language_visual_tokens=sequence_image_tokens)
    raise KeyError(model_name)


def qwen25_window_sequences(grid_height: int, grid_width: int, window_units: int = 4, merge: int = 2) -> List[int]:
    """Patch counts of the windows used by Qwen2.5-VL's windowed ViT layers.

    Windows are ``window_units`` x ``window_units`` merge units (window_size 112 px /
    patch 14 / merge 2 = 4), i.e. at most 8 x 8 = 64 patches; edge windows are smaller.
    """
    unit_rows, unit_columns = grid_height // merge, grid_width // merge
    sequences = []
    for row_start in range(0, unit_rows, window_units):
        for column_start in range(0, unit_columns, window_units):
            rows = min(window_units, unit_rows - row_start)
            columns = min(window_units, unit_columns - column_start)
            sequences.append(rows * columns * merge * merge)
    return sequences


# ---------------------------------------------------------------------------
# Gemma 4 (roster extension, decision D9)
# ---------------------------------------------------------------------------

# Released image-processor settings of both Gemma 4 checkpoints: 16-px patches, 3 x 3 pooling, a budget of
# 280 soft tokens (selectable 70 / 140 / 280 / 560 / 1,120; the released default is 280).
GEMMA4_PATCH_SIZE, GEMMA4_POOLING, GEMMA4_SOFT_TOKEN_BUDGET = 16, 3, 280
GEMMA4_LAYOUT_TOKENS = 2                      # begin-of-image and end-of-image markers around the soft tokens


def gemma4_resized_size(height: int, width: int, max_soft_tokens: int = GEMMA4_SOFT_TOKEN_BUDGET) -> Tuple[int, int]:
    """Gemma 4 aspect-ratio-preserving resize: the largest size whose patches fit the budget.

    Transcribed from ``get_aspect_ratio_preserving_size`` (transformers 5.18,
    ``image_processing_gemma4.py``; identical in ``gemma4_unified``). Every image is scaled
    up or down to the budget, so the token count does not depend on the input size, only
    on its aspect ratio. Checked against both released processors in the 5.x environment.
    """
    max_patches = max_soft_tokens * GEMMA4_POOLING ** 2
    factor = math.sqrt(max_patches * GEMMA4_PATCH_SIZE ** 2 / (height * width))
    side_multiple = GEMMA4_POOLING * GEMMA4_PATCH_SIZE
    target_height = int(math.floor(factor * height / side_multiple)) * side_multiple
    target_width = int(math.floor(factor * width / side_multiple)) * side_multiple
    max_side_length = (max_patches // GEMMA4_POOLING ** 2) * side_multiple
    if target_height == 0 and target_width == 0:
        raise ValueError(f"Gemma 4 resizes a {height} x {width} image to 0 x 0")
    if target_height == 0:
        target_height = side_multiple
        target_width = min(int(math.floor(width / height)) * side_multiple, max_side_length)
    elif target_width == 0:
        target_width = side_multiple
        target_height = min(int(math.floor(height / width)) * side_multiple, max_side_length)
    return target_height, target_width


def account_gemma4(model_name: str, height: int, width: int, executed: bool = False,
                   max_soft_tokens: int = GEMMA4_SOFT_TOKEN_BUDGET) -> TokenAccount:
    """Gemma 4 token account; ``executed=True`` gives what the reference implementation runs.

    * Gemma-4-26B-A4B: a 27-layer vision encoder on 16-px patches, 3 x 3 average pooling to
      soft tokens, one projection into the language model. The processor pads the patches to
      the budget (280 x 9 = 2,520 slots) and the encoder runs on every slot (padding is only
      masked), then pools with a dense one-hot matrix product over all slots and drops the
      padding before the projection.
    * Gemma-4-12B (encoder-free): each 48-px patch (3 x 3 of 16 px, 6,912 values) is projected
      straight to the language width; the embedder and the projection run on the padded 280
      slots and the padding is dropped before the language model.
    """
    resized_height, resized_width = gemma4_resized_size(height, width, max_soft_tokens)
    patches = (resized_height // GEMMA4_PATCH_SIZE) * (resized_width // GEMMA4_PATCH_SIZE)
    soft_tokens = patches // GEMMA4_POOLING ** 2
    padded_patch_slots = max_soft_tokens * GEMMA4_POOLING ** 2
    details: Dict[str, object] = {"resized_to": f"{resized_height}x{resized_width}", "soft_token_budget": max_soft_tokens}
    if model_name == "Gemma-4-26B-A4B":
        encoder_tokens = padded_patch_slots if executed else patches
        if executed:
            details["dense_pooling_product"] = (max_soft_tokens, padded_patch_slots, 1152)
        return TokenAccount(model=model_name, image_height=height, image_width=width,
                            encoder_sequences=[encoder_tokens], patch_positions=encoder_tokens,
                            fusion_input_tokens=soft_tokens, fusion_output_tokens=soft_tokens,
                            language_visual_tokens=soft_tokens + GEMMA4_LAYOUT_TOKENS, details=details)
    if model_name == "Gemma-4-12B":
        embedded_patches = max_soft_tokens if executed else soft_tokens
        return TokenAccount(model=model_name, image_height=height, image_width=width,
                            encoder_sequences=[], patch_positions=embedded_patches,
                            fusion_input_tokens=embedded_patches, fusion_output_tokens=soft_tokens,
                            language_visual_tokens=soft_tokens + GEMMA4_LAYOUT_TOKENS, details=details)
    raise KeyError(model_name)
