"""Verbose, per-iteration logging to .txt files.

Logging contract used by every notebook:

    with ExperimentLogger(log_dir, run_name) as log:
        log.section("Loading model")
        log.info("Downloading checkpoint...")
        log.iteration("Memory pass 1/3 for vision_model", batch=1, precision="fp16")
        log.metric("peak_mb", 1843.22, unit="MB")

Output file: ``<log_dir>/<YYYYMMDD_HHMMSS>_<run_name>.txt``

Behavioural guarantees:
    * Line-buffered — partial runs are inspectable while the notebook is running.
    * ISO-8601 timestamps on every entry.
    * Errors capture the full traceback automatically when the logger is used
      as a context manager.
    * Final summary line includes total iteration count.
"""

import os
import sys
import traceback
from datetime import datetime
from pathlib import Path


class ExperimentLogger:
    def __init__(self, log_dir, run_name):
        """Open a verbose .txt log file for one experiment run.

        Parameters
        ----------
        log_dir : str or Path
            Where the log file will live. Will be created if absent.
        run_name : str
            Free-form label, used both in the filename and header.
            Convention: ``"<notebook>__<model_id_sanitized>__<metric>"``.
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        # Sanitize run_name for filesystem
        safe_name = "".join(c if c.isalnum() or c in "_-." else "_" for c in run_name)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.log_path = self.log_dir / f"{timestamp}_{safe_name}.txt"
        # Line-buffered so partial runs are inspectable while running
        self.fp = open(self.log_path, "w", encoding="utf-8", buffering=1)
        self.iteration_count = 0
        self.run_name = run_name
        self._write_header()

    def _ts(self):
        return datetime.now().isoformat(timespec="milliseconds")

    def _write_header(self):
        self.fp.write("=" * 80 + "\n")
        self.fp.write(f"EXPERIMENT LOG: {self.run_name}\n")
        self.fp.write(f"Started: {self._ts()}\n")
        self.fp.write(f"Python: {sys.version.split()[0]}\n")
        try:
            import torch
            self.fp.write(f"PyTorch: {torch.__version__}\n")
            self.fp.write(f"CUDA available: {torch.cuda.is_available()}\n")
            if torch.cuda.is_available():
                self.fp.write(f"CUDA device: {torch.cuda.get_device_name(0)}\n")
                self.fp.write(
                    f"CUDA memory: "
                    f"{torch.cuda.get_device_properties(0).total_memory / 1e9:.1f}GB\n"
                )
        except Exception as e:
            self.fp.write(f"PyTorch import failed: {e}\n")
        try:
            import transformers
            self.fp.write(f"transformers: {transformers.__version__}\n")
        except Exception:
            pass
        self.fp.write("=" * 80 + "\n\n")

    def section(self, title):
        """Write a visual divider for a new section of the run."""
        self.fp.write("\n" + "-" * 80 + "\n")
        self.fp.write(f"{self._ts()}  >>> {title}\n")
        self.fp.write("-" * 80 + "\n")

    def info(self, msg):
        """Free-form informational entry."""
        self.fp.write(f"{self._ts()}  {msg}\n")

    def iteration(self, label, **kwargs):
        """Mark the start of a discrete iteration; increment the counter."""
        self.iteration_count += 1
        self.fp.write(f"\n[ITERATION {self.iteration_count:04d}] {self._ts()}  {label}\n")
        for k, v in kwargs.items():
            self.fp.write(f"    {k}: {v}\n")

    def metric(self, name, value, unit=""):
        """Record a measured metric inside the current iteration."""
        unit_s = f" {unit}" if unit else ""
        self.fp.write(f"    METRIC  {name}: {value}{unit_s}\n")

    def warn(self, msg):
        self.fp.write(f"{self._ts()}  WARN: {msg}\n")

    def error(self, msg, exc=None):
        """Log an error; include traceback if an exception is passed."""
        self.fp.write(f"{self._ts()}  ERROR: {msg}\n")
        if exc is not None:
            tb = traceback.format_exception(type(exc), exc, exc.__traceback__)
            for line in tb:
                for sub in line.rstrip("\n").split("\n"):
                    self.fp.write(f"    {sub}\n")

    def close(self):
        self.fp.write("\n" + "=" * 80 + "\n")
        self.fp.write(f"Ended: {self._ts()}\n")
        self.fp.write(f"Total iterations: {self.iteration_count}\n")
        self.fp.write("=" * 80 + "\n")
        try:
            self.fp.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_val is not None:
            self.error("Logger exiting with exception", exc_val)
        self.close()
        # Do not suppress the exception
        return False


class _TeeStream:
    """Writes everything to the original stream and to a transcript file."""

    def __init__(self, original_stream, transcript_file):
        self.original_stream = original_stream
        self.transcript_file = transcript_file

    def write(self, text):
        """Write to both destinations; the transcript is flushed at once."""
        self.original_stream.write(text)
        try:
            self.transcript_file.write(text)
            self.transcript_file.flush()
        except ValueError:
            pass  # transcript already closed
        return len(text)

    def flush(self):
        """Flush both destinations."""
        self.original_stream.flush()
        try:
            self.transcript_file.flush()
        except ValueError:
            pass

    def __getattr__(self, attribute_name):
        # Everything else (isatty, fileno, encoding, ...) behaves like the original stream.
        return getattr(self.original_stream, attribute_name)


class SessionTranscript:
    """Copy everything a notebook prints (stdout and stderr) into a .txt file.

    Complements ``ExperimentLogger``: the per-model logs hold the structured
    record, the transcript holds every printed line and library warning of the
    whole session, so nothing is lost if the browser tab or runtime disconnects.
    A second file receives Python-level tracebacks of hard crashes (segfaults,
    aborts) through ``faulthandler``.

        transcript = SessionTranscript(log_dir, "29_gpu_latency")
        ...
        transcript.close()
    """

    def __init__(self, log_dir, run_name):
        """Start the transcript and the crash-trace file."""
        import faulthandler

        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_name = sanitize_for_filename(run_name)
        self.transcript_path = self.log_dir / f"{timestamp}_{safe_name}__session_transcript.txt"
        self.crash_trace_path = self.log_dir / f"{timestamp}_{safe_name}__crash_traces.txt"
        self.transcript_file = open(self.transcript_path, "w", encoding="utf-8", buffering=1)
        self.crash_trace_file = open(self.crash_trace_path, "w", encoding="utf-8", buffering=1)
        faulthandler.enable(file=self.crash_trace_file, all_threads=True)
        self.original_stdout, self.original_stderr = sys.stdout, sys.stderr
        sys.stdout = _TeeStream(self.original_stdout, self.transcript_file)
        sys.stderr = _TeeStream(self.original_stderr, self.transcript_file)
        print(f"Session transcript: {self.transcript_path}")
        print(f"Crash traces:       {self.crash_trace_path}")

    def close(self):
        """Restore the original streams and close both files."""
        import faulthandler

        sys.stdout, sys.stderr = self.original_stdout, self.original_stderr
        try:
            faulthandler.disable()
        except Exception:
            pass
        for open_file in (self.transcript_file, self.crash_trace_file):
            try:
                open_file.close()
            except Exception:
                pass


def sanitize_for_filename(s):
    """Convert an arbitrary string into a safe filename token.

    Used when building log/measurement filenames from HF model ids
    like ``openai/clip-vit-large-patch14``.
    """
    return "".join(c if c.isalnum() or c in "_-." else "_" for c in s)
