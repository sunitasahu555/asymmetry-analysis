"""Dataclasses used to serialize measurements.

Each model audit produces one ``ModelRecord``. The record contains one
``ComponentRecord`` per (V/F/L/H or extended) component plus zero or more
``FreezingPolicy`` entries describing which components are frozen in
which training stage.

Phase-2 additions (backwards-compatible with Phase-1 JSONs):
* ``ComponentRecord.params_active`` and ``n_experts_*`` — for MoE models.
* ``ComponentRecord.output_tokens_at_native_res`` / ``_at_224`` — for
  dynamic-tile vision encoders whose token count varies with input.
* ``ComponentRecord.flops_source`` / ``flops_estimate`` — provenance flag.
* ``ModelRecord.architecture_pattern`` — coarse pattern tag.
* ``ModelRecord.benchmark_scores`` / ``benchmark_sources`` — populated by
  script 06 from ``benchmarks.csv``.
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class InputConfig:
    """Standardized input configuration used for FLOPs / memory measurements."""
    image_hw: Tuple[int, int] = (224, 224)
    text_tokens: int = 32
    batch_size: int = 1
    precision: str = "fp16"  # "fp16" or "fp32"

    def to_dict(self):
        return {
            "image_hw": list(self.image_hw),
            "text_tokens": self.text_tokens,
            "batch_size": self.batch_size,
            "precision": self.precision,
        }


@dataclass
class ComponentRecord:
    """One row in the per-component breakdown."""
    name: str  # "vision" / "fusion" / "language" / "head" or "fused_transformer" / etc.
    module_path: str = ""
    params_total: int = 0
    params_trainable: int = 0
    # Phase-2: MoE bookkeeping. If the layer is dense, params_active == params_total.
    params_active: Optional[int] = None
    n_experts_total: Optional[int] = None
    n_experts_active_per_token: Optional[int] = None
    # FLOPs
    flops_g: Optional[float] = None
    flops_source: str = ""          # "calflops" / "fvcore" / "ptflops" / "manual_estimate" / ""
    flops_estimate: bool = False    # True if manual fallback was used
    # Memory
    peak_mem_mb: Optional[float] = None
    # Token counts (scalar + at specific resolutions for dynamic-tile models)
    output_tokens: Optional[int] = None
    output_tokens_at_native_res: Optional[int] = None
    output_tokens_at_224: Optional[int] = None
    notes: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass
class FreezingPolicy:
    """Which components are frozen during a given training stage."""
    stage: str  # "pretraining", "stage_1", "stage_2", "training_recipe", etc.
    frozen_components: List[str] = field(default_factory=list)
    trainable_components: List[str] = field(default_factory=list)
    notes: str = ""

    def to_dict(self):
        return asdict(self)


@dataclass
class ModelRecord:
    """One audit result for one model.

    Scripts 02–05 populate this incrementally; script 06 aggregates.
    """
    model_id: str
    name: str = ""
    family: str = ""
    release_year: int = 0
    architecture_pattern: str = ""  # NEW (Phase 2)
    input_config: InputConfig = field(default_factory=InputConfig)
    components: Dict[str, ComponentRecord] = field(default_factory=dict)
    freezing_policies: List[FreezingPolicy] = field(default_factory=list)
    measurement_timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    hardware: str = ""
    notes: str = ""
    # Phase-2: populated by script 06 from benchmarks.csv
    benchmark_scores: Dict[str, Optional[float]] = field(default_factory=dict)
    benchmark_sources: Dict[str, str] = field(default_factory=dict)
    # Revision fix A13: whole-model parameter total and attribution residual
    # (see metrics.partition_component_params). Empty for pre-A13 records.
    parameter_audit: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return {
            "model_id": self.model_id,
            "name": self.name,
            "family": self.family,
            "release_year": self.release_year,
            "architecture_pattern": self.architecture_pattern,
            "input_config": self.input_config.to_dict(),
            "components": {k: v.to_dict() for k, v in self.components.items()},
            "freezing_policies": [fp.to_dict() for fp in self.freezing_policies],
            "measurement_timestamp": self.measurement_timestamp,
            "hardware": self.hardware,
            "notes": self.notes,
            "benchmark_scores": self.benchmark_scores,
            "benchmark_sources": self.benchmark_sources,
            "parameter_audit": self.parameter_audit,
        }

    @classmethod
    def from_dict(cls, d):
        """Reconstruct a ModelRecord from a dict.

        Backwards-compatible with Phase-1 JSONs that lack the new Phase-2
        fields — unknown keys are dropped and missing keys take defaults.
        """
        ic = d.get("input_config", {})
        rec = cls(
            model_id=d["model_id"],
            name=d.get("name", ""),
            family=d.get("family", ""),
            release_year=d.get("release_year", 0),
            architecture_pattern=d.get("architecture_pattern", ""),
            input_config=InputConfig(
                image_hw=tuple(ic.get("image_hw", [224, 224])),
                text_tokens=ic.get("text_tokens", 32),
                batch_size=ic.get("batch_size", 1),
                precision=ic.get("precision", "fp16"),
            ),
            measurement_timestamp=d.get("measurement_timestamp", ""),
            hardware=d.get("hardware", ""),
            notes=d.get("notes", ""),
            benchmark_scores=d.get("benchmark_scores", {}) or {},
            benchmark_sources=d.get("benchmark_sources", {}) or {},
            parameter_audit=d.get("parameter_audit", {}) or {},
        )
        valid_comp_keys = {f.name for f in ComponentRecord.__dataclass_fields__.values()}
        for cname, cdat in d.get("components", {}).items():
            cdat_clean = {k: v for k, v in (cdat or {}).items() if k in valid_comp_keys}
            cdat_clean.setdefault("name", cname)
            rec.components[cname] = ComponentRecord(**cdat_clean)
        valid_fp_keys = {f.name for f in FreezingPolicy.__dataclass_fields__.values()}
        for fp in d.get("freezing_policies", []):
            fp_clean = {k: v for k, v in (fp or {}).items() if k in valid_fp_keys}
            rec.freezing_policies.append(FreezingPolicy(**fp_clean))
        return rec
