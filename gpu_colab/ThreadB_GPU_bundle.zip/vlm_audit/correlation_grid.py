"""Spearman correlation grid with exact permutation tests (manuscript Section 5.7, Table 8).

Reconstructed during revision item A13 (the original script was not in the
code tree). Notebook 25 shows that, on the manuscript's own inputs, this
module reproduces every published marginal rho, every year-partial rho, and
every exact (n <= 8) permutation p-value of Table 8.

* Marginal: Spearman rho; two-sided permutation p over **all** orderings of
  the structural variable (exact enumeration is feasible up to n = 10).
* Year-partial: Spearman partial correlation (Pearson correlation of rank
  residuals after regressing on the rank of release year), with an exact
  two-sided permutation p obtained by permuting the structural variable.
* Benjamini-Hochberg adjustment within each 28-test family.

Also holds the pairwise order comparison shared by notebooks 31 (latency at two
input sizes) and 32 (compute over a sweep of input sizes).

Author: Sunita Sahu.
"""

import itertools
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from scipy import stats

EXACT_ENUMERATION_LIMIT = 10
MONTE_CARLO_DRAWS = 20000


def _unit_rows(matrix: np.ndarray) -> np.ndarray:
    """Centre each row and scale it to unit length, so dot products are Pearson correlations."""
    centred = matrix - matrix.mean(axis=-1, keepdims=True)
    return centred / np.linalg.norm(centred, axis=-1, keepdims=True)


def _orderings(sample_size: int, seed: int):
    """All orderings when feasible, otherwise ``MONTE_CARLO_DRAWS`` random ones."""
    if sample_size <= EXACT_ENUMERATION_LIMIT:
        return itertools.permutations(range(sample_size)), True
    generator = np.random.default_rng(seed)
    return (generator.permutation(sample_size) for _ in range(MONTE_CARLO_DRAWS)), False


def spearman_with_partial(
    structural_values, scores, release_years, seed: int = 0, chunk_size: int = 400000
) -> Dict[str, float]:
    """Marginal and year-partial Spearman correlations with permutation p-values.

    Returns ``rho``, ``p_value``, ``partial_rho``, ``partial_p_value``,
    ``sample_size`` and ``exact`` (True when every ordering was enumerated).
    """
    rank_structural, rank_score, rank_year = (
        stats.rankdata(np.asarray(values, dtype=float)) for values in (structural_values, scores, release_years)
    )
    unit_score = _unit_rows(rank_score)
    unit_year = _unit_rows(rank_year)
    score_year_correlation = float(unit_score @ unit_year)

    def marginal_and_partial(rank_matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Vectorised marginal and partial correlation for each row of ranks."""
        unit_structural = _unit_rows(rank_matrix)
        structural_score = unit_structural @ unit_score
        structural_year = unit_structural @ unit_year
        denominator = np.sqrt(np.clip((1 - structural_year ** 2) * (1 - score_year_correlation ** 2), 1e-15, None))
        return structural_score, (structural_score - structural_year * score_year_correlation) / denominator

    observed_marginal, observed_partial = (float(value[0]) for value in marginal_and_partial(rank_structural[None, :]))
    orderings, is_exact = _orderings(len(rank_structural), seed)
    marginal_hits = partial_hits = total = 0
    while True:
        chunk = list(itertools.islice(orderings, chunk_size))
        if not chunk:
            break
        marginal, partial = marginal_and_partial(rank_structural[np.array(chunk)])
        marginal_hits += int((np.abs(marginal) >= abs(observed_marginal) - 1e-9).sum())
        partial_hits += int((np.abs(partial) >= abs(observed_partial) - 1e-9).sum())
        total += len(chunk)
    return {
        "rho": observed_marginal,
        "p_value": marginal_hits / total,
        "partial_rho": observed_partial,
        "partial_p_value": partial_hits / total,
        "sample_size": len(rank_structural),
        "exact": is_exact,
    }


def benjamini_hochberg(p_values) -> np.ndarray:
    """Benjamini-Hochberg adjusted p-values (step-up, monotone, capped at 1)."""
    from scipy.stats import false_discovery_control

    return false_discovery_control(np.asarray(p_values, dtype=float), method="bh")


def spearman_permutation_test(first_values, second_values, seed: int = 0) -> Dict[str, float]:
    """Spearman rho with a two-sided permutation p (exact up to n = 10, Monte Carlo above; (hits+1)/(draws+1))."""
    rank_first = stats.rankdata(np.asarray(first_values, dtype=float))
    unit_second = _unit_rows(stats.rankdata(np.asarray(second_values, dtype=float)))
    observed = float(_unit_rows(rank_first[None, :])[0] @ unit_second)
    orderings, is_exact = _orderings(len(rank_first), seed)
    hits = total = 0
    while True:
        chunk = list(itertools.islice(orderings, 400000))
        if not chunk:
            break
        correlations = _unit_rows(rank_first[np.array(chunk)]) @ unit_second
        hits += int((np.abs(correlations) >= abs(observed) - 1e-9).sum())
        total += len(chunk)
    p_value = hits / total if is_exact else (hits + 1) / (total + 1)
    return {"rho": observed, "p_value": p_value, "sample_size": len(rank_first), "exact": is_exact}


def benjamini_yekutieli(p_values) -> np.ndarray:
    """Benjamini-Yekutieli adjusted p-values: valid under arbitrary dependence (reviewer item A10)."""
    from scipy.stats import false_discovery_control

    return false_discovery_control(np.asarray(p_values, dtype=float), method="by")


def exact_two_group_test(scores, in_first_group) -> Dict[str, float]:
    """Exact two-sided permutation test of a rank-sum difference between two groups (reviewer item A2).

    Enumerates every assignment of ``n1`` group labels to the ``n`` models (all
    C(n, n1) of them) and compares the mean rank of group 1 with that of the
    rest. This is the exact Mann-Whitney test; with n1 = 1 its smallest attainable
    two-sided p-value is 2/n, whatever the data.

    Returns ``n``, ``n1``, ``mean_rank_difference`` (group 1 minus rest),
    ``p_value`` and ``minimum_attainable_p``.
    """
    ranks = stats.rankdata(np.asarray(scores, dtype=float))
    membership = np.asarray(in_first_group, dtype=bool)
    size, first_size = len(ranks), int(membership.sum())
    if first_size in (0, size):
        return {"n": size, "n1": first_size, "mean_rank_difference": float("nan"), "p_value": float("nan"),
                "minimum_attainable_p": float("nan")}

    def difference(selection) -> float:
        """Mean rank of the selected models minus mean rank of the others."""
        chosen = ranks[list(selection)]
        return chosen.mean() - (ranks.sum() - chosen.sum()) / (size - first_size)

    observed = difference(np.flatnonzero(membership))
    all_differences = np.array([difference(selection) for selection in itertools.combinations(range(size), first_size)])
    p_value = float((np.abs(all_differences) >= abs(observed) - 1e-9).mean())
    minimum_p = float((np.abs(all_differences) >= np.abs(all_differences).max() - 1e-9).mean())
    return {"n": size, "n1": first_size, "mean_rank_difference": float(observed), "p_value": p_value,
            "minimum_attainable_p": minimum_p}


def has_variation(values) -> bool:
    """True when a variable takes at least two distinct values (a rank correlation is defined)."""
    return len(set(np.round(np.asarray(values, dtype=float), 12))) > 1


def pairwise_order_changes(first_values: pd.Series, second_values: pd.Series,
                           minimum_gap: float = 0.05) -> pd.DataFrame:
    """Pairs of items whose order differs between two measurements of the same items.

    Used for "which model is cheaper" at two input sizes. A pair counts as changed when
    the sign of its difference differs between the two measurements and both relative
    gaps exceed ``minimum_gap``, so that near-ties (or measurement noise) cannot create
    a change.

    Args:
        first_values, second_values: one value per item (index = item name), named after
            the measurement (the names label the output columns).
        minimum_gap: smallest relative gap |a - b| / max(a, b) that counts as an order.

    Returns:
        One row per changed pair (items in alphabetical order): first, second, then the
        values of both items in the first and in the second measurement.
    """
    first_label, second_label = first_values.name, second_values.name
    columns = ["first", "second", f"first_{first_label}", f"second_{first_label}",
               f"first_{second_label}", f"second_{second_label}"]
    names = sorted(set(first_values.index) & set(second_values.index))
    changed = []
    for first_index, first in enumerate(names):
        for second in names[first_index + 1:]:
            first_gap = first_values[first] - first_values[second]
            second_gap = second_values[first] - second_values[second]
            first_relative = abs(first_gap) / max(first_values[first], first_values[second])
            second_relative = abs(second_gap) / max(second_values[first], second_values[second])
            if np.sign(first_gap) != np.sign(second_gap) and min(first_relative, second_relative) > minimum_gap:
                changed.append(dict(zip(columns, (first, second, first_values[first], first_values[second],
                                                  second_values[first], second_values[second]))))
    return pd.DataFrame(changed, columns=columns)
