"""Per-component dummy input builders.

Phase-2 fixes:
* ``interpolate_pos_encoding=True`` is now passed for all CLIP/SigLIP-derived
  vision encoders so a 224x224 dummy input doesn't blow up when the model
  was pretrained at 336/384/448 (EXPERIMENT_LOG.md issue F-1).
* For dynamic-tile encoders (Qwen2-VL etc.) the dummy input uses the model's
  native resolution to avoid the same mismatch.

Phase-2 new families:
* ``dynamic_tile_adapter_llm`` — Qwen2-VL, Qwen2.5-VL, InternVL3
* ``adapter_llm_own_encoder`` — Pixtral
* ``moe_adapter_llm`` — DeepSeek-VL2
* ``native_early_fusion`` — Chameleon (no V/F/L decomposition)
* ``native_decoupled_encoder`` — Janus-Pro (two vision encoders)
"""

from typing import Any, Dict, Optional

from .schema import InputConfig


def _native_or_ic_hw(family: str, ic: InputConfig, model_spec=None):
    """Return (H, W) to use for the vision dummy input.

    For dynamic-tile / native models we use the model's native resolution
    because their position embeddings depend on it; for fixed-resolution
    families we respect ``ic.image_hw``.
    """
    fixed_native_families = {
        "dynamic_tile_adapter_llm",
        "adapter_llm_own_encoder",
        "native_early_fusion",
        "native_decoupled_encoder",
    }
    if family in fixed_native_families and model_spec is not None:
        return model_spec.native_image_hw
    return ic.image_hw


def build_dummy_inputs(
    family: str,
    ic: Optional[InputConfig] = None,
    device: str = "cpu",
    model_spec=None,
) -> Dict[str, Optional[Dict[str, Any]]]:
    """Per-component kwargs for each component's ``forward()``.

    ``model_spec`` is optional; supplying it allows dynamic-tile / native
    families to use the right native resolution instead of the standardized
    ``ic.image_hw``.
    """
    import torch
    ic = ic or InputConfig()
    H, W = _native_or_ic_hw(family, ic, model_spec=model_spec)
    T = ic.text_tokens
    B = ic.batch_size

    pixel_values = torch.randn(B, 3, H, W, device=device)
    input_ids = torch.randint(low=1, high=1000, size=(B, T), device=device)
    attention_mask = torch.ones(B, T, dtype=torch.long, device=device)

    # ----- Phase 1 families -----

    if family == "dual_encoder_contrastive":
        # F-1 fix: vision models pretrained at 384 (SigLIP) / 224 (CLIP) need
        # interpolate_pos_encoding=True if we feed any other resolution.
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   None,
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "bridge_module_precursor":  # BLIP-1
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   {"input_ids": input_ids, "attention_mask": attention_mask},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family in ("bridge_module", "bridge_module_adapter_llm"):
        query_embeds = torch.randn(B, 32, 768, device=device)
        vision_hidden = torch.randn(B, 257, 1408, device=device)
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   {
                "_qformer_query": query_embeds,
                "_qformer_vision_hidden": vision_hidden,
                "_qformer_attention_mask": torch.ones(B, vision_hidden.size(1), dtype=torch.long, device=device),
            },
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "adapter_llm":  # LLaVA-1.5 / LLaVA-NeXT / Molmo
        # F-1 fix: vision tower is CLIP-336 (LLaVA) — use native res and
        # interpolate_pos_encoding to be safe.
        vision_hw = model_spec.native_image_hw if model_spec else (336, 336)
        vision_pv = torch.randn(B, 3, vision_hw[0], vision_hw[1], device=device)
        vision_hidden = torch.randn(B, 576, 1024, device=device)
        return {
            "vision":   {"pixel_values": vision_pv, "interpolate_pos_encoding": True},
            "fusion":   {"_mlp_input": vision_hidden},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "cross_attention_llm":  # IDEFICS / Llama-3.2-Vision
        vision_hidden = torch.randn(B, 257, 1024, device=device)
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   {"_perceiver_input": vision_hidden},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "perceiver_adapter_llm":  # Idefics2
        vision_hidden = torch.randn(B, 257, 1152, device=device)
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   {"_connector_input": vision_hidden},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "single_stream_fused":  # ViLT
        num_image_tokens = (max(H, W) // 32) ** 2
        combined_seq_len = num_image_tokens + T
        hidden_states = torch.randn(B, combined_seq_len, 768, device=device)
        return {
            "vision":   {"input_ids": input_ids, "pixel_values": pixel_values},
            "fusion":   None,
            "language": {"hidden_states": hidden_states},
            "head":     None,
        }

    # ----- Phase 2 families -----

    if family == "dynamic_tile_adapter_llm":  # Qwen2-VL / Qwen2.5-VL / InternVL3
        # Vision input at native resolution; pos-embedding interpolation on.
        vision_hidden = torch.randn(B, 256, 1024, device=device)
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   {"_merger_input": vision_hidden},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "adapter_llm_own_encoder":  # Pixtral
        # Pixtral takes its own image tensor format; native-aspect ratio.
        vision_hidden = torch.randn(B, 1024, 1024, device=device)
        return {
            "vision":   {"pixel_values": pixel_values},  # Pixtral encoder may not accept interpolate kw
            "fusion":   {"_projector_input": vision_hidden},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "moe_adapter_llm":  # DeepSeek-VL2
        vision_hidden = torch.randn(B, 576, 1152, device=device)
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   {"_aligner_input": vision_hidden},
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
        }

    if family == "native_early_fusion":  # Chameleon — no V/F/L decomposition
        # The whole transformer operates on input_ids alone (image-as-tokens).
        return {
            "vision":   None,
            "fusion":   None,
            "language": None,
            "head":     None,
            "fused_transformer": {"input_ids": input_ids, "attention_mask": attention_mask},
            "embeddings": None,
        }

    if family == "native_decoupled_encoder":  # Janus-Pro
        return {
            "vision":   {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "fusion":   None,
            "language": {"input_ids": input_ids, "attention_mask": attention_mask},
            "head":     None,
            "vision_und": {"pixel_values": pixel_values, "interpolate_pos_encoding": True},
            "vision_gen": None,  # generation pathway forward not measured in this paper
        }

    raise ValueError(f"Unknown family for dummy inputs: {family!r}")
