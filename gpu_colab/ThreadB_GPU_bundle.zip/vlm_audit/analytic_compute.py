"""Analytic forward-pass cost model of manuscript Section 3.2 (Table 3).

Reconstructed during revision item A13 (the original calculator was not in
the code tree) and validated cell-by-cell against the published Table 3
before any input was changed; see notebook 25.

Protocol (Section 3.2):

* A dense transformer component with ``P`` parameters, ``L`` layers and width
  ``d`` processing ``N`` tokens costs ``2·P·N + 4·L·N²·d`` FLOPs.
* The fusion module is costed over the tokens it emits, weight term only:
  ``2·P_fusion·N_out``.
* Inserted-token designs: the language model is costed over visual + text
  tokens and the cost is apportioned to "LLM-visual" / "LLM-text" by
  sequence share.
* Cross-attention designs: no visual tokens enter the language sequence.
  "LLM-text" is the language model over the text tokens only; "LLM-visual"
  is, per cross-attention layer, the key and value projections over the
  attended visual tokens (``2 × 2·d²·N_visual``, the first-order d×d
  convention) plus attention mixing (``4·N_text·N_visual·d``).
* Contrastive dual encoders: "LLM-text" is the text tower; there is no
  LLM-visual term.
* Single-stream and native designs: one shared transformer over visual +
  text tokens, apportioned by sequence share; encoder cost is zero.

Author: Sunita Sahu.
"""

from dataclasses import dataclass, asdict
from typing import Dict, Optional

GIGA = 1e9

DESIGN_INSERTED = "inserted"
DESIGN_CROSS_ATTENTION = "cross_attention"
DESIGN_CONTRASTIVE = "contrastive"
DESIGN_SHARED_STREAM = "shared_stream"


@dataclass
class ComputeInputs:
    """Every input of the Table 3 calculation for one model (parameters in raw counts)."""

    model: str
    design: str
    encoder_parameters: float = 0.0
    encoder_layers: int = 0
    encoder_tokens: int = 0
    encoder_width: int = 0
    fusion_parameters: float = 0.0
    fusion_output_tokens: int = 0
    language_parameters: float = 0.0
    language_layers: int = 0
    language_width: int = 0
    visual_tokens_in_language: int = 0
    text_tokens: int = 32
    cross_attention_layers: int = 0
    notes: str = ""

    def to_dict(self) -> Dict[str, object]:
        """Return the inputs as a flat dict (one CSV row)."""
        return asdict(self)


def dense_transformer_gflops(parameters: float, layers: int, tokens: int, width: int) -> float:
    """``2·P·N + 4·L·N²·d`` in GFLOPs."""
    return (2 * parameters * tokens + 4 * layers * tokens ** 2 * width) / GIGA


def cross_attention_visual_gflops(cross_layers: int, visual_tokens: int, text_tokens: int, width: int) -> float:
    """Per-layer K/V projections over visual tokens (d×d convention) plus attention mixing, summed over layers."""
    key_value_projections = 2 * (2 * width * width * visual_tokens)
    attention_mixing = 4 * text_tokens * visual_tokens * width
    return cross_layers * (key_value_projections + attention_mixing) / GIGA


def forward_cost(inputs: ComputeInputs) -> Dict[str, float]:
    """Return the Table 3 row for one model.

    Keys: ``encoder_g``, ``fusion_g``, ``llm_visual_g``, ``llm_text_g``,
    ``total_g``, ``vision_compute_share_pct`` (C_V%), ``vision_attributable_pct``.
    """
    encoder = 0.0
    if inputs.encoder_parameters:
        encoder = dense_transformer_gflops(
            inputs.encoder_parameters, inputs.encoder_layers, inputs.encoder_tokens, inputs.encoder_width
        )
    fusion = 2 * inputs.fusion_parameters * inputs.fusion_output_tokens / GIGA

    if inputs.design == DESIGN_CROSS_ATTENTION:
        llm_text = dense_transformer_gflops(
            inputs.language_parameters, inputs.language_layers, inputs.text_tokens, inputs.language_width
        )
        llm_visual = cross_attention_visual_gflops(
            inputs.cross_attention_layers, inputs.visual_tokens_in_language, inputs.text_tokens, inputs.language_width
        )
    elif inputs.design == DESIGN_CONTRASTIVE:
        llm_text = dense_transformer_gflops(
            inputs.language_parameters, inputs.language_layers, inputs.text_tokens, inputs.language_width
        )
        llm_visual = 0.0
    elif inputs.design in (DESIGN_INSERTED, DESIGN_SHARED_STREAM):
        sequence_length = inputs.visual_tokens_in_language + inputs.text_tokens
        language_total = dense_transformer_gflops(
            inputs.language_parameters, inputs.language_layers, sequence_length, inputs.language_width
        )
        llm_visual = language_total * inputs.visual_tokens_in_language / sequence_length
        llm_text = language_total * inputs.text_tokens / sequence_length
    else:
        raise ValueError(f"Unknown design {inputs.design!r}")

    total = encoder + fusion + llm_visual + llm_text
    return {
        "encoder_g": encoder,
        "fusion_g": fusion,
        "llm_visual_g": llm_visual,
        "llm_text_g": llm_text,
        "total_g": total,
        "vision_compute_share_pct": 100 * encoder / total,
        "vision_attributable_pct": 100 * (encoder + fusion + llm_visual) / total,
    }


def fisher_interval(rho: float, sample_size: int, z_critical: float = 1.959963984540054) -> Optional[tuple]:
    """95% Fisher-transform interval for a correlation coefficient (``None`` when n < 4)."""
    import math

    if sample_size < 4 or abs(rho) >= 1:
        return None
    half_width = z_critical / math.sqrt(sample_size - 3)
    centre = math.atanh(rho)
    return math.tanh(centre - half_width), math.tanh(centre + half_width)
