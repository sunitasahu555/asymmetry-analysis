"""Parameter names and shapes of every roster model, without downloading weights.

* transformers-native models: a weightless ``meta``-device skeleton built from the
  released config (gated repositories read through verified ungated mirrors);
* remote-code models (InternVL3, Molmo, DeepSeek-VL2, Janus-Pro): the tensor index of
  the released checkpoint (safetensors headers or the ``data.pkl`` of ``.bin`` files).

Serialised buffers (rotary ``inv_freq``, ``position_ids``, Janus-Pro's VQ
``codebook_used`` usage counter) are not parameters and are dropped.

Author: Sunita Sahu.
"""

from typing import Dict, Tuple

# Table name -> (models.py roster name, measured repository).
ROSTER_TABLE_NAMES = {
    "CLIP-ViT-L/14": ("CLIP-ViT-L/14", "openai/clip-vit-large-patch14"),
    "SigLIP-L/16": ("SigLIP-L/16", "google/siglip-large-patch16-384"),
    "SigLIP2-So400m/14": ("SigLIP2-So400m/14", "google/siglip2-so400m-patch14-384"),
    "ViLT-B/32": ("ViLT-B/32", "dandelin/vilt-b32-finetuned-vqa"),
    "BLIP-large": ("BLIP-large", "Salesforce/blip-image-captioning-large"),
    "BLIP-2-OPT-2.7B": ("BLIP-2-OPT-2.7B", "Salesforce/blip2-opt-2.7b"),
    "InstructBLIP-Vicuna-7B": ("InstructBLIP-Vicuna-7B", "Salesforce/instructblip-vicuna-7b"),
    "LLaVA-1.5-7B": ("LLaVA-1.5-7B", "llava-hf/llava-1.5-7b-hf"),
    "LLaVA-NeXT-7B": ("LLaVA-NeXT-7B", "llava-hf/llava-v1.6-mistral-7b-hf"),
    "Molmo-7B-D": ("Molmo-7B-D", "allenai/Molmo-7B-D-0924"),
    "IDEFICS-9B": ("IDEFICS-9B", "HuggingFaceM4/idefics-9b"),
    "Llama-3.2-11B-Vision": ("Llama-3.2-11B-Vision-Instruct", "meta-llama/Llama-3.2-11B-Vision-Instruct"),
    "Idefics2-8B": ("Idefics2-8B", "HuggingFaceM4/idefics2-8b"),
    "Qwen2-VL-7B": ("Qwen2-VL-7B-Instruct", "Qwen/Qwen2-VL-7B-Instruct"),
    "Qwen2.5-VL-7B": ("Qwen2.5-VL-7B-Instruct", "Qwen/Qwen2.5-VL-7B-Instruct"),
    "InternVL3-8B": ("InternVL3-8B", "OpenGVLab/InternVL3-8B"),
    "Pixtral-12B": ("Pixtral-12B", "mistral-community/pixtral-12b"),
    "DeepSeek-VL2-Small": ("DeepSeek-VL2-Small", "deepseek-ai/deepseek-vl2-small"),
    "Chameleon-7B": ("Chameleon-7B", "facebook/chameleon-7b"),
    "Janus-Pro-7B": ("Janus-Pro-7B", "deepseek-ai/Janus-Pro-7B"),
    # Roster extension (decision D9, 2026-10-04).
    "Qwen3-VL-8B": ("Qwen3-VL-8B-Instruct", "Qwen/Qwen3-VL-8B-Instruct"),
    "Gemma-4-12B": ("Gemma-4-12B-it", "google/gemma-4-12B-it"),
    "Gemma-4-26B-A4B": ("Gemma-4-26B-A4B-it", "google/gemma-4-26B-A4B-it"),
}

CONFIG_MIRRORS = {
    "meta-llama/Llama-3.2-11B-Vision-Instruct": "unsloth/Llama-3.2-11B-Vision-Instruct",
    "facebook/chameleon-7b": "FriendliAI/chameleon-7b",
}

# Gemma 4 needs transformers >= 5.5 / 5.10 for a skeleton; its checkpoint index gives the same names.
READ_FROM_CHECKPOINT = {"InternVL3-8B", "Molmo-7B-D", "DeepSeek-VL2-Small", "Janus-Pro-7B", "Qwen3-VL-8B",
                        "Gemma-4-12B", "Gemma-4-26B-A4B"}
# Gemma 4 also serialises three buffers: the per-layer output scalar and the vision standardisation constants.
BUFFER_SUFFIXES = ("inv_freq", "position_ids", "codebook_used", "layer_scalar", "std_bias", "std_scale")


def load_parameter_shapes(table_name: str) -> Dict[str, Tuple[int, ...]]:
    """Every parameter name -> shape for one roster model (no weights downloaded)."""
    from . import MODELS
    from .runner import build_model_skeleton
    from .checkpoint_headers import read_checkpoint_shapes

    roster_name, repository = ROSTER_TABLE_NAMES[table_name]
    if table_name in READ_FROM_CHECKPOINT:
        shapes = read_checkpoint_shapes(repository)
        return {name: tuple(shape) for name, shape in shapes.items() if not name.endswith(BUFFER_SUFFIXES)}
    spec = next(spec for spec in MODELS if spec.name == roster_name)
    model = build_model_skeleton(spec, config_repository=CONFIG_MIRRORS.get(repository))
    return {name: tuple(parameter.shape) for name, parameter in model.named_parameters()}
