"""Operator calls per decode step: the dispatch floor of batch-1 latency (decision log N28).

At batch size one, a reference implementation running a short sequence is limited by the host,
which issues one GPU kernel per operator call. The GPU run of notebooks 29/30/34 showed that a
language-model prefill of up to about 330 tokens takes exactly one decode step, and that decode
time per token follows the number of calls rather than the weights. This module counts the calls
so that notebook 31 can test that relation on every generative model.

Method, per model (CPU, random weights):

1. Build the reduced-depth real architecture of the validation spec with the library's default
   attention and expert kernels, as the GPU run loaded the released checkpoints (the FLOP
   validation instead forces eager attention and the eager expert loop).
2. Generate three tokens greedily from the 448 x 448 test input through the released processor,
   and count every aten call from the moment the first language block starts in the second pass
   (the first decode step) to the moment it starts in the third. That window is exactly one period
   of the decode loop: the step's blocks, final norm, head and generate's own per-step work, then
   the next step's embedding and masks (the same work as this step's). The GPU decode timing
   includes all of it. Keying the window on a language block, not on the whole model, also covers
   models whose ``generate`` delegates to an inner language model (BLIP, BLIP-2, InstructBLIP).
3. Attribute each call to the outermost repeated block of the language model it ran in (a child
   of a ModuleList under the language component's module paths), or to "outside blocks".
4. Scale to full depth: build the released configuration on the meta device (no memory), count
   its blocks by type (class name plus attention type), and add each type's calls per block
   times its full-depth count to the calls outside blocks.

Counted: calls that launch a kernel. Not counted: view and metadata calls, which launch none.
Host synchronisations (``.item()``, ``nonzero``) are tallied separately. The counts are taken at
the aten dispatcher on the CPU; a CUDA backend can fuse or split a few of them differently.

Author: Sunita Sahu.
"""

import json
import statistics
import time
from collections import Counter, defaultdict
from typing import Dict, Iterable, List, Optional

import pandas as pd

from .flop_counter_validation import build_validation_inputs, reduced_configuration, validation_spec
from .latency_measurement import RELEASED_PROCESSOR_KWARGS, set_padding_token, structured_test_image
from .tensor_cost_model import LANGUAGE

# Generative models whose decode step each environment can count. Molmo-7B-D and DeepSeek-VL2-Small
# run remote code under transformers 4.46.3 and are not counted.
TRANSFORMERS4_DECODE_MODELS = (
    "BLIP-large", "BLIP-2-OPT-2.7B", "InstructBLIP-Vicuna-7B", "LLaVA-1.5-7B", "LLaVA-NeXT-7B", "IDEFICS-9B",
    "Llama-3.2-11B-Vision", "Idefics2-8B", "Qwen2-VL-7B", "Qwen2.5-VL-7B", "Qwen3-VL-8B", "InternVL3-8B",
    "Pixtral-12B", "Chameleon-7B", "Janus-Pro-7B",
)
TRANSFORMERS5_DECODE_MODELS = ("Gemma-4-12B", "Gemma-4-26B-A4B")
# Counted in both environments: the same architecture under two library releases.
BRIDGE_MODEL = "Qwen3-VL-8B"

COUNTING_IMAGE_SIDE = 448
GENERATED_TOKENS = 3   # forward 1 = prefill, forward 2 = the counted decode step, forward 3 closes the window

# Calls that only change tensor metadata and launch no kernel.
VIEW_ONLY_OPERATIONS = {
    "view", "_unsafe_view", "transpose", "permute", "t", "expand", "unsqueeze", "squeeze", "slice", "select",
    "alias", "as_strided", "detach", "split", "split_with_sizes", "unbind", "unflatten", "narrow",
    "_reshape_alias", "lift_fresh", "reshape", "flatten", "sym_size", "sym_stride", "is_same_size",
}
# Calls that make the host wait for the device. ``_local_scalar_dense`` (``.item()``) is a copy to the host,
# not a kernel, so it is tallied here only.
HOST_SYNCHRONISING_OPERATIONS = {"_local_scalar_dense", "nonzero", "masked_select", "_unique2", "unique_consecutive"}


def operator_base_name(operator) -> str:
    """``aten.add.Tensor`` -> ``add``."""
    return operator.__name__.split(".")[0]


def _make_decode_step_counter():
    """A TorchDispatchMode that tallies kernel-launching calls by block while ``counting`` is set."""
    from torch.utils._python_dispatch import TorchDispatchMode

    class DecodeStepCounter(TorchDispatchMode):
        """Kernel-launching aten calls inside and outside the language blocks, during the counted window."""

        def __init__(self):
            """Start with empty tallies; counting off; no block entered."""
            super().__init__()
            self.counting = False
            self.current_block: Optional[str] = None
            self.calls_outside_blocks = 0
            self.calls_by_block: Dict[str, int] = defaultdict(int)
            self.operators_by_block: Dict[str, Counter] = defaultdict(Counter)
            self.host_synchronisations = 0

        def __torch_dispatch__(self, func, types, args=(), kwargs=None):
            """Tally one call (inside the window) and run it."""
            if self.counting:
                operator_name = operator_base_name(func)
                if operator_name in HOST_SYNCHRONISING_OPERATIONS:
                    self.host_synchronisations += 1
                if operator_name not in VIEW_ONLY_OPERATIONS and operator_name != "_local_scalar_dense":
                    if self.current_block is None:
                        self.calls_outside_blocks += 1
                    else:
                        self.calls_by_block[self.current_block] += 1
                        self.operators_by_block[self.current_block][operator_name] += 1
            return func(*args, **(kwargs or {}))

    return DecodeStepCounter()


def _is_under(module_name: str, path: str) -> bool:
    """True when ``module_name`` is ``path`` or lies inside it."""
    return module_name == path or module_name.startswith(path + ".")


def language_blocks(model, model_name: str) -> Dict[str, object]:
    """The outermost repeated blocks of the language model: children of a ModuleList under its module paths."""
    import torch

    paths = validation_spec(model_name).component_modules[LANGUAGE]
    included = [path for path in paths if not path.startswith("-")]
    excluded = [path[1:] for path in paths if path.startswith("-")]
    blocks: Dict[str, object] = {}
    for module_name, module in model.named_modules():
        if not isinstance(module, torch.nn.ModuleList):
            continue
        if not any(_is_under(module_name, path) for path in included):
            continue
        if any(_is_under(module_name, path) for path in excluded):
            continue
        if any(_is_under(module_name, block_name) for block_name in blocks):
            continue   # a list inside a block already found (expert lists, per-head lists)
        for index, child in enumerate(module):
            blocks[f"{module_name}.{index}"] = child
    return blocks


def block_type(block) -> str:
    """Class name, plus the attention type where the layer declares one (sliding versus full attention)."""
    for holder in (block, getattr(block, "self_attn", None)):
        if holder is None:
            continue
        for attribute in ("layer_type", "attention_type"):
            value = getattr(holder, attribute, None)
            if isinstance(value, str):
                return f"{type(block).__name__}:{value}"
    return type(block).__name__


def full_depth_block_types(model_name: str) -> Counter:
    """Blocks of each type in the released configuration (built on the meta device: no memory, no weights)."""
    import torch
    import transformers
    from transformers import AutoConfig

    spec = validation_spec(model_name)
    configuration = AutoConfig.from_pretrained(spec.repository)
    with torch.device("meta"):
        model = getattr(transformers, spec.model_class)._from_config(configuration, dtype=torch.bfloat16)
    return Counter(block_type(block) for block in language_blocks(model, model_name).values())


def _experts_implementation(model) -> Optional[str]:
    """The expert kernel the model uses, if it has routed experts."""
    if hasattr(model, "get_experts_implementation"):
        return str(model.get_experts_implementation())
    return None


def count_decode_step(model_name: str, image_side: int = COUNTING_IMAGE_SIDE) -> Dict[str, object]:
    """Kernel-launching calls of one decode step, measured at reduced depth and scaled to full depth."""
    import torch
    import transformers

    spec = validation_spec(model_name)
    torch.manual_seed(0)
    # No attention or expert override: the library default, as when the released checkpoint is loaded.
    model = getattr(transformers, spec.model_class)._from_config(reduced_configuration(model_name),
                                                                 dtype=torch.bfloat16)
    model = model.to(torch.bfloat16).eval()   # sub-configs may carry their own dtype; unify
    model.requires_grad_(False)
    set_padding_token(model)
    batch = build_validation_inputs(model_name, image_size=(image_side, image_side),
                                    processor_kwargs=RELEASED_PROCESSOR_KWARGS.get(model_name, {}),
                                    image=structured_test_image(image_side, image_side))
    blocks = language_blocks(model, model_name)
    if not blocks:
        raise LookupError(f"{model_name}: no repeated blocks under the language module paths")
    counter = _make_decode_step_counter()
    forward_passes = 0

    def open_or_close_window(module, arguments):
        """Pre-hook of the first language block: count from its second call until its third."""
        nonlocal forward_passes
        forward_passes += 1
        counter.counting = forward_passes == 2

    def entering_block(block_name: str):
        """Pre-hook factory: attribute calls to the outermost block entered."""
        def enter(module, arguments):
            """Remember the block, unless already inside one."""
            if counter.current_block is None:
                counter.current_block = block_name
        return enter

    def leaving_block(block_name: str):
        """Post-hook factory: stop attributing calls to the block."""
        def leave(module, arguments, output):
            """Forget the block when its own forward ends."""
            if counter.current_block == block_name:
                counter.current_block = None
        return leave

    first_block = next(iter(blocks.values()))
    # Registered before the block's own hook, so the window opens before the block is entered.
    handles = [first_block.register_forward_pre_hook(open_or_close_window)]
    for block_name, block in blocks.items():
        handles.append(block.register_forward_pre_hook(entering_block(block_name)))
        handles.append(block.register_forward_hook(leaving_block(block_name), always_call=True))
    try:
        with torch.no_grad(), counter:
            model.generate(**batch, max_new_tokens=GENERATED_TOKENS, min_new_tokens=GENERATED_TOKENS,
                           do_sample=False)
    finally:
        for handle in handles:
            handle.remove()
    if forward_passes < GENERATED_TOKENS:
        raise RuntimeError(f"{model_name}: the language model ran {forward_passes} passes, expected {GENERATED_TOKENS}")

    calls_by_type: Dict[str, List[int]] = defaultdict(list)
    operators_by_type: Dict[str, Counter] = defaultdict(Counter)
    for block_name, block in blocks.items():
        kind = block_type(block)
        calls_by_type[kind].append(counter.calls_by_block.get(block_name, 0))
        operators_by_type[kind] += counter.operators_by_block.get(block_name, Counter())
    full_depth_types = full_depth_block_types(model_name)
    unmeasured = sorted(set(full_depth_types) - set(calls_by_type))
    if unmeasured:
        raise ValueError(f"{model_name}: block types {unmeasured} occur at full depth but not in the reduced copy")
    calls_per_block = {kind: statistics.mean(calls) for kind, calls in calls_by_type.items()}
    calls_per_decode_step = counter.calls_outside_blocks + sum(
        calls_per_block[kind] * count for kind, count in full_depth_types.items())
    return {
        "model": model_name,
        "transformers_version": transformers.__version__,
        "torch_version": torch.__version__,
        "attention_implementation": getattr(model.config, "_attn_implementation", None),
        "experts_implementation": _experts_implementation(model),
        "image_side": image_side,
        "calls_per_decode_step": round(calls_per_decode_step),
        "calls_outside_blocks": counter.calls_outside_blocks,
        "calls_per_block_by_type": json.dumps(calls_per_block, sort_keys=True),
        "spread_within_type": json.dumps({kind: [min(calls), max(calls)] for kind, calls in calls_by_type.items()},
                                         sort_keys=True),
        "full_depth_blocks_by_type": json.dumps(dict(full_depth_types), sort_keys=True),
        "full_depth_blocks": sum(full_depth_types.values()),
        "reduced_blocks_by_type": json.dumps({kind: len(calls) for kind, calls in calls_by_type.items()},
                                             sort_keys=True),
        "host_synchronisations_reduced": counter.host_synchronisations,
        # Summed over the reduced copy's blocks of each type (see reduced_blocks_by_type).
        "top_operators_by_type": json.dumps({kind: operators.most_common(6)
                                             for kind, operators in operators_by_type.items()}),
    }


def decode_step_table(model_names: Iterable[str], logger=None) -> pd.DataFrame:
    """``count_decode_step`` for each model; a failure is recorded in its row and the loop continues."""
    rows = []
    for model_name in model_names:
        started = time.perf_counter()
        try:
            row = dict(count_decode_step(model_name), status="complete", error=None)
            message = (f"{model_name}: {row['calls_per_decode_step']} calls per decode step "
                       f"({row['full_depth_blocks']} blocks; {row['calls_per_block_by_type']})")
        except Exception as error:   # keep counting the other models; the reason is kept in the table
            row = {"model": model_name, "status": "failed", "error": f"{type(error).__name__}: {error}"[:400]}
            message = f"{model_name}: FAILED ({row['error']})"
        row["seconds"] = round(time.perf_counter() - started, 1)
        rows.append(row)
        print(message)
        if logger is not None:
            logger.info(message)
    return pd.DataFrame(rows)
