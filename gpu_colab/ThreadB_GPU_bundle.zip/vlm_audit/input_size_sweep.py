"""Forward compute as a function of the input image (follow-up F2; reviewer item A9).

Notebook 27 priced every model at two common inputs (448 x 448 and 1024 x 1024). The GPU
run (notebooks 29-31) then showed that measured prefill latency changes by up to 5.8x
between those two inputs within one model, and that 20 of 171 model pairs swap order.
This module turns the two points into curves: every model is priced, with the validated
tensor-level cost model, on

* square images from 224 px up to the largest input any released preprocessing accepts
  (Qwen3-VL's pixel limit, 16,777,216 = 4,096^2; Qwen2-VL and Qwen2.5-VL stop at 3,584^2), and
* images of one pixel count (1024^2) but different aspect ratios.

Two predictions per input:

* **intrinsic** - the revised protocol of Table 3 (no padding; DeepSeek-VL2's latent
  attention in decompressed form);
* **executed** - what the reference implementation runs, as validated on the GPU:
  Llama-3.2-Vision's four tile slots, Idefics2's padded sub-images and DeepSeek-VL2's
  absorbed latent attention. Every other model executes its intrinsic input.

CPU only and weightless: released processors, checkpoint headers and configs.

Author: Sunita Sahu.
"""

import math
from typing import Callable, Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd

from .correlation_grid import pairwise_order_changes, spearman_permutation_test
from .flop_counter_validation import validation_token_account
from .latency_analysis import format_p_value
from .latency_measurement import CHAMELEON_VQ_ENCODER_GFLOPS
from .tensor_cost_model import forward_cost_revised
from .token_accounting import TokenAccount, account_gemma4, account_visual_tokens, run_processor

# Square sides in pixels. 4,096^2 is the largest image Qwen3-VL keeps at full resolution (16,777,216 pixels);
# Qwen2-VL / Qwen2.5-VL stop at 3,584^2 (max_pixels = 12,845,056); every other model at or below 2,048 px.
SQUARE_SIDES = (224, 336, 448, 560, 672, 784, 896, 1024, 1120, 1344, 1568, 1792, 2048, 2688, 3584, 4096)
SMALL_SIDE, REFERENCE_SIDE = 448, 1024          # the two inputs of notebook 27 and of the GPU run

# Same pixel count, different shape (width : height), landscape and portrait: several processors add layout
# tokens per row (row breaks, newline tokens), so the two orientations of one shape can differ slightly.
ASPECT_RATIOS = ((1, 1), (4, 3), (3, 4), (16, 9), (9, 16), (2, 1), (1, 2), (3, 1), (1, 3), (4, 1), (1, 4))
ASPECT_PIXEL_COUNT = 1024 * 1024

TEXT_TOKENS = 32                                 # prompt length of the published protocol

# How the released preprocessing turns an image into visual tokens.
INPUT_HANDLING = {
    "CLIP-ViT-L/14": "fixed resize", "SigLIP-L/16": "fixed resize", "SigLIP2-So400m/14": "fixed resize",
    "BLIP-large": "fixed resize", "BLIP-2-OPT-2.7B": "fixed resize", "InstructBLIP-Vicuna-7B": "fixed resize",
    "IDEFICS-9B": "fixed resize", "LLaVA-1.5-7B": "fixed resize", "Janus-Pro-7B": "fixed resize",
    "Chameleon-7B": "fixed resize",
    "ViLT-B/32": "aspect-preserving resize",
    "LLaVA-NeXT-7B": "tiling", "Llama-3.2-11B-Vision": "tiling", "InternVL3-8B": "tiling", "Molmo-7B-D": "tiling",
    "DeepSeek-VL2-Small": "tiling", "Idefics2-8B": "tiling",
    "Qwen2-VL-7B": "native resolution", "Qwen2.5-VL-7B": "native resolution", "Pixtral-12B": "native resolution",
    "Qwen3-VL-8B": "native resolution",
    "Gemma-4-12B": "resize to a token budget", "Gemma-4-26B-A4B": "resize to a token budget",
}

# Models whose reference implementation computes more (or differently) than the intrinsic input.
EXECUTION_DIFFERS = ("Llama-3.2-11B-Vision", "Idefics2-8B", "DeepSeek-VL2-Small", "Gemma-4-12B", "Gemma-4-26B-A4B")

# Relative gap below which two models count as tied (same threshold as the latency analysis).
MINIMUM_ORDER_GAP = 0.05


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

def square_shapes(sides: Sequence[int] = SQUARE_SIDES) -> List[Tuple[str, int, int]]:
    """(label, height, width) of the square images of the sweep."""
    return [(f"{side}x{side}", side, side) for side in sides]


def aspect_ratio_shapes(pixel_count: int = ASPECT_PIXEL_COUNT,
                        ratios: Sequence[Tuple[int, int]] = ASPECT_RATIOS) -> List[Tuple[str, int, int]]:
    """(label, height, width) of images with about ``pixel_count`` pixels each, labelled width:height."""
    shapes = []
    for ratio_width, ratio_height in ratios:
        width = round(math.sqrt(pixel_count * ratio_width / ratio_height))
        height = round(pixel_count / width)
        shapes.append((f"{ratio_width}:{ratio_height}", height, width))
    return shapes


def boundary_tokens(account: TokenAccount) -> int:
    """Fusion-boundary bandwidth: tokens the language side receives (inserted or cross-attended)."""
    return account.language_visual_tokens or account.cross_attended_tokens or account.fusion_output_tokens


def executed_account(model_name: str, height: int, width: int) -> TokenAccount:
    """Token account of what the reference implementation runs for one image.

    Llama-3.2-Vision runs all four tile slots (1,608 padded tokens each); Idefics2 pads every
    sub-image to the largest one. Both are read from the released processor's output, with
    the rules validated against the GPU run (``validation_token_account``).
    """
    if model_name in ("Llama-3.2-11B-Vision", "Idefics2-8B"):
        batch, _ = run_processor(model_name, height, width)
        return validation_token_account(model_name, batch, image_size=(height, width))
    if model_name in ("Gemma-4-12B", "Gemma-4-26B-A4B"):
        return account_gemma4(model_name, height, width, executed=True)
    return account_visual_tokens(model_name, height, width)


def cost_options(model_name: str, executed: bool) -> Dict[str, object]:
    """Extra arguments of ``forward_cost_revised`` for one model and one prediction."""
    options: Dict[str, object] = {}
    if model_name == "Chameleon-7B":
        # The VQ encoder always sees a 512 x 512 resize; its op-level count does not depend on the input.
        options["measured_encoder_gflops"] = CHAMELEON_VQ_ENCODER_GFLOPS
    if executed and model_name == "DeepSeek-VL2-Small":
        options["mla_attention_form"] = "absorbed"
    return options


# ---------------------------------------------------------------------------
# Pricing
# ---------------------------------------------------------------------------

def price_input(model_name: str, parameter_shapes: Dict[str, Tuple[int, ...]], label: str, height: int, width: int,
                text_tokens: int = TEXT_TOKENS) -> Dict[str, object]:
    """Intrinsic and executed forward compute of one model for one input image (one table row)."""
    account = account_visual_tokens(model_name, height, width)
    intrinsic = forward_cost_revised(model_name, parameter_shapes, account, text_tokens=text_tokens,
                                     **cost_options(model_name, executed=False))
    row: Dict[str, object] = {
        "model": model_name, "input_handling": INPUT_HANDLING[model_name], "shape": label,
        "height": height, "width": width, "pixels": height * width,
        "encoder_passes": len(account.encoder_sequences), "encoder_tokens": account.encoder_tokens,
        "boundary_tokens": boundary_tokens(account), "language_visual_tokens": account.language_visual_tokens,
        **intrinsic.to_row(),
        "unrouted_parameters": len(intrinsic.unrouted_parameters),
    }
    if model_name in EXECUTION_DIFFERS:
        executed = forward_cost_revised(model_name, parameter_shapes, executed_account(model_name, height, width),
                                        text_tokens=text_tokens, **cost_options(model_name, executed=True))
        row["executed_total_g"] = executed.total_g
        row["executed_encoder_g"] = executed.encoder_g
    else:
        row["executed_total_g"] = intrinsic.total_g
        row["executed_encoder_g"] = intrinsic.encoder_g
    row["executed_over_intrinsic"] = row["executed_total_g"] / row["total_g"]
    return row


def sweep_inputs(parameter_shapes_by_model: Dict[str, Dict[str, Tuple[int, ...]]],
                 shapes: Sequence[Tuple[str, int, int]], text_tokens: int = TEXT_TOKENS,
                 progress: Optional[Callable[[str], None]] = None) -> pd.DataFrame:
    """Price every model on every input shape; one row per (model, shape)."""
    rows = []
    for model_name, parameter_shapes in parameter_shapes_by_model.items():
        for label, height, width in shapes:
            rows.append(price_input(model_name, parameter_shapes, label, height, width, text_tokens))
        if progress is not None:
            progress(f"{model_name}: {len(shapes)} inputs priced")
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Analysis of the square sweep
# ---------------------------------------------------------------------------

def _totals_by_side(square_table: pd.DataFrame, column: str = "total_g") -> pd.DataFrame:
    """Model x side matrix of one column of the square sweep (sides as integer columns)."""
    return square_table.pivot(index="model", columns="height", values=column)


def growth_summary(square_table: pd.DataFrame, small_side: int = SMALL_SIDE,
                   reference_side: int = REFERENCE_SIDE) -> pd.DataFrame:
    """How each model's compute grows with the image side.

    Columns: compute at the smallest, small, reference and largest side; the side at which
    compute stops growing (``saturation_side``); the growth from the small side to that
    plateau; the number of distinct compute levels (few for tilings, many for native
    resolution); and the exponent of compute in pixel count between the small and the
    reference side (1 = proportional to pixels; below 1 when fixed text work dilutes it,
    above 1 when quadratic attention dominates).
    """
    totals = _totals_by_side(square_table)
    executed = _totals_by_side(square_table, "executed_total_g")
    smallest_side, largest_side = min(totals.columns), max(totals.columns)
    rows = []
    for model_name in totals.index:
        curve = totals.loc[model_name]
        plateau = curve.max()
        saturation_side = int(curve[curve >= plateau * (1 - 1e-9)].index.min())
        levels = len(set(np.round(curve.to_numpy() / plateau, 6)))
        pixel_ratio = (reference_side / small_side) ** 2
        rows.append({
            "model": model_name, "input_handling": INPUT_HANDLING[model_name],
            f"total_g_{smallest_side}": curve[smallest_side], f"total_g_{small_side}": curve[small_side],
            f"total_g_{reference_side}": curve[reference_side], "total_g_plateau": plateau,
            "saturation_side": saturation_side if levels > 1 else pd.NA,
            f"ratio_{reference_side}_over_{small_side}": curve[reference_side] / curve[small_side],
            f"ratio_plateau_over_{small_side}": plateau / curve[small_side],
            "ratio_plateau_over_smallest": plateau / curve[smallest_side],
            "compute_levels": levels,
            f"pixel_exponent_{small_side}_to_{reference_side}":
                math.log(curve[reference_side] / curve[small_side]) / math.log(pixel_ratio),
            "executed_plateau_g": executed.loc[model_name].max(),
            "encoder_tokens_plateau": int(square_table[(square_table["model"] == model_name)
                                                       & (square_table["height"] == largest_side)]["encoder_tokens"].iloc[0]),
        })
    summary = pd.DataFrame(rows).astype({"saturation_side": "Int64"})
    return summary.sort_values(f"ratio_plateau_over_{small_side}").reset_index(drop=True)


def order_changes_between(square_table: pd.DataFrame, first_side: int = SMALL_SIDE,
                          second_side: int = REFERENCE_SIDE, column: str = "total_g",
                          minimum_gap: float = MINIMUM_ORDER_GAP) -> pd.DataFrame:
    """Model pairs whose cheaper member changes between two square sides."""
    totals = _totals_by_side(square_table, column)
    return pairwise_order_changes(totals[first_side].rename(f"g_{first_side}"),
                                  totals[second_side].rename(f"g_{second_side}"), minimum_gap)


def order_changes_across_sweep(square_table: pd.DataFrame, column: str = "total_g",
                               minimum_gap: float = MINIMUM_ORDER_GAP) -> pd.DataFrame:
    """Model pairs whose cheaper member changes anywhere in the sweep, with the sides where it changes.

    Sides at which the two models are within ``minimum_gap`` of each other are skipped
    (a tie is not an order). ``crossing_sides`` lists every side at which the cheaper
    model differs from the one at the previous non-tied side.
    """
    totals = _totals_by_side(square_table, column)
    sides = sorted(totals.columns)
    names = sorted(totals.index)
    rows = []
    for first_index, first in enumerate(names):
        for second in names[first_index + 1:]:
            cheaper_by_side = []
            for side in sides:
                first_value, second_value = totals.loc[first, side], totals.loc[second, side]
                if abs(first_value - second_value) / max(first_value, second_value) > minimum_gap:
                    cheaper_by_side.append((side, first if first_value < second_value else second))
            crossings = [side for (side, cheaper), (_, previous) in zip(cheaper_by_side[1:], cheaper_by_side[:-1])
                         if cheaper != previous]
            if crossings:
                rows.append({"first": first, "second": second,
                             "cheaper_at_smallest": cheaper_by_side[0][1], "cheaper_at_largest": cheaper_by_side[-1][1],
                             "crossings": len(crossings), "crossing_sides": ", ".join(str(side) for side in crossings)})
    return pd.DataFrame(rows, columns=["first", "second", "cheaper_at_smallest", "cheaper_at_largest",
                                       "crossings", "crossing_sides"])


def rank_agreement_by_side(square_table: pd.DataFrame, column: str = "total_g") -> pd.DataFrame:
    """Kendall tau between the compute rankings of the models at every pair of sides."""
    return _totals_by_side(square_table, column).corr(method="kendall")


def vision_share_by_side(square_table: pd.DataFrame) -> pd.DataFrame:
    """Encoder share of FLOPs (C_V%) and vision-attributable share for every model and side (long table)."""
    columns = ["model", "input_handling", "height", "vision_compute_share_pct", "vision_attributable_pct"]
    return square_table[columns].rename(columns={"height": "side"}).reset_index(drop=True)


def vision_share_ranges(square_table: pd.DataFrame, small_side: int = SMALL_SIDE,
                        reference_side: int = REFERENCE_SIDE) -> pd.DataFrame:
    """Range of the encoder share of FLOPs (C_V%) over the sweep, per model."""
    shares = _totals_by_side(square_table, "vision_compute_share_pct")
    rows = []
    for model_name in shares.index:
        curve = shares.loc[model_name]
        rows.append({"model": model_name, "input_handling": INPUT_HANDLING[model_name],
                     f"C_V_pct_{small_side}": curve[small_side], f"C_V_pct_{reference_side}": curve[reference_side],
                     "C_V_pct_min": curve.min(), "side_of_min": int(curve.idxmin()),
                     "C_V_pct_max": curve.max(), "side_of_max": int(curve.idxmax()),
                     "spread_points": curve.max() - curve.min()})
    return pd.DataFrame(rows).sort_values("spread_points", ascending=False).reset_index(drop=True)


def executed_versus_intrinsic_by_side(square_table: pd.DataFrame) -> pd.DataFrame:
    """Executed / intrinsic compute along the sweep for the models whose execution differs."""
    rows = square_table[square_table["model"].isin(EXECUTION_DIFFERS)]
    return rows.pivot(index="height", columns="model", values="executed_over_intrinsic")


# ---------------------------------------------------------------------------
# Same pixels, different shape
# ---------------------------------------------------------------------------

def aspect_ratio_summary(aspect_table: pd.DataFrame) -> pd.DataFrame:
    """Per model: compute range over images with the same pixel count but different shapes."""
    rows = []
    for model_name, model_rows in aspect_table.groupby("model", sort=False):
        totals = model_rows.set_index("shape")["total_g"]
        tokens = model_rows.set_index("shape")["boundary_tokens"]
        rows.append({"model": model_name, "input_handling": INPUT_HANDLING[model_name],
                     "total_g_square": totals.get("1:1"), "total_g_min": totals.min(), "cheapest_shape": totals.idxmin(),
                     "total_g_max": totals.max(), "most_expensive_shape": totals.idxmax(),
                     "max_over_min": totals.max() / totals.min(),
                     "boundary_tokens_min": int(tokens.min()), "boundary_tokens_max": int(tokens.max())})
    return pd.DataFrame(rows).sort_values("max_over_min", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------------------
# A processor setting as a convention: Gemma 4's soft-token budget
# ---------------------------------------------------------------------------

GEMMA4_BUDGETS = (70, 140, 280, 560, 1120)   # the budgets the released Gemma 4 processors accept; 280 is the default


def token_budget_sweep(parameter_shapes_by_model: Dict[str, Dict[str, Tuple[int, ...]]],
                       budgets: Sequence[int] = GEMMA4_BUDGETS, side: int = REFERENCE_SIDE,
                       text_tokens: int = TEXT_TOKENS) -> pd.DataFrame:
    """Intrinsic compute of the Gemma 4 models at every soft-token budget, for one square image.

    The budget is a processor argument, not part of the architecture: the same model and
    image cost what the setting makes them cost. Above 1,024 tokens the sliding-window layers
    would see a window shorter than the sequence; their products are still counted over the
    whole prefix, as the reference attention computes them (masked, not skipped).
    """
    rows = []
    for model_name in ("Gemma-4-12B", "Gemma-4-26B-A4B"):
        if model_name not in parameter_shapes_by_model:
            continue
        for budget in budgets:
            account = account_gemma4(model_name, side, side, max_soft_tokens=budget)
            breakdown = forward_cost_revised(model_name, parameter_shapes_by_model[model_name], account,
                                             text_tokens=text_tokens)
            rows.append({"model": model_name, "soft_token_budget": budget, "resized_to": account.details["resized_to"],
                         "image_tokens": account.language_visual_tokens, "encoder_tokens": account.encoder_tokens,
                         "total_g": breakdown.total_g, "vision_compute_share_pct": breakdown.vision_compute_share_pct})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Agreement with the measured latency (notebook 31 outputs)
# ---------------------------------------------------------------------------

def latency_agreement(square_table: pd.DataFrame, input_scaling: pd.DataFrame, latency_flips: pd.DataFrame,
                      small_side: int = SMALL_SIDE, reference_side: int = REFERENCE_SIDE,
                      minimum_gap: float = MINIMUM_ORDER_GAP) -> Dict[str, object]:
    """Do the compute curves anticipate what the GPU measured between the two inputs?

    Args:
        square_table: the square sweep (this module).
        input_scaling: ``nb31_input_scaling.csv`` (measured latency ratio and the FLOPs predicted
            for the exact inputs that were timed).
        latency_flips: ``nb31_latency_order_flips.csv`` (pairs whose measured latency order changed).

    Returns:
        ``ratios``: per measured model, the compute ratio reference/small (intrinsic and executed,
        from the sweep) beside the measured latency ratio; ``spearman_*``: rank correlation of the
        latency ratio with each compute ratio; ``flip_overlap``: how many latency order changes are
        also order changes of the predicted FLOPs of the timed inputs, and how many are not.
    """
    intrinsic = _totals_by_side(square_table)
    executed = _totals_by_side(square_table, "executed_total_g")
    measured = input_scaling.set_index("model")
    models = [name for name in measured.index if name in intrinsic.index]
    ratios = pd.DataFrame({
        "intrinsic_flop_ratio": intrinsic.loc[models, reference_side] / intrinsic.loc[models, small_side],
        "executed_flop_ratio": executed.loc[models, reference_side] / executed.loc[models, small_side],
        "latency_ratio": measured.loc[models, "latency_ratio"],
    })
    result: Dict[str, object] = {"ratios": ratios.sort_values("latency_ratio").reset_index().rename(columns={"index": "model"})}
    for column in ("intrinsic_flop_ratio", "executed_flop_ratio"):
        result[f"spearman_{column}"] = spearman_permutation_test(ratios[column].to_numpy(), ratios["latency_ratio"].to_numpy())

    predicted_small = measured["predicted_total_gflops_small"].rename("predicted_small")
    predicted_large = measured["predicted_total_gflops_large"].rename("predicted_large")
    flop_flips = pairwise_order_changes(predicted_small, predicted_large, minimum_gap)
    latency_pairs = {tuple(sorted(pair)) for pair in zip(latency_flips["first"], latency_flips["second"])}
    flop_pairs = {tuple(sorted(pair)) for pair in zip(flop_flips["first"], flop_flips["second"])}
    result["flip_overlap"] = {"latency_flips": len(latency_pairs), "flop_flips": len(flop_pairs),
                              "both": len(latency_pairs & flop_pairs),
                              "latency_only": sorted(latency_pairs - flop_pairs),
                              "flop_only": sorted(flop_pairs - latency_pairs)}
    return result


# ---------------------------------------------------------------------------
# Plain-text summary
# ---------------------------------------------------------------------------

def findings_markdown(growth: pd.DataFrame, between: pd.DataFrame, across: pd.DataFrame, rank_agreement: pd.DataFrame,
                      share_ranges: pd.DataFrame, executed_ratio: pd.DataFrame, aspect: pd.DataFrame,
                      agreement: Optional[Dict[str, object]], model_count: int,
                      small_side: int = SMALL_SIDE, reference_side: int = REFERENCE_SIDE,
                      budget_table: Optional[pd.DataFrame] = None) -> str:
    """Numbers of notebook 32 as a markdown summary (every figure computed, none typed)."""
    pairs = model_count * (model_count - 1) // 2
    sides = sorted(rank_agreement.columns)
    constant = growth[growth["compute_levels"] == 1]["model"].tolist()
    growing = growth[growth["compute_levels"] > 1].sort_values(f"ratio_plateau_over_{small_side}", ascending=False)
    lines = [
        "# Notebook 32 - compute versus input size: findings",
        "",
        f"Intrinsic forward compute (revised Table 3 protocol, {TEXT_TOKENS} prompt tokens) of {model_count} models "
        f"on {len(sides)} square images ({sides[0]}-{sides[-1]} px) and on {len(ASPECT_RATIOS)} images of "
        f"{ASPECT_PIXEL_COUNT:,} pixels with different aspect ratios. CPU only; same cost model as Table 3 "
        "(validated within 0.008% of an op-level count at full depth, notebook 31).",
        "",
        "## 1. How compute grows with the image",
        "",
        f"* {len(constant)} models cost the same at every square size (a fixed resize, or Gemma 4's fixed token "
        "budget): " + ", ".join(constant) + ".",
        f"* {len(growing)} models grow until a plateau. Plateau over the {small_side}^2 cost:",
    ]
    for _, row in growing.iterrows():
        lines.append(f"  * {row['model']} ({row['input_handling']}): x{row[f'ratio_plateau_over_{small_side}']:.1f} "
                     f"(plateau {row['total_g_plateau']:,.0f} G from {row['saturation_side']} px; "
                     f"{row['compute_levels']} distinct levels; {reference_side}/{small_side} = "
                     f"x{row[f'ratio_{reference_side}_over_{small_side}']:.2f})")
    lines += [
        "",
        "## 2. Which model is cheaper depends on the input",
        "",
        f"* Between {small_side}^2 and {reference_side}^2, {len(between)} of {pairs} pairs change order "
        f"(both gaps > {MINIMUM_ORDER_GAP:.0%}).",
        f"* Across the whole sweep, {len(across)} of {pairs} pairs change order at least once; "
        f"{int((across['crossings'] > 1).sum()) if len(across) else 0} of them more than once.",
        f"* Kendall tau between the rankings at {sides[0]} px and {sides[-1]} px: "
        f"{rank_agreement.loc[sides[0], sides[-1]]:+.2f}; between {small_side} and {reference_side} px: "
        f"{rank_agreement.loc[small_side, reference_side]:+.2f}.",
        "",
        "## 3. The vision encoder's share of FLOPs (C_V) changes with the input (largest ranges)",
        "",
    ]
    for _, row in share_ranges.head(8).iterrows():
        lines.append(f"* {row['model']}: C_V {row['C_V_pct_min']:.1f}% ({row['side_of_min']} px) to "
                     f"{row['C_V_pct_max']:.1f}% ({row['side_of_max']} px)")
    lines += ["", "## 4. Executed versus intrinsic compute along the sweep", ""]
    for model_name in executed_ratio.columns:
        curve = executed_ratio[model_name]
        if curve.max() - curve.min() < 1e-6:
            lines.append(f"* {model_name}: executed / intrinsic x{curve.max():.3f} at every size")
            continue
        lines.append(f"* {model_name}: executed / intrinsic from x{curve.min():.2f} ({int(curve.idxmin())} px) "
                     f"to x{curve.max():.2f} ({int(curve.idxmax())} px)")
    lines += ["", f"## 5. Same {ASPECT_PIXEL_COUNT:,} pixels, different shape", ""]
    for _, row in aspect[aspect["max_over_min"] > 1.01].iterrows():
        lines.append(f"* {row['model']}: x{row['max_over_min']:.2f} (cheapest {row['cheapest_shape']}, "
                     f"most expensive {row['most_expensive_shape']})")
    if budget_table is not None and len(budget_table):
        totals = budget_table.pivot(index="soft_token_budget", columns="model", values="total_g")
        lines += ["", f"## 6. A processor setting changes cost: Gemma 4's soft-token budget ({reference_side}^2 image)", ""]
        for model_name in totals.columns:
            curve = totals[model_name]
            lines.append(f"* {model_name}: {curve.min():,.0f} G (budget {int(curve.idxmin())}) to {curve.max():,.0f} G "
                         f"(budget {int(curve.idxmax())}), x{curve.max() / curve.min():.1f}")
        if totals.shape[1] == 2:
            first, second = totals.columns
            cheaper = (totals[first] < totals[second]).map({True: first, False: second})
            lines.append("* Cheaper model by budget: " + ", ".join(f"{int(budget)}: {name}" for budget, name in cheaper.items()))
    if agreement is not None:
        overlap = agreement["flip_overlap"]
        executed_test = agreement["spearman_executed_flop_ratio"]
        intrinsic_test = agreement["spearman_intrinsic_flop_ratio"]
        lines += [
            "", "## 7. Agreement with the measured latency (GPU run, notebook 31)", "",
            f"* Latency ratio {reference_side}/{small_side} against the executed compute ratio: Spearman "
            f"rho = {executed_test['rho']:+.2f} ({format_p_value(executed_test['p_value'])}, "
            f"n = {executed_test['sample_size']}); against the intrinsic ratio: {intrinsic_test['rho']:+.2f} "
            f"({format_p_value(intrinsic_test['p_value'])}).",
            f"* Of the {overlap['latency_flips']} measured latency order changes, {overlap['both']} are also "
            f"order changes of the predicted FLOPs of the timed inputs ({overlap['flop_flips']} FLOP order changes in all).",
        ]
    return "\n".join(lines) + "\n"
