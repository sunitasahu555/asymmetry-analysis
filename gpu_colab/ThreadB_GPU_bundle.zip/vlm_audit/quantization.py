"""Quantization helpers for fitting larger models on a single L40S (48 GB).

Default precision is **fp16**. Every model in the n=10 roster fits fp16 on one
L40S; the largest is ~18 GB (IDEFICS-9B). Quantization is
*opt-in* via the ``--quantization`` flag on each measurement script — kept here
as a fallback for:

* Future additions outside the current roster (e.g. Qwen2-VL-72B, LLaVA-NeXT-34B)
* Cases where activation memory pushes a borderline model over 48 GB
* Reviewer requests to report quantized-deployment numbers alongside fp16

When quantization is applied, the resulting measurement is **not directly
comparable** to fp16 numbers (param counts shrink ~4× at int8, ~8× at 4-bit;
FLOPs are unaffected since they're analytical). The runner labels every record
with ``hardware`` and ``notes`` strings showing what was used so the paper can
flag those rows.

Levels supported (via bitsandbytes):

* ``None``  — no quantization, fp16/bf16/fp32 as passed.
* ``"int8"`` — load_in_8bit (LLM.int8()), about 2× smaller than fp16.
* ``"4bit"`` — NF4 with double quantization, compute_dtype=fp16, about 4× smaller.
"""

from typing import Optional


# Approx single-L40S budget. fp16 footprint must stay under this minus a
# safety margin for activations.
DEFAULT_GPU_GB = 48.0
DEFAULT_SAFETY_MARGIN_GB = 8.0


def get_quantization_config(level: Optional[str]):
    """Build a ``BitsAndBytesConfig`` for the requested level.

    Returns ``None`` for ``level=None``, so callers can do:

        cfg = get_quantization_config(args.quantization)
        if cfg is not None:
            kwargs["quantization_config"] = cfg

    without an extra branch.
    """
    if level is None or level == "none":
        return None
    import torch
    from transformers import BitsAndBytesConfig

    if level == "int8":
        return BitsAndBytesConfig(load_in_8bit=True)

    if level == "4bit":
        return BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=torch.float16,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
        )

    raise ValueError(
        f"Unknown quantization level: {level!r}. Expected one of: None, 'int8', '4bit'."
    )


def auto_quantization(
    model_spec,
    gpu_gb: float = DEFAULT_GPU_GB,
    safety_margin_gb: float = DEFAULT_SAFETY_MARGIN_GB,
) -> Optional[str]:
    """Pick a quantization level based on the model's fp16 size vs single-GPU VRAM.

    Heuristic:
    * fp16 fits with margin   → ``None``  (no quantization)
    * int8 fits with margin   → ``"int8"`` (≈ ½ fp16 size)
    * otherwise               → ``"4bit"`` (≈ ¼ fp16 size)

    For the current n=10 roster on a 48 GB L40S, this returns ``None`` for
    every model. The function is retained for future additions.
    """
    fp16_gb = getattr(model_spec, "fits_in_gb_fp16", 0.0)
    available = gpu_gb - safety_margin_gb
    if fp16_gb <= available:
        return None
    if fp16_gb * 0.5 <= available:
        return "int8"
    return "4bit"


def describe(level: Optional[str]) -> str:
    """One-line human-readable description for logging."""
    if level is None or level == "none":
        return "no quantization (fp16/bf16/fp32 as requested)"
    if level == "int8":
        return "8-bit (bitsandbytes LLM.int8())"
    if level == "4bit":
        return "4-bit NF4 + double quant (compute_dtype=fp16)"
    return f"unknown level: {level!r}"
