"""vlm_audit — Phase 2 measurement pipeline for the architectural-asymmetry paper.

Public API used by the numbered scripts:

    from vlm_audit import (
        MODELS, get_model_list,
        ModelRecord, ComponentRecord, InputConfig, FreezingPolicy,
        ExperimentLogger,
        extract_components, COMPONENT_NAMES, EXTENDED_COMPONENT_NAMES,
        count_params, count_active_params, count_image_token_vocab,
        count_dynamic_tile_tokens, compute_trainable_from_policy,
        measure_flops, measure_peak_memory, count_fusion_boundary_tokens,
        build_dummy_inputs,
        run_full_audit, load_existing_record, merge_records,
        get_quantization_config, auto_quantization, describe_quantization,
    )
"""

from .schema import ModelRecord, ComponentRecord, InputConfig, FreezingPolicy
from .logging_utils import ExperimentLogger
from .models import MODELS, MODELS_BY_ID, MODELS_BY_NAME, ModelSpec, get_model_list, FAMILIES
from .components import (
    extract_components,
    COMPONENT_NAMES,
    EXTENDED_COMPONENT_NAMES,
    freezing_policy_hint,
    trainable_components_for_family,
    find_inserted_cross_attention_modules,
    INSERTED_CROSS_ATTENTION_ONLY,
)
from .metrics import (
    count_params,
    count_active_params,
    count_image_token_vocab,
    count_dynamic_tile_tokens,
    compute_trainable_from_policy,
    measure_flops,
    measure_peak_memory,
    count_fusion_boundary_tokens,
    count_model_params,
    partition_component_params,
    count_inserted_cross_attention_params,
)
from .dummy_inputs import build_dummy_inputs
from .quantization import (
    get_quantization_config,
    auto_quantization,
    describe as describe_quantization,
)
from .runner import (
    run_full_audit,
    load_existing_record,
    merge_records,
    build_model_skeleton,
    audit_parameter_attribution,
)

__version__ = "0.3.0-revision-a13"
