"""Canonical model roster — Phase 2: 20 vision-language models, 13 family categories.

The Phase-1 n=10 roster is preserved at the top; the Phase-2 additions follow.

New 2024–2026 additions in Phase 2:
* SigLIP2 (2025) — updated contrastive baseline
* Qwen2-VL-7B + Qwen2.5-VL-7B + InternVL3-8B — dynamic_tile_adapter_llm (NEW family)
* Llama-3.2-11B-Vision — cross_attention_llm (2nd in family, fixes n=1)
* Pixtral-12B — adapter_llm_own_encoder (NEW family)
* Molmo-7B-D — adapter_llm (CLIP encoder + Qwen2 backbone)
* DeepSeek-VL2-Small — moe_adapter_llm (NEW family)
* Chameleon-7B — native_early_fusion (NEW family; breaks V/F/L)
* Janus-Pro-7B — native_decoupled_encoder (NEW family)

See ../docs/PHASE_2_IMPLEMENTATION_PLAN.md for rationale per pick.
"""

from dataclasses import dataclass, field
from typing import List, Optional


FAMILIES = [
    # --- Phase 1 ---
    "dual_encoder_contrastive",
    "bridge_module_precursor",
    "bridge_module",
    "bridge_module_adapter_llm",
    "adapter_llm",
    "cross_attention_llm",
    "perceiver_adapter_llm",
    "single_stream_fused",
    # --- Phase 2 new families ---
    "dynamic_tile_adapter_llm",
    "adapter_llm_own_encoder",
    "moe_adapter_llm",
    "native_early_fusion",
    "native_decoupled_encoder",
]


@dataclass
class ModelSpec:
    name: str
    hf_id: str
    family: str
    release_year: int
    native_image_hw: tuple
    fits_in_gb_fp16: float
    notes: str = ""
    recent_gen: bool = False
    # Phase-2 fields:
    architecture_pattern: str = "dense_adapter"
    is_moe: bool = False
    n_experts_total: Optional[int] = None
    n_experts_active_per_token: Optional[int] = None
    requires_trust_remote_code: bool = False
    # Revision fix A13: per-model deviations from the family's canonical
    # freezing policy (see components.trainable_components_for_family), plus
    # the documentary source for the recipe actually used.
    trainable_policy_override: Optional[dict] = None
    training_recipe_note: str = ""


MODELS: List[ModelSpec] = [
    # ==================================================================
    # PHASE 1 ROSTER (preserved)
    # ==================================================================
    ModelSpec(
        name="CLIP-ViT-L/14",
        hf_id="openai/clip-vit-large-patch14",
        family="dual_encoder_contrastive",
        release_year=2021,
        native_image_hw=(224, 224),
        fits_in_gb_fp16=1.0,
        architecture_pattern="dual_tower_contrastive",
    ),
    ModelSpec(
        name="SigLIP-L/16",
        hf_id="google/siglip-large-patch16-384",
        family="dual_encoder_contrastive",
        release_year=2023,
        native_image_hw=(384, 384),
        fits_in_gb_fp16=1.5,
        notes="Sigmoid-loss CLIP variant.",
        architecture_pattern="dual_tower_contrastive",
    ),
    ModelSpec(
        name="BLIP-large",
        hf_id="Salesforce/blip-image-captioning-large",
        family="bridge_module_precursor",
        release_year=2022,
        native_image_hw=(384, 384),
        fits_in_gb_fp16=1.0,
        notes="Precursor to BLIP-2.",
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="BLIP-2-OPT-2.7B",
        hf_id="Salesforce/blip2-opt-2.7b",
        family="bridge_module",
        release_year=2023,
        native_image_hw=(224, 224),
        fits_in_gb_fp16=7.0,
        notes="Q-Former + frozen ViT-g + frozen OPT-2.7B.",
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="InstructBLIP-Vicuna-7B",
        hf_id="Salesforce/instructblip-vicuna-7b",
        family="bridge_module_adapter_llm",
        release_year=2023,
        native_image_hw=(224, 224),
        fits_in_gb_fp16=17.0,
        notes="Instruction-tuned BLIP-2 with Vicuna-7B.",
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="LLaVA-1.5-7B",
        hf_id="llava-hf/llava-1.5-7b-hf",
        family="adapter_llm",
        release_year=2023,
        native_image_hw=(336, 336),
        fits_in_gb_fp16=16.0,
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="LLaVA-NeXT-7B",
        hf_id="llava-hf/llava-v1.6-mistral-7b-hf",
        family="adapter_llm",
        release_year=2024,
        native_image_hw=(336, 336),
        fits_in_gb_fp16=16.0,
        notes="Multi-tile patching.",
        recent_gen=True,
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="IDEFICS-9B",
        hf_id="HuggingFaceM4/idefics-9b",
        family="cross_attention_llm",
        release_year=2023,
        native_image_hw=(224, 224),
        fits_in_gb_fp16=18.0,
        notes="Perceiver Resampler + LLaMA-7B with gated cross-attention.",
        architecture_pattern="cross_attention",
        training_recipe_note=(
            "Base checkpoint: 'The pre-trained backbones are frozen while we train the newly "
            "initialized parameters' (HuggingFaceM4/idefics-9b model card) -> Perceiver Resampler "
            "+ 8 gated cross-attention blocks trained; vision encoder, LLaMA-7B and LM head frozen. "
            "The -instruct variant unfreezes all parameters (same model card)."
        ),
    ),
    ModelSpec(
        name="Idefics2-8B",
        hf_id="HuggingFaceM4/idefics2-8b",
        family="perceiver_adapter_llm",
        release_year=2024,
        native_image_hw=(224, 224),
        fits_in_gb_fp16=16.0,
        notes="Perceiver resampler -> 64 tokens.",
        recent_gen=True,
        architecture_pattern="perceiver",
    ),
    ModelSpec(
        name="ViLT-B/32",
        hf_id="dandelin/vilt-b32-finetuned-vqa",
        family="single_stream_fused",
        release_year=2021,
        native_image_hw=(384, 384),
        fits_in_gb_fp16=0.5,
        notes="Symmetric-allocation limit case. n=1 in family by design.",
        architecture_pattern="single_stream",
    ),

    # ==================================================================
    # PHASE 2 ADDITIONS (10 new models)
    # ==================================================================

    # --- Updated contrastive baseline (2025) ---
    ModelSpec(
        name="SigLIP2-So400m/14",
        hf_id="google/siglip2-so400m-patch14-384",
        family="dual_encoder_contrastive",
        release_year=2025,
        native_image_hw=(384, 384),
        fits_in_gb_fp16=1.5,
        notes="2025 update to SigLIP. Multitask language-vision objectives + attention pooling.",
        recent_gen=True,
        architecture_pattern="dual_tower_contrastive",
    ),

    # --- Dynamic-tile adapter-LLM (NEW family) ---
    ModelSpec(
        name="Qwen2-VL-7B-Instruct",
        hf_id="Qwen/Qwen2-VL-7B-Instruct",
        family="dynamic_tile_adapter_llm",
        release_year=2024,
        native_image_hw=(448, 448),
        fits_in_gb_fp16=17.0,
        notes="Foundational dynamic-resolution model. MRoPE; ViT-L/14 + MLP merger.",
        recent_gen=True,
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="Qwen2.5-VL-7B-Instruct",
        hf_id="Qwen/Qwen2.5-VL-7B-Instruct",
        family="dynamic_tile_adapter_llm",
        release_year=2025,
        native_image_hw=(448, 448),
        fits_in_gb_fp16=17.0,
        notes="Direct successor to Qwen2-VL. ViT with SwiGLU + RMSNorm + window attention.",
        recent_gen=True,
        architecture_pattern="dense_adapter",
    ),
    ModelSpec(
        name="InternVL3-8B",
        hf_id="OpenGVLab/InternVL3-8B",
        family="dynamic_tile_adapter_llm",
        release_year=2025,
        native_image_hw=(448, 448),
        fits_in_gb_fp16=17.0,
        notes="InternViT-300M + Qwen2.5-7B backbone. Pixel-shuffle compression 1024->256.",
        recent_gen=True,
        architecture_pattern="dense_adapter",
        requires_trust_remote_code=True,
    ),

    # --- Adapter-LLM (Phase-2 additions to existing family) ---
    ModelSpec(
        name="Molmo-7B-D",
        hf_id="allenai/Molmo-7B-D-0924",
        family="adapter_llm",
        release_year=2024,
        native_image_hw=(336, 336),
        fits_in_gb_fp16=16.0,
        notes="Fully-open data + weights. CLIP encoder + Qwen2-7B. Multiscale crops.",
        recent_gen=True,
        architecture_pattern="dense_adapter",
        requires_trust_remote_code=True,
    ),

    # --- Adapter-LLM with own vision encoder (NEW family) ---
    ModelSpec(
        name="Pixtral-12B",
        # Use the HF-converted community port (has standard model.safetensors
        # shards). The original mistralai/Pixtral-12B-2409 ships only the
        # consolidated.safetensors blob and will fail with
        # "no model.safetensors" on transformers.from_pretrained.
        hf_id="mistral-community/pixtral-12b",
        family="adapter_llm_own_encoder",
        release_year=2024,
        native_image_hw=(1024, 1024),
        fits_in_gb_fp16=24.0,
        notes="Vision encoder trained from scratch. HF-converted port; original Mistral release uses consolidated.safetensors. May need int8 on single L40S.",
        recent_gen=True,
        architecture_pattern="dense_adapter",
    ),

    # --- Cross-attention LLM (Phase-2 addition) ---
    ModelSpec(
        name="Llama-3.2-11B-Vision-Instruct",
        hf_id="meta-llama/Llama-3.2-11B-Vision-Instruct",
        family="cross_attention_llm",
        release_year=2024,
        native_image_hw=(560, 560),
        fits_in_gb_fp16=22.0,
        notes="Meta's official open multimodal. ViT + cross-attention into Llama-3.1-8B.",
        recent_gen=True,
        architecture_pattern="cross_attention",
        trainable_policy_override={"vision": True},
        training_recipe_note=(
            "Llama 3 paper (arXiv:2407.21783) Sec. 7.4: 'The vision encoder is unfrozen, while the "
            "text model weights are kept frozen'; Sec. 7.5 SFT: 'we only update the vision encoder "
            "and image adapter weights'. Image adapter = projector + 8 cross-attention layers."
        ),
    ),

    # --- MoE adapter-LLM (NEW family) ---
    ModelSpec(
        name="DeepSeek-VL2-Small",
        hf_id="deepseek-ai/deepseek-vl2-small",
        family="moe_adapter_llm",
        release_year=2024,
        native_image_hw=(384, 384),
        fits_in_gb_fp16=30.0,
        notes="DeepSeekMoE LLM (top-6 of 64 experts) + SigLIP-SO400M + dynamic tiling. ~2.8B activated.",
        recent_gen=True,
        architecture_pattern="moe_dense",
        is_moe=True,
        n_experts_total=64,
        n_experts_active_per_token=6,
        requires_trust_remote_code=True,
    ),

    # --- Native unified-token (NEW family — breaks V/F/L) ---
    ModelSpec(
        name="Chameleon-7B",
        hf_id="facebook/chameleon-7b",
        family="native_early_fusion",
        release_year=2024,
        native_image_hw=(512, 512),
        fits_in_gb_fp16=14.0,
        notes="Token-based early-fusion. Image and text in same vocab.",
        recent_gen=True,
        architecture_pattern="early_fusion",
    ),
    ModelSpec(
        name="Janus-Pro-7B",
        hf_id="deepseek-ai/Janus-Pro-7B",
        family="native_decoupled_encoder",
        release_year=2025,
        native_image_hw=(384, 384),
        fits_in_gb_fp16=14.0,
        notes="Decoupled encoders (SigLIP-L for understanding + separate for generation) + shared LLM.",
        recent_gen=True,
        architecture_pattern="decoupled_encoder",
        requires_trust_remote_code=True,
    ),
]


MODELS_BY_ID = {m.hf_id: m for m in MODELS}
MODELS_BY_NAME = {m.name: m for m in MODELS}


def get_model_list(
    filter_year_gte: Optional[int] = None,
    filter_family: Optional[str] = None,
    names: Optional[List[str]] = None,
    hf_ids: Optional[List[str]] = None,
    recent_gen_only: bool = False,
    phase: Optional[int] = None,
) -> List[ModelSpec]:
    """Return a filtered subset of MODELS.

    All filters are AND-ed together.

    ``phase=1`` → only original Phase-1 entries (first 10).
    ``phase=2`` → only Phase-2 additions (last 10).
    """
    result = list(MODELS)
    if phase == 1:
        result = result[:10]
    elif phase == 2:
        result = result[10:]
    if filter_year_gte is not None:
        result = [m for m in result if m.release_year >= filter_year_gte]
    if filter_family is not None:
        result = [m for m in result if m.family == filter_family]
    if recent_gen_only:
        result = [m for m in result if m.recent_gen]
    if names is not None:
        wanted = set(names)
        result = [m for m in result if m.name in wanted]
    if hf_ids is not None:
        wanted = set(hf_ids)
        result = [m for m in result if m.hf_id in wanted]
    return result
