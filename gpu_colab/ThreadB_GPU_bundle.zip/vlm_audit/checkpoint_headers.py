"""Read tensor names and shapes from released checkpoints without downloading weights.

Revision fix A13. Gives an independent, code-free checkpoint total for the
parameter-attribution residual check:

* ``.safetensors`` checkpoints: the JSON header of each shard is read through
  ``huggingface_hub.get_safetensors_metadata`` (a few kilobytes per shard).
* PyTorch ``.bin`` checkpoints (zip archives): only the zip central directory
  and the small ``data.pkl`` entry are fetched with HTTP range requests, and
  ``data.pkl`` is read by a restricted unpickler that records tensor shapes
  and refuses every other global. Tensor storages are never downloaded.

Typical use::

    shapes = read_checkpoint_shapes("deepseek-ai/Janus-Pro-7B")
    counts = attribute_by_prefix(shapes, JANUS_PREFIX_RULES)

Author: Sunita Sahu.
"""

import io
import json
import math
import pickle
import struct
import zlib
from typing import Dict, List, Optional, Tuple

# Serialized non-parameter tensors (buffers) that some checkpoints include.
BUFFER_NAME_SUFFIXES = ("inv_freq", "position_ids", "num_batches_tracked", "masked_bias", "_float_tensor")

HUB_RESOLVE_URL = "https://huggingface.co/{repository_id}/resolve/main/{file_name}"


# ---------------------------------------------------------------------------
# safetensors
# ---------------------------------------------------------------------------

def read_safetensors_shapes(repository_id: str) -> Dict[str, Tuple[int, ...]]:
    """Return ``{tensor_name: shape}`` from a safetensors repository's shard headers."""
    from huggingface_hub import get_safetensors_metadata

    metadata = get_safetensors_metadata(repository_id)
    shapes = {}
    for file_metadata in metadata.files_metadata.values():
        for tensor_name, tensor_info in file_metadata.tensors.items():
            shapes[tensor_name] = tuple(tensor_info.shape)
    return shapes


# ---------------------------------------------------------------------------
# PyTorch .bin (zip) via HTTP range requests
# ---------------------------------------------------------------------------

def _fetch_byte_range(url: str, start: int, end: int) -> bytes:
    """Fetch bytes ``start``..``end`` (inclusive) of a remote file."""
    import requests

    response = requests.get(url, headers={"Range": f"bytes={start}-{end}"}, timeout=120, allow_redirects=True)
    response.raise_for_status()
    return response.content


def _remote_file_size(url: str) -> int:
    """Size in bytes of a remote file."""
    import requests

    response = requests.head(url, allow_redirects=True, timeout=120)
    response.raise_for_status()
    return int(response.headers["Content-Length"])


class _TensorShapeRecord:
    """Inert stand-in for a tensor that keeps only its shape."""

    def __init__(self, shape):
        """Store the tensor shape."""
        self.shape = tuple(shape)


def _rebuild_tensor_record(storage, storage_offset, size, stride, *unused_arguments):
    """Replacement for ``torch._utils._rebuild_tensor_v2``: records the shape only."""
    return _TensorShapeRecord(size)


def _rebuild_parameter_record(data, requires_grad, backward_hooks, *unused_arguments):
    """Replacement for ``torch._utils._rebuild_parameter``."""
    return data


class _StorageTypeRecord:
    """Inert stand-in for torch storage classes such as ``torch.BFloat16Storage``."""


class _StateDictRecord(dict):
    """Stand-in for ``collections.OrderedDict``; older checkpoints attach a ``_metadata`` attribute to it."""


class _ShapeOnlyUnpickler(pickle.Unpickler):
    """Unpickler that resolves only the torch tensor-rebuild helpers; everything else is refused."""

    ALLOWED_GLOBALS = {
        ("torch._utils", "_rebuild_tensor_v2"): _rebuild_tensor_record,
        ("torch._utils", "_rebuild_parameter"): _rebuild_parameter_record,
        ("collections", "OrderedDict"): _StateDictRecord,
    }

    def find_class(self, module, name):
        """Resolve whitelisted globals; torch storage types become inert records."""
        if (module, name) in self.ALLOWED_GLOBALS:
            return self.ALLOWED_GLOBALS[(module, name)]
        if module == "torch" and name.endswith("Storage"):
            return _StorageTypeRecord
        raise pickle.UnpicklingError(f"Blocked global {module}.{name}")

    def persistent_load(self, persistent_id):
        """Storages are referenced by persistent id; nothing is loaded."""
        return None


def _read_zip_directory_location(url: str, file_size: int) -> Tuple[int, int]:
    """Return ``(directory_size, directory_offset)`` of a remote zip, supporting zip64."""
    tail_length = min(file_size, 1 << 20)
    tail = _fetch_byte_range(url, file_size - tail_length, file_size - 1)
    zip64_locator_offset = tail.rfind(b"PK\x06\x07")
    if zip64_locator_offset != -1:
        zip64_record_offset = struct.unpack("<Q", tail[zip64_locator_offset + 8:zip64_locator_offset + 16])[0]
        record = _fetch_byte_range(url, zip64_record_offset, zip64_record_offset + 55)
        directory_size, directory_offset = struct.unpack("<QQ", record[40:56])
        return directory_size, directory_offset
    end_of_directory_offset = tail.rfind(b"PK\x05\x06")
    directory_size, directory_offset = struct.unpack(
        "<II", tail[end_of_directory_offset + 12:end_of_directory_offset + 20]
    )
    return directory_size, directory_offset


def read_torch_bin_shapes(url: str) -> Dict[str, Tuple[int, ...]]:
    """Return ``{tensor_name: shape}`` for one remote PyTorch zip checkpoint file."""
    file_size = _remote_file_size(url)
    directory_size, directory_offset = _read_zip_directory_location(url, file_size)
    directory = _fetch_byte_range(url, directory_offset, directory_offset + directory_size - 1)
    position = 0
    while directory[position:position + 4] == b"PK\x01\x02":
        compression_method = struct.unpack("<H", directory[position + 10:position + 12])[0]
        compressed_size, uncompressed_size = struct.unpack("<II", directory[position + 20:position + 28])
        name_length, extra_length, comment_length = struct.unpack("<HHH", directory[position + 28:position + 34])
        local_header_offset = struct.unpack("<I", directory[position + 42:position + 46])[0]
        entry_name = directory[position + 46:position + 46 + name_length].decode()
        extra_field = directory[position + 46 + name_length:position + 46 + name_length + extra_length]
        if 0xFFFFFFFF in (compressed_size, uncompressed_size, local_header_offset):
            value_count = (len(extra_field) - 4) // 8
            zip64_values = list(struct.unpack("<" + "Q" * value_count, extra_field[4:4 + 8 * value_count]))
            if uncompressed_size == 0xFFFFFFFF:
                uncompressed_size = zip64_values.pop(0)
            if compressed_size == 0xFFFFFFFF:
                compressed_size = zip64_values.pop(0)
            if local_header_offset == 0xFFFFFFFF:
                local_header_offset = zip64_values.pop(0)
        if entry_name.endswith("data.pkl"):
            local_header = _fetch_byte_range(url, local_header_offset, local_header_offset + 29)
            local_name_length, local_extra_length = struct.unpack("<HH", local_header[26:30])
            data_start = local_header_offset + 30 + local_name_length + local_extra_length
            payload = _fetch_byte_range(url, data_start, data_start + compressed_size - 1)
            if compression_method == 8:
                payload = zlib.decompress(payload, -15)
            state_dict = _ShapeOnlyUnpickler(io.BytesIO(payload)).load()
            return {
                name: value.shape for name, value in state_dict.items()
                if isinstance(value, _TensorShapeRecord)
            }
        position += 46 + name_length + extra_length + comment_length
    raise RuntimeError(f"data.pkl not found in {url}")


def _list_torch_bin_files(repository_id: str) -> List[str]:
    """Return the ``.bin`` weight files of a repository (sharded or single)."""
    from huggingface_hub import list_repo_files

    repository_files = list_repo_files(repository_id)
    if "pytorch_model.bin.index.json" in repository_files:
        from huggingface_hub import hf_hub_download

        index_path = hf_hub_download(repository_id, "pytorch_model.bin.index.json")
        with open(index_path, "r", encoding="utf-8") as index_file:
            weight_map = json.load(index_file)["weight_map"]
        return sorted(set(weight_map.values()))
    return [file_name for file_name in repository_files if file_name.endswith(".bin") and "pytorch_model" in file_name]


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def read_checkpoint_shapes(repository_id: str) -> Dict[str, Tuple[int, ...]]:
    """Return ``{tensor_name: shape}`` for a repository, preferring safetensors over ``.bin``."""
    from huggingface_hub.errors import NotASafetensorsRepoError

    try:
        return read_safetensors_shapes(repository_id)
    except NotASafetensorsRepoError:
        shapes = {}
        for file_name in _list_torch_bin_files(repository_id):
            url = HUB_RESOLVE_URL.format(repository_id=repository_id, file_name=file_name)
            shapes.update(read_torch_bin_shapes(url))
        return shapes


def split_parameters_and_buffers(shapes: Dict[str, Tuple[int, ...]]) -> Tuple[int, int]:
    """Return ``(parameter_elements, buffer_elements)`` using ``BUFFER_NAME_SUFFIXES``."""
    parameter_elements = 0
    buffer_elements = 0
    for tensor_name, shape in shapes.items():
        if tensor_name.endswith(BUFFER_NAME_SUFFIXES):
            buffer_elements += math.prod(shape)
        else:
            parameter_elements += math.prod(shape)
    return parameter_elements, buffer_elements


def attribute_by_prefix(
    shapes: Dict[str, Tuple[int, ...]],
    prefix_rules: Dict[str, str],
    loose_tensor_rules: Optional[Dict[str, str]] = None,
) -> Dict[str, object]:
    """Attribute checkpoint tensors to components by name prefix (longest prefix wins).

    ``prefix_rules`` maps a tensor-name prefix (e.g. ``"language_model.lm_head."``)
    to a component. Because the longest matching prefix wins, a nested module
    such as an LM head inside the language model is owned once, by its own
    component - the checkpoint-side equivalent of
    ``metrics.partition_component_params``. ``loose_tensor_rules`` maps exact
    top-level tensor names (e.g. ``"image_newline"``) to a component.

    Returns ``{"component_counts", "attributed_total", "unattributed_by_name",
    "checkpoint_parameter_total", "buffer_elements"}``.
    """
    loose_tensor_rules = loose_tensor_rules or {}
    sorted_prefixes = sorted(prefix_rules, key=len, reverse=True)
    component_counts: Dict[str, int] = {}
    unattributed_by_name: Dict[str, int] = {}
    checkpoint_parameter_total = 0
    buffer_elements = 0
    for tensor_name, shape in shapes.items():
        element_count = math.prod(shape)
        if tensor_name.endswith(BUFFER_NAME_SUFFIXES):
            buffer_elements += element_count
            continue
        checkpoint_parameter_total += element_count
        owner = loose_tensor_rules.get(tensor_name)
        if owner is None:
            owner = next((prefix_rules[prefix] for prefix in sorted_prefixes if tensor_name.startswith(prefix)), None)
        if owner is None:
            unattributed_by_name[tensor_name] = element_count
            continue
        component_counts[owner] = component_counts.get(owner, 0) + element_count
    return {
        "component_counts": component_counts,
        "attributed_total": sum(component_counts.values()),
        "unattributed_by_name": unattributed_by_name,
        "checkpoint_parameter_total": checkpoint_parameter_total,
        "buffer_elements": buffer_elements,
    }
