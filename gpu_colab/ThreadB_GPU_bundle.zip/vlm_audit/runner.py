"""High-level orchestration: run all metrics on one model, save the record.

Phase-2 changes:
* HF class dispatch extended for: Qwen2-VL, Qwen2.5-VL, InternVL3 (custom),
  Pixtral (LLaVA-class wrapper), Llama-3.2-Vision (Mllama),
  DeepSeek-VL2 (custom), Chameleon, Janus-Pro.
* ``count_trainable_from_policy`` used in place of ``requires_grad`` (bug F-5).
* ``measure_flops`` now returns ``(value, source)``; record stores both
  ``flops_g`` and ``flops_source`` + ``flops_estimate``.
* Iterates ``comps.keys()`` directly so native families with ``fused_transformer``
  / ``vision_und`` / ``vision_gen`` components are measured too.
* Every error in every step is caught and logged with a full traceback; the
  per-model record is still saved with partial measurements so reruns can
  incrementally fill in the gaps.
"""

import gc
import json
import time
from pathlib import Path
from typing import Optional, Set

from .schema import ModelRecord, ComponentRecord, FreezingPolicy, InputConfig
from .components import (
    extract_components,
    COMPONENT_NAMES,
    EXTENDED_COMPONENT_NAMES,
    freezing_policy_hint,
)
from .dummy_inputs import build_dummy_inputs
from .metrics import (
    count_params,
    measure_flops,
    measure_peak_memory,
    count_fusion_boundary_tokens,
    count_active_params,
    count_image_token_vocab,
    count_dynamic_tile_tokens,
    compute_trainable_from_policy,
    partition_component_params,
    count_inserted_cross_attention_params,
)
from .logging_utils import ExperimentLogger, sanitize_for_filename
from .quantization import get_quantization_config, describe as describe_quantization


# ---------------------------------------------------------------------------
# Parameter-attribution audit (revision fix A13)
# ---------------------------------------------------------------------------

def build_parameter_audit_entry(attribution, inserted_cross_attention_params, model_spec) -> dict:
    """Shape the ``partition_component_params`` result into the JSON ``parameter_audit`` block."""
    return {
        "model_total": attribution["model_total"],
        "attributed_total": attribution["attributed_total"],
        "residual": attribution["residual"],
        "residual_check_passed": attribution["residual"] == 0,
        "unattributed_by_path": attribution["unattributed_by_path"],
        "overlaps_resolved": attribution["overlaps_resolved"],
        "alias_of": attribution["alias_of"],
        "inserted_cross_attention_params": inserted_cross_attention_params,
        "training_recipe_note": getattr(model_spec, "training_recipe_note", "") or "",
        "method": "partition_component_params (every parameter owned by exactly one component)",
    }


def _log_parameter_audit(log, audit_entry) -> None:
    """Write the residual check to the experiment log; non-zero residuals are logged as warnings."""
    log.info(f"Whole-model parameters : {audit_entry['model_total']:,}")
    log.info(f"Attributed to components: {audit_entry['attributed_total']:,}")
    log.metric("params_model_total", audit_entry["model_total"])
    log.metric("params_residual", audit_entry["residual"])
    for overlap in audit_entry["overlaps_resolved"]:
        log.info(
            f"Overlap resolved: {overlap['params']:,} params owned by '{overlap['owned_by']}' "
            f"(also inside '{overlap['also_inside']}')"
        )
    if audit_entry["inserted_cross_attention_params"]:
        log.info(f"Inserted cross-attention params (inside language): "
                 f"{audit_entry['inserted_cross_attention_params']:,}")
    if audit_entry["residual"] != 0:
        log.warn(
            f"RESIDUAL CHECK FAILED: {audit_entry['residual']:,} parameters are not attributed "
            f"to any component: {audit_entry['unattributed_by_path']}"
        )
    else:
        log.info("Residual check passed: component sum equals whole-model total.")


def build_model_skeleton(model_spec, config_repository: Optional[str] = None):
    """Instantiate a model on the ``meta`` device from its config only (no weights downloaded).

    Parameter counts depend only on tensor shapes, so a skeleton gives exact
    counts on a CPU laptop in seconds. ``config_repository`` lets a gated
    repository's config be read from a verified ungated mirror.
    Not supported for ``requires_trust_remote_code`` models.
    """
    import torch
    from transformers import AutoConfig

    if model_spec.requires_trust_remote_code:
        raise ValueError(f"{model_spec.name} needs remote code; use checkpoint headers instead")
    model_class = _resolve_hf_class(model_spec.family, model_spec.hf_id)
    config = AutoConfig.from_pretrained(config_repository or model_spec.hf_id)
    with torch.device("meta"):
        # Auto* classes (dual encoders) only build through from_config.
        if model_class.__name__.startswith("Auto"):
            return model_class.from_config(config)
        if hasattr(model_class, "_from_config"):
            return model_class._from_config(config)
        return model_class(config)


def audit_parameter_attribution(model_spec, config_repository: Optional[str] = None) -> dict:
    """Run extraction + partition + trainable policy on a weightless skeleton.

    Returns ``{"component_counts", "trainable_counts", "raw_module_counts", "audit"}``
    where ``raw_module_counts`` are the un-partitioned per-module sums (what the
    pre-A13 pipeline recorded) for before/after comparison.
    """
    model = build_model_skeleton(model_spec, config_repository=config_repository)
    components = extract_components(model, model_spec.family)
    attribution = partition_component_params(model, components)
    inserted_cross_attention_params = count_inserted_cross_attention_params(model)
    trainable_counts = compute_trainable_from_policy(
        model_spec, components,
        partitioned_counts=attribution["component_counts"],
        inserted_cross_attention_params=inserted_cross_attention_params,
    )
    raw_module_counts = {name: count_params(module) for name, module in components.items()}
    return {
        "component_counts": attribution["component_counts"],
        "trainable_counts": trainable_counts,
        "raw_module_counts": raw_module_counts,
        "audit": build_parameter_audit_entry(attribution, inserted_cross_attention_params, model_spec),
    }


# ---------------------------------------------------------------------------
# Per-family HF class dispatch
# ---------------------------------------------------------------------------

def _resolve_hf_class(family: str, hf_id: str, trust_remote_code: bool = False):
    """Return the right HuggingFace class for a (family, model) pair.

    For some Phase-2 models (InternVL3, Molmo, DeepSeek-VL2, Janus-Pro) the
    architecture is not in the released transformers package and we use
    ``AutoModel`` with ``trust_remote_code=True``.
    """
    if family == "dual_encoder_contrastive":
        from transformers import AutoModel
        return AutoModel
    if family == "bridge_module_precursor":
        from transformers import BlipForConditionalGeneration
        return BlipForConditionalGeneration
    if family == "bridge_module":
        from transformers import Blip2ForConditionalGeneration
        return Blip2ForConditionalGeneration
    if family == "bridge_module_adapter_llm":
        from transformers import InstructBlipForConditionalGeneration
        return InstructBlipForConditionalGeneration
    if family == "adapter_llm":
        if "v1.6" in hf_id or "next" in hf_id.lower():
            from transformers import LlavaNextForConditionalGeneration
            return LlavaNextForConditionalGeneration
        if "molmo" in hf_id.lower():
            # Molmo uses a custom AllenAI architecture
            from transformers import AutoModelForCausalLM
            return AutoModelForCausalLM
        from transformers import LlavaForConditionalGeneration
        return LlavaForConditionalGeneration
    if family == "cross_attention_llm":
        if "idefics" in hf_id.lower():
            from transformers import IdeficsForVisionText2Text
            return IdeficsForVisionText2Text
        if "llama-3.2" in hf_id.lower() or "llama-3-2" in hf_id.lower():
            from transformers import MllamaForConditionalGeneration
            return MllamaForConditionalGeneration
        # Default fallback
        from transformers import AutoModelForCausalLM
        return AutoModelForCausalLM
    if family == "perceiver_adapter_llm":
        from transformers import Idefics2ForConditionalGeneration
        return Idefics2ForConditionalGeneration
    if family == "single_stream_fused":
        from transformers import ViltForQuestionAnswering
        return ViltForQuestionAnswering

    # --- Phase 2 ---
    if family == "dynamic_tile_adapter_llm":
        if "qwen2-vl" in hf_id.lower() or "qwen2_vl" in hf_id.lower():
            try:
                from transformers import Qwen2VLForConditionalGeneration
                return Qwen2VLForConditionalGeneration
            except ImportError:
                from transformers import AutoModelForCausalLM
                return AutoModelForCausalLM
        if "qwen2.5-vl" in hf_id.lower() or "qwen2_5_vl" in hf_id.lower():
            try:
                from transformers import Qwen2_5_VLForConditionalGeneration
                return Qwen2_5_VLForConditionalGeneration
            except ImportError:
                from transformers import AutoModelForCausalLM
                return AutoModelForCausalLM
        # InternVL3 — custom; use AutoModel with trust_remote_code
        from transformers import AutoModel
        return AutoModel
    if family == "adapter_llm_own_encoder":
        # Pixtral uses LlavaForConditionalGeneration class with Pixtral configs.
        from transformers import LlavaForConditionalGeneration
        return LlavaForConditionalGeneration
    if family == "moe_adapter_llm":
        # DeepSeek-VL2 — config.json has no auto_map, so AutoModel will fail.
        # Use deepseek_vl2 package's DeepseekVLV2ForCausalLM if installed.
        # The package's modeling code imports `LlamaFlashAttention2` which
        # transformers 4.45+ removed. Monkey-patch a backward-compat alias
        # before importing — DeepseekVLV2 doesn't actually use the flash
        # variant at inference time (the import is at module top-level only).
        # Install with: pip install --no-deps git+https://github.com/deepseek-ai/DeepSeek-VL2.git
        try:
            import transformers.models.llama.modeling_llama as _m
            if not hasattr(_m, "LlamaFlashAttention2"):
                _m.LlamaFlashAttention2 = _m.LlamaAttention
            from deepseek_vl2.models import DeepseekVLV2ForCausalLM
            return DeepseekVLV2ForCausalLM
        except ImportError:
            from transformers import AutoModel
            return AutoModel
    if family == "native_early_fusion":
        try:
            from transformers import ChameleonForConditionalGeneration
            return ChameleonForConditionalGeneration
        except ImportError:
            from transformers import AutoModelForCausalLM
            return AutoModelForCausalLM
    if family == "native_decoupled_encoder":
        # Janus-Pro — config.json declares model_type='multi_modality' but has
        # NO auto_map. transformers AutoModel cannot load it (raises ValueError
        # before checking trust_remote_code fallback). The DeepSeek-released
        # `janus` package provides MultiModalityCausalLM, which is the only
        # working loader. Install via:
        #   pip install git+https://github.com/deepseek-ai/Janus.git
        try:
            from janus.models import MultiModalityCausalLM
            return MultiModalityCausalLM
        except ImportError:
            from transformers import AutoModel
            return AutoModel

    raise ValueError(f"No HF class mapping for family {family!r}")


def _load_model(model_spec, dtype, quantization: Optional[str], logger):
    """Load the model with the right class, optionally quantized.

    Phase-2.1 fix (2026-05-22) for transformers >= 5.0: when a custom model
    has a `model_type` that is NOT in the built-in CONFIG_MAPPING (e.g.
    Janus-Pro's ``multi_modality`` or DeepSeek-VL2's ``deepseek_vl_v2``),
    newer transformers versions raise ValueError BEFORE checking the
    ``auto_map`` fallback for ``trust_remote_code=True``. We work around by
    explicitly loading ``AutoConfig`` first with ``trust_remote_code=True``
    and passing the config to the model class.
    """
    cls = _resolve_hf_class(
        model_spec.family,
        model_spec.hf_id,
        trust_remote_code=model_spec.requires_trust_remote_code,
    )

    kwargs = dict(low_cpu_mem_usage=True)
    if model_spec.requires_trust_remote_code:
        kwargs["trust_remote_code"] = True
        # Pre-load the config explicitly so transformers 5.x falls into the
        # auto_map / dynamic-module path instead of raising on unknown
        # model_type. Safe no-op for older transformers.
        try:
            from transformers import AutoConfig
            cfg = AutoConfig.from_pretrained(
                model_spec.hf_id, trust_remote_code=True
            )
            kwargs["config"] = cfg
            if logger:
                logger.info(
                    f"Pre-loaded AutoConfig with trust_remote_code=True "
                    f"(model_type={getattr(cfg, 'model_type', '?')})"
                )
        except Exception as e:
            if logger:
                logger.warn(
                    f"AutoConfig pre-load failed ({type(e).__name__}: {e}); "
                    f"proceeding without explicit config"
                )

    quant_cfg = get_quantization_config(quantization)
    if quant_cfg is not None:
        kwargs["quantization_config"] = quant_cfg
        if logger:
            logger.info(f"Quantization: {describe_quantization(quantization)}")
    else:
        if logger:
            logger.info(f"Quantization: none (dtype={dtype})")

    # Phase-2.2 fix (2026-05-22): on transformers >= 5.0, custom-code models
    # (Molmo, InternVL3, etc.) crash in `_finalize_model_loading` because the
    # new code path calls `self.all_tied_weights_keys.keys()` but the custom
    # modeling file only defines the legacy `_tied_weights_keys`. We monkey-
    # patch a default property onto PreTrainedModel before loading so the
    # access succeeds. Harmless on transformers 4.x (overrides a real
    # attribute that just returns the same data).
    try:
        from transformers import PreTrainedModel
        if not hasattr(PreTrainedModel, "all_tied_weights_keys"):
            def _all_tied_weights_keys(self):
                """Compat shim: map legacy _tied_weights_keys list → dict."""
                legacy = getattr(self, "_tied_weights_keys", None) or []
                # transformers 5.x expects a dict {target_key: source_key};
                # legacy was a list of keys. Build an identity mapping.
                if isinstance(legacy, dict):
                    return legacy
                return {k: k for k in legacy}
            PreTrainedModel.all_tied_weights_keys = property(_all_tied_weights_keys)
            if logger:
                logger.info(
                    "Patched PreTrainedModel.all_tied_weights_keys (transformers 5.x compat)"
                )
    except Exception as e:
        if logger:
            logger.warn(f"all_tied_weights_keys patch failed ({type(e).__name__}: {e})")

    try:
        return cls.from_pretrained(model_spec.hf_id, dtype=dtype, **kwargs)
    except TypeError:
        if logger:
            logger.info("Retrying load with torch_dtype= for older transformers")
        return cls.from_pretrained(model_spec.hf_id, torch_dtype=dtype, **kwargs)


# ---------------------------------------------------------------------------
# Record I/O — incremental update across scripts
# ---------------------------------------------------------------------------

def load_existing_record(model_spec, measurement_dir: str) -> Optional[ModelRecord]:
    path = Path(measurement_dir) / f"{sanitize_for_filename(model_spec.hf_id)}.json"
    if not path.exists():
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return ModelRecord.from_dict(data)
    except Exception:
        return None


def merge_records(existing: ModelRecord, new: ModelRecord) -> ModelRecord:
    """Field-by-field merge so reruns of one metric don't clobber others."""
    out = ModelRecord(
        model_id=new.model_id,
        name=new.name,
        family=new.family,
        release_year=new.release_year,
        architecture_pattern=new.architecture_pattern or existing.architecture_pattern,
        input_config=new.input_config,
        measurement_timestamp=new.measurement_timestamp,
        hardware=new.hardware or existing.hardware,
        benchmark_scores={**existing.benchmark_scores, **new.benchmark_scores},
        benchmark_sources={**existing.benchmark_sources, **new.benchmark_sources},
        parameter_audit=new.parameter_audit or existing.parameter_audit,
    )
    out.notes = "\n".join(s for s in [existing.notes, new.notes] if s)

    all_names = set(existing.components.keys()) | set(new.components.keys())
    for cname in all_names:
        old_c = existing.components.get(cname)
        new_c = new.components.get(cname)
        if old_c is None and new_c is not None:
            out.components[cname] = new_c
            continue
        if new_c is None and old_c is not None:
            out.components[cname] = old_c
            continue
        merged = ComponentRecord(name=cname)
        merged.module_path = new_c.module_path or old_c.module_path
        merged.notes = new_c.notes or old_c.notes
        # Counts — prefer new if non-zero, else keep old
        for field_name in ("params_total", "params_trainable", "params_active"):
            new_val = getattr(new_c, field_name, None)
            old_val = getattr(old_c, field_name, None)
            chosen = new_val if (new_val is not None and new_val != 0) else old_val
            setattr(merged, field_name, chosen)
        for field_name in ("n_experts_total", "n_experts_active_per_token"):
            new_val = getattr(new_c, field_name, None)
            old_val = getattr(old_c, field_name, None)
            setattr(merged, field_name, new_val if new_val is not None else old_val)
        # Floats / Nones
        for field_name in (
            "flops_g", "peak_mem_mb",
            "output_tokens", "output_tokens_at_native_res", "output_tokens_at_224",
        ):
            new_val = getattr(new_c, field_name, None)
            old_val = getattr(old_c, field_name, None)
            chosen = new_val if new_val is not None else old_val
            setattr(merged, field_name, chosen)
        # Strings + flags
        merged.flops_source = new_c.flops_source or old_c.flops_source
        merged.flops_estimate = new_c.flops_estimate or old_c.flops_estimate
        out.components[cname] = merged

    seen_stages = {fp.stage for fp in existing.freezing_policies}
    out.freezing_policies = list(existing.freezing_policies)
    for fp in new.freezing_policies:
        if fp.stage not in seen_stages:
            out.freezing_policies.append(fp)
    return out


def _save_record(rec: ModelRecord, measurement_dir: str, logger):
    Path(measurement_dir).mkdir(parents=True, exist_ok=True)
    out_path = Path(measurement_dir) / f"{sanitize_for_filename(rec.model_id)}.json"
    existing = None
    if out_path.exists():
        try:
            with open(out_path, "r", encoding="utf-8") as f:
                existing = ModelRecord.from_dict(json.load(f))
        except Exception as e:
            if logger:
                logger.warn(f"Could not parse existing record at {out_path}: {e}")
    if existing is not None:
        if logger:
            logger.info(f"Merging into existing record at {out_path}")
        rec = merge_records(existing, rec)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(rec.to_dict(), f, indent=2)
    if logger:
        logger.info(f"Saved record to {out_path}")
    return out_path


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_full_audit(
    model_spec,
    metrics: Optional[Set[str]] = None,
    ic: Optional[InputConfig] = None,
    device: str = "cuda",
    dtype=None,
    quantization: Optional[str] = None,
    measurement_dir: str = "outputs/measurements",
    log_dir: str = "outputs/logs",
    notebook_label: str = "audit",
    memory_repeats: int = 3,
    save_json: bool = True,
) -> ModelRecord:
    """Run the requested metrics on one model and return a ``ModelRecord``.

    Wrapped in try/except at every step so partial measurements still get
    saved even if one step crashes. Every error is logged with a full
    traceback to the per-model .txt log file.
    """
    import torch
    if metrics is None:
        metrics = {"params", "flops", "memory", "tokens"}
    if ic is None:
        ic = InputConfig()
    if dtype is None:
        dtype = torch.float16 if "memory" in metrics else torch.float32

    run_name = f"{notebook_label}__{sanitize_for_filename(model_spec.hf_id)}"
    log = ExperimentLogger(log_dir, run_name)

    rec = ModelRecord(
        model_id=model_spec.hf_id,
        name=model_spec.name,
        family=model_spec.family,
        release_year=model_spec.release_year,
        architecture_pattern=getattr(model_spec, "architecture_pattern", "") or "",
        input_config=ic,
        hardware=(
            f"cuda:{torch.cuda.get_device_name(0)}"
            if torch.cuda.is_available() else "cpu"
        ),
    )
    if quantization:
        rec.notes = f"quantization={quantization}"

    try:
        log.section(f"Auditing {model_spec.name} ({model_spec.hf_id})")
        log.info(f"Family: {model_spec.family}")
        log.info(f"Release year: {model_spec.release_year}")
        log.info(f"Native resolution: {model_spec.native_image_hw}")
        log.info(f"Input config: {ic.to_dict()}")
        log.info(f"Metrics: {sorted(metrics)}")
        log.info(f"Quantization: {describe_quantization(quantization)}")

        needs_model = bool(metrics & {"params", "flops", "memory"})

        model = None
        comps = None
        if needs_model:
            log.section("Loading model")
            t0 = time.time()
            try:
                model = _load_model(model_spec, dtype=dtype, quantization=quantization, logger=log)
                log.info(f"Loaded in {time.time() - t0:.1f}s")
            except Exception as e:
                log.error("Model load failed", e)
                # Still save the partial record (no measurements but identity intact)
                if save_json:
                    try:
                        _save_record(rec, measurement_dir, logger=log)
                    except Exception as e2:
                        log.error("Could not save partial record after load failure", e2)
                return rec

            log.section("Extracting components")
            try:
                comps = extract_components(model, model_spec.family)
                for cname, mod in comps.items():
                    log.info(
                        f"{cname:<18s}: "
                        f"{'<present>' if mod is not None else 'None'}  "
                        f"({type(mod).__name__ if mod is not None else '-'})"
                    )
            except Exception as e:
                log.error("Component extraction failed", e)
                if save_json:
                    try:
                        _save_record(rec, measurement_dir, logger=log)
                    except Exception as e2:
                        log.error("Could not save partial record after extract failure", e2)
                return rec

        component_names = tuple(comps.keys()) if comps else EXTENDED_COMPONENT_NAMES

        # --- Parameters (with Phase-2 F-5 fix: trainable from policy) ---
        if "params" in metrics and comps is not None:
            log.section("Parameter counting")
            # Revision fix A13: partition every parameter to exactly one
            # component and check the sum against the whole-model total.
            attribution = None
            inserted_cross_attention_params = 0
            try:
                attribution = partition_component_params(model, comps)
                inserted_cross_attention_params = count_inserted_cross_attention_params(model)
                rec.parameter_audit = build_parameter_audit_entry(
                    attribution, inserted_cross_attention_params, model_spec
                )
                _log_parameter_audit(log, rec.parameter_audit)
            except Exception as e:
                log.error("partition_component_params failed; component counts are NOT residual-checked", e)
            partitioned_counts = attribution["component_counts"] if attribution else None
            try:
                trainable_per_comp = compute_trainable_from_policy(
                    model_spec, comps,
                    partitioned_counts=partitioned_counts,
                    inserted_cross_attention_params=inserted_cross_attention_params,
                )
            except Exception as e:
                log.error("compute_trainable_from_policy failed; falling back to count_params", e)
                trainable_per_comp = {n: count_params(comps.get(n), trainable_only=True) for n in component_names}

            for cname in component_names:
                mod = comps.get(cname)
                loose_only_count = (partitioned_counts or {}).get(cname, 0) if mod is None else 0
                if mod is None and loose_only_count == 0:
                    rec.components[cname] = ComponentRecord(name=cname, notes="absent")
                    log.info(f"{cname}: absent")
                    continue
                try:
                    if partitioned_counts is not None and cname in partitioned_counts:
                        total = partitioned_counts[cname]
                    else:
                        total = count_params(mod, trainable_only=False)
                    trainable = trainable_per_comp.get(cname, total)
                    cr = ComponentRecord(
                        name=cname,
                        params_total=total,
                        params_trainable=trainable,
                    )
                    # MoE handling: store active params on the language component
                    if getattr(model_spec, "is_moe", False) and cname == "language":
                        cr.n_experts_total = model_spec.n_experts_total
                        cr.n_experts_active_per_token = model_spec.n_experts_active_per_token
                        try:
                            cr.params_active = count_active_params(
                                mod,
                                model_spec.n_experts_total,
                                model_spec.n_experts_active_per_token,
                            )
                            log.info(
                                f"MoE active params (language): {cr.params_active:,} "
                                f"of {total:,} total ({cr.n_experts_active_per_token}/{cr.n_experts_total} experts)"
                            )
                        except Exception as e:
                            log.error("count_active_params failed", e)
                    rec.components[cname] = cr
                    log.iteration(f"params {cname}", total=total, trainable=trainable)
                    log.metric("params_total", total)
                    log.metric("params_trainable", trainable)
                except Exception as e:
                    log.error(f"Param counting failed for {cname}", e)
                    rec.components[cname] = ComponentRecord(name=cname, notes="param_count_failed")

        # --- Tokens (static; no model load needed) ---
        if "tokens" in metrics:
            log.section("Fusion-boundary token count")
            try:
                n_tokens = count_fusion_boundary_tokens(model_spec, image_hw=ic.image_hw)
                log.info(f"Fusion boundary tokens (canonical): {n_tokens}")
                target = (
                    "fusion" if (comps and comps.get("fusion") is not None)
                    else "language"
                )
                if target not in rec.components:
                    rec.components[target] = ComponentRecord(name=target)
                rec.components[target].output_tokens = n_tokens
                log.iteration(f"tokens {target}", n_tokens=n_tokens)
                log.metric("output_tokens", n_tokens)

                # Phase-2: also record at native res + at 224 for dynamic-tile families
                if model_spec.family in ("dynamic_tile_adapter_llm", "moe_adapter_llm",
                                          "adapter_llm_own_encoder"):
                    try:
                        nt_native = count_dynamic_tile_tokens(model_spec, model_spec.native_image_hw)
                        nt_224 = count_dynamic_tile_tokens(model_spec, (224, 224))
                        rec.components[target].output_tokens_at_native_res = nt_native
                        rec.components[target].output_tokens_at_224 = nt_224
                        log.info(f"Tokens at native_res {model_spec.native_image_hw}: {nt_native}")
                        log.info(f"Tokens at 224x224 (standardized): {nt_224}")
                    except Exception as e:
                        log.error("Dynamic-tile token count failed", e)

                # Phase-2: for Chameleon, also record image-token vocab size
                if model_spec.family == "native_early_fusion" and model is not None:
                    try:
                        iv = count_image_token_vocab(model)
                        if "embeddings" not in rec.components:
                            rec.components["embeddings"] = ComponentRecord(name="embeddings")
                        rec.components["embeddings"].output_tokens = iv
                        log.info(f"Chameleon image-token vocab size: {iv}")
                    except Exception as e:
                        log.error("count_image_token_vocab failed", e)
            except Exception as e:
                log.error("Token-count metric failed", e)

        # --- FLOPs ---
        if "flops" in metrics and comps is not None:
            log.section("FLOPs measurement")
            try:
                dummies = build_dummy_inputs(model_spec.family, ic, device="cpu", model_spec=model_spec)
            except Exception as e:
                log.error("build_dummy_inputs for FLOPs failed", e)
                dummies = {}
            for cname in component_names:
                mod = comps.get(cname)
                kwargs = dummies.get(cname)
                if mod is None or kwargs is None:
                    log.info(f"{cname}: skipped (module or inputs missing)")
                    continue
                log.iteration(f"flops {cname}")
                try:
                    g, source = measure_flops(mod, kwargs, logger=log)
                except Exception as e:
                    log.error(f"measure_flops crashed on {cname}", e)
                    g, source = None, ""
                if cname not in rec.components:
                    rec.components[cname] = ComponentRecord(name=cname)
                rec.components[cname].flops_g = g
                rec.components[cname].flops_source = source
                rec.components[cname].flops_estimate = (source == "manual_estimate")
                if g is not None:
                    log.metric("flops_g", round(g, 4), unit="GFLOPs")
                    log.metric("flops_source", source)

        # --- Memory ---
        if "memory" in metrics and comps is not None:
            if not torch.cuda.is_available():
                log.warn("Memory metric requested but CUDA unavailable; skipping")
            else:
                log.section("Peak activation memory measurement")
                try:
                    dummies = build_dummy_inputs(model_spec.family, ic, device="cpu", model_spec=model_spec)
                except Exception as e:
                    log.error("build_dummy_inputs for memory failed", e)
                    dummies = {}
                for cname in component_names:
                    mod = comps.get(cname)
                    kwargs = dummies.get(cname)
                    if mod is None or kwargs is None:
                        log.info(f"{cname}: skipped (module or inputs missing)")
                        continue
                    log.iteration(f"memory {cname} (median of {memory_repeats})")
                    try:
                        peak = measure_peak_memory(
                            mod, kwargs,
                            device=device,
                            repeats=memory_repeats,
                            logger=log,
                        )
                    except Exception as e:
                        log.error(f"measure_peak_memory crashed on {cname}", e)
                        peak = None
                    if cname not in rec.components:
                        rec.components[cname] = ComponentRecord(name=cname)
                    rec.components[cname].peak_mem_mb = peak
                    if peak is not None:
                        log.metric("peak_mem_mb_median", round(peak, 2), unit="MB")

        # --- Freezing policy hint (annotation only) ---
        log.section("Freezing policy")
        try:
            hint = freezing_policy_hint(model_spec.family)
            log.info(hint)
            rec.freezing_policies.append(
                FreezingPolicy(stage="training_recipe", notes=hint)
            )
        except Exception as e:
            log.error("freezing_policy_hint failed", e)

        # --- Save (incremental merge) — runs even if some steps failed ---
        if save_json:
            try:
                _save_record(rec, measurement_dir, logger=log)
            except Exception as e:
                log.error("Save record failed", e)

        # --- Cleanup ---
        try:
            if model is not None:
                del model
            del comps
        except Exception:
            pass
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    except Exception as e:
        log.error("Audit top-level failed", e)
        # One more save attempt for whatever partial data we have
        if save_json:
            try:
                _save_record(rec, measurement_dir, logger=log)
            except Exception:
                pass
    finally:
        log.close()

    return rec
